<?php
$pageTitle = 'DriveSmart - Welkom';
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-hero">
    <div>
        <div class="ds-tag">Blauw • Geel • Olijfgroen</div>
        <h1>Welkom bij DriveSmart</h1>
        <p>Betrouwbare rijlessen met aandacht voor elke leerling. Veilig, persoonlijk en professioneel.</p>
        <div class="ds-stack">
            <a class="ds-btn ds-btn-primary" href="../Database/login.php">Inloggen</a>
            <a class="ds-btn ds-btn-outline" href="../Database/User-register.php">Registreren</a>
        </div>
    </div>
    <div class="ds-card">
        <h3 class="ds-section-title" style="margin-top:0;">Wat je kunt verwachten</h3>
        <ul style="padding-left: 16px; margin: 0; color: var(--muted); line-height: 1.6;">
            <li>Moderne auto's en ervaren instructeurs</li>
            <li>Flexibele planning, ook avonden en weekenden</li>
            <li>Persoonlijk plan voor leerlingen met een beperking</li>
            <li>Transparante prijzen zonder verrassingen</li>
        </ul>
    </div>
</section>

<section class="ds-section">
    <h2 class="ds-section-title">Waarom DriveSmart?</h2>
    <div class="ds-grid">
        <div class="ds-card">
            <h3>Ervaren instructeurs</h3>
            <p class="ds-text-muted">Gecertificeerd team met jaren praktijkervaring.</p>
        </div>
        <div class="ds-card">
            <h3>Moderne auto's</h3>
            <p class="ds-text-muted">Veilig en goed onderhouden, voorzien van de nieuwste hulpmiddelen.</p>
        </div>
        <div class="ds-card">
            <h3>Flexibele planning</h3>
            <p class="ds-text-muted">Lessen wanneer het jou uitkomt.</p>
        </div>
        <div class="ds-card">
            <h3>Persoonlijk plan</h3>
            <p class="ds-text-muted">Afgestemd op jouw doelen en eventuele beperkingen.</p>
        </div>
        <div class="ds-card">
            <h3>Heldere prijzen</h3>
            <p class="ds-text-muted">Geen verborgen kosten, wel kwaliteit.</p>
        </div>
        <div class="ds-card">
            <h3>Hoge slagingskans</h3>
            <p class="ds-text-muted">Effectieve lesmethode met duidelijke feedback.</p>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
