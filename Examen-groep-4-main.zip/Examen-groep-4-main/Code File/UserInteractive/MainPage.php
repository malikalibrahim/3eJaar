<?php
    require_once '../Database/db.php';
    session_start();
    
    if (!isset($_SESSION['user_id'])) {
        header('Location: ../Database/login.php');
        exit;
    }
    
    $userName = $_SESSION['user_name'] ?? 'Gebruiker';
    $role = $_SESSION['role'] ?? '';
?>

<?php
$pageTitle = 'DriveSmart Dashboard';
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-hero">
    <div>
        <div class="ds-tag">Welkom terug</div>
        <h1>Hallo, <?php echo htmlspecialchars($userName, ENT_QUOTES, 'UTF-8'); ?></h1>
        <p>Ga direct naar je dashboard of log uit.</p>
        <div class="ds-stack">
            <?php
            $drivesmartLink = null;
            if ($role === 'student') {
                $drivesmartLink = '../Leerling/HomepageLeerling.php';
            } elseif ($role === 'teacher') {
                $drivesmartLink = '../Instructor/HomepageInstructor.php';
            } elseif ($role === 'admin') {
                $drivesmartLink = '../Admin/HomepageAdmin.php';
            }
            ?>

            <?php if ($drivesmartLink): ?>
                <a class="ds-btn ds-btn-primary" href="<?php echo $drivesmartLink; ?>">Naar dashboard</a>
            <?php endif; ?>
            <form action="../Database/logout.php" method="POST" style="display: inline;">
                <button type="submit" class="ds-btn ds-btn-outline">Uitloggen</button>
            </form>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
