<?php
// Publieke weergave van de algemene voorwaarden
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../Database/db.php';
require_once __DIR__ . '/../Database/Admin-class.php';

$admin = new Admin($pdo);
$currentTerms = $admin->getTerms();

$pageTitle = 'Algemene voorwaarden';
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-section">
    <h1 class="ds-section-title" style="margin-top:0;">Algemene voorwaarden</h1>
    <div class="ds-card">
        <?php if (empty($currentTerms)): ?>
            <p class="ds-text-muted">Er zijn nog geen voorwaarden gepubliceerd.</p>
        <?php else: ?>
            <pre style="white-space: pre-wrap; margin:0; font-family: Arial, sans-serif;"><?= htmlspecialchars($currentTerms) ?></pre>
        <?php endif; ?>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
