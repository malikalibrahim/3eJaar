<?php
$pageTitle = 'Over ons - DriveSmart';
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-section">
    <h1 class="ds-section-title" style="margin-top:0;">Over DriveSmart</h1>
    <div class="ds-card">
        <p class="ds-text-muted">
            DriveSmart specialiseert zich in rijlessen voor leerlingen met een fysieke beperking.
            We bieden aangepaste voertuigen, deskundige begeleiding en een persoonlijke aanpak zodat
            iedere leerling veilig en zelfstandig de weg op kan.
        </p>
    </div>
</section>

<section class="ds-section">
    <h2 class="ds-section-title">Onze aanpak</h2>
    <div class="ds-card">
        <p class="ds-text-muted">
            We starten met een intake om jouw situatie te begrijpen en te bepalen welke aanpassingen nodig zijn.
            Daarna bouwen we een lesplan op maat, met heldere doelen en regelmatige feedback. Waar nodig
            schakelen we samen met specialisten zoals ergotherapeuten.
        </p>
    </div>
</section>

<section class="ds-section">
    <h2 class="ds-section-title">Team</h2>
    <div class="ds-grid">
        <div class="ds-card">
            <h3>Lesgevers</h3>
            <p class="ds-text-muted">Helena (begeleiding), Malik (instructeur), Avinash (instructeur), Kasper (planning).</p>
        </div>
        <div class="ds-card">
            <h3>Contactpersoon</h3>
            <p class="ds-text-muted">Chris Groot, eigenaar</p>
            <p class="ds-text-muted">E-mail: Chris@gmail.com</p>
        </div>
    </div>
</section>

<section class="ds-section">
    <h2 class="ds-section-title">Contact en locatie</h2>
    <div class="ds-card">
        <p class="ds-text-muted">
            Onze locatie is rolstoeltoegankelijk en heeft aangepaste parkeergelegenheid. Plan je route via Google Maps.
        </p>
        <a class="ds-btn ds-btn-primary" href="https://www.google.com/maps/dir/?api=1&destination=52.3159197,4.9438528" target="_blank" rel="noopener">Plan route</a>
        <div style="margin-top:14px;">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4878.009125883406!2d4.943852861073872!3d52.3159197!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c60b91697d8729%3A0xb5cf33c91399403c!2sMBO%20College%20Zuidoost%20%7C%20Hoofdlocatie%20%7C%20ROC%20van%20Amsterdam!5e0!3m2!1sen!2snl!4v1764760182574!5m2!1sen!2snl" width="100%" height="320" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
