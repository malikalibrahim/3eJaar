<?php
// Bootstrap: zoek omhoog naar project root config.php en include indien aanwezig
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/student-class.php';
require_once __DIR__ . '/../includes/Algemeen/schedule-class.php';
require_once __DIR__ . '/../includes/Algemeen/announcement-class.php';
session_start();

if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit;
}

$studentId = $_SESSION['student_id'];
$schedule = new Schedule();
$announcement = new Announcement();

$lessons = $schedule->getStudentLessons($studentId);
$announcements = $announcement->getForTarget('student');
$pageTitle = 'Leerling - Home';
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-hero">
    <div>
        <div class="ds-tag">Leerling dashboard</div>
        <h1>Welkom, <?= htmlspecialchars($_SESSION['student_name'] ?? 'Leerling') ?></h1>
        <p>Plan je lessen, bekijk opmerkingen en volg je voortgang.</p>
        <div class="ds-stack">
            <a class="ds-btn ds-btn-primary" href="leerling-les-plannen.php">Les plannen</a>
            <a class="ds-btn ds-btn-outline" href="pakket-lessen.php">Mijn lespakket</a>
        </div>
    </div>
    <div class="ds-card">
        <h3 class="ds-section-title" style="margin-top:0;">Snelle links</h3>
        <ul style="padding-left:16px; margin:0; color:var(--muted); line-height:1.6;">
            <li><a href="profile.php">Mijn profiel</a></li>
            <li><a href="../UserInteractive/terms.php">Algemene voorwaarden</a></li>
            <li><a href="../Database/logout.php">Uitloggen</a></li>
        </ul>
    </div>
</section>

<section class="ds-section">
    <h2 class="ds-section-title">Mijn lessen</h2>
    <div class="ds-card">
        <table class="ds-table">
            <thead>
            <tr>
                <th>Datum/tijd</th>
                <th>Onderwerp</th>
                <th>Status</th>
                <th>Mijn opmerking</th>
                <th>Instructeur opmerking</th>
                <th>Acties</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($lessons as $lesson): ?>
                <tr>
                    <td><?= htmlspecialchars($lesson['ScheduleDateTime']) ?></td>
                    <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '') ?></td>
                    <td>
                        <?php if ($lesson['ScheduleStatus'] === 'cancelled'): ?>
                            <span class="ds-pill warn">Geannuleerd</span>
                        <?php elseif ($lesson['ScheduleStatus'] === 'done'): ?>
                            <span class="ds-pill success">Voltooid</span>
                        <?php else: ?>
                            <span class="ds-pill info">Gepland</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (!empty($lesson['ScheduleStudentRemark'])): ?>
                            <span class="ds-text-muted"><?= htmlspecialchars(substr($lesson['ScheduleStudentRemark'], 0, 50)) ?>...</span>
                        <?php else: ?>
                            <span class="ds-text-muted">-</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (!empty($lesson['ScheduleTeacherRemark'])): ?>
                            <span class="ds-text-muted"><?= htmlspecialchars(substr($lesson['ScheduleTeacherRemark'], 0, 50)) ?>...</span>
                        <?php else: ?>
                            <span class="ds-text-muted">-</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="ds-stack">
                            <a class="ds-btn ds-btn-outline" href="leerling-ophaal-locatie.php?id=<?= (int)$lesson['idSchedule'] ?>">Ophaallocatie</a>
                            <a class="ds-btn ds-btn-primary" href="leerling-les-opmerking.php?id=<?= (int)$lesson['idSchedule'] ?>">Opmerking</a>
                            <a class="ds-btn ds-btn-outline" href="leerling-les-annuleren.php?id=<?= (int)$lesson['idSchedule'] ?>">Annuleren</a>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<section class="ds-section">
    <h2 class="ds-section-title">Mededelingen</h2>
    <div class="ds-card">
        <?php if (!$announcements): ?>
            <p class="ds-text-muted">Geen mededelingen.</p>
        <?php else: ?>
            <?php foreach ($announcements as $a): ?>
                <div class="ds-card" style="margin-bottom:10px;">
                    <h4 style="margin:0 0 6px;"><?= htmlspecialchars($a['Title']) ?></h4>
                    <p class="ds-text-muted" style="margin:0 0 6px;"><?= htmlspecialchars($a['Message']) ?></p>
                    <small class="ds-text-muted"><?= htmlspecialchars($a['CreatedAt']) ?></small>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
