<?php
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/student-class.php';
session_start();

if (isset($_SESSION['student_id'])) {
    header('Location: HomepageLeerling.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student = new Student($pdo);
    $email = htmlspecialchars($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $row = $student->login($email);
    if ($row && password_verify($password, $row['StudentsPsw'])) {
        $_SESSION['student_id'] = $row['idStudents'];
        $_SESSION['student_name'] = $row['StudentsName'];
        $_SESSION['user_id'] = $row['idStudents'];
        // Standaardiseer sessie-gegevens voor centrale homepage/menu
        $_SESSION['user_name'] = $row['StudentsName'];
        $_SESSION['role'] = 'student';
        header('Location: HomepageLeerling.php');
        exit;
    } else {
        $error = 'Ongeldig e-mailadres of wachtwoord.';
    }
}

$pageTitle = "Leerling Inloggen";
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-section">
    <h1 class="ds-section-title" style="margin-top:0;">Leerling inloggen</h1>
    <div class="ds-card" style="max-width: 520px;">
        <?php if ($error): ?>
            <div class="ds-pill warn" style="display:block; margin-bottom:10px;"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="post" class="ds-form">
            <div>
                <label for="email">E-mailadres</label>
                <input type="email" id="email" name="email" class="ds-input" required>
            </div>
            <div>
                <label for="password">Wachtwoord</label>
                <input type="password" id="password" name="password" class="ds-input" required>
            </div>
            <div class="ds-stack" style="justify-content: flex-end;">
                <button type="submit" class="ds-btn ds-btn-primary">Inloggen</button>
            </div>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
