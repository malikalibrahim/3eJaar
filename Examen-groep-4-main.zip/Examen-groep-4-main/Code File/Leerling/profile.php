<?php
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/student-class.php';
session_start();

if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit;
}

$studentId = $_SESSION['student_id'];
$student = new Student();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name'] ?? '');
    $age = (int)($_POST['age'] ?? 0);
    $address = htmlspecialchars($_POST['address'] ?? '');
    $phone = htmlspecialchars($_POST['phone'] ?? '');
    $email = htmlspecialchars($_POST['email'] ?? '');

    $student->updateProfile($studentId, $name, $age, $address, $phone, $email);
    $_SESSION['student_name'] = $name;
    $message = 'Profiel is bijgewerkt.';
}

$data = $student->getById($studentId);

$pageTitle = "Mijn Profiel";
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-section">
    <h1 class="ds-section-title" style="margin-top:0;">Mijn profiel</h1>
    <div class="ds-card" style="display:grid; grid-template-columns: 1fr 1.4fr; gap:18px; max-width: 960px; align-items:start;">
        <?php if ($message): ?>
            <div class="ds-pill success" style="display:block; grid-column: 1 / -1; margin-bottom:10px;"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <div class="ds-card" style="box-shadow:none; border:1px solid var(--border); text-align:center;">
            <div style="display:flex; justify-content:center; margin-bottom:12px;">
                <div style="width:120px; height:120px; border-radius:50%; background:linear-gradient(135deg, #0d47a1, #556b2f); display:flex; align-items:center; justify-content:center; color:#fff; font-size:32px; font-weight:700;">
                    <?= strtoupper(substr($data['StudentsName'] ?? 'L', 0, 1)) ?>
                </div>
            </div>
            <h3 style="margin:0 0 6px;"><?= htmlspecialchars($data['StudentsName'] ?? 'Leerling') ?></h3>
            <p class="ds-text-muted" style="margin:0 0 10px;">Leerling profiel</p>
            <div class="ds-tag" style="display:block; margin:6px auto; width:fit-content;">E-mail: <?= htmlspecialchars($data['StudentsEmail'] ?? '-') ?></div>
            <div class="ds-tag" style="display:block; margin:6px auto; width:fit-content;">Telefoon: <?= htmlspecialchars($data['StudentsPhoneNumber'] ?? '-') ?></div>
            <div class="ds-tag" style="display:block; margin:6px auto; width:fit-content;">Adres: <?= htmlspecialchars($data['StudentsAddress'] ?? '-') ?></div>
        </div>

        <div>
            <h3 style="margin-top:0;">Gegevens bijwerken</h3>
            <form method="post" class="ds-form">
                <div class="ds-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));">
                    <div>
                        <label class="form-label">Naam</label>
                        <input type="text" name="name" class="ds-input" required
                               value="<?= htmlspecialchars($data['StudentsName'] ?? '') ?>">
                    </div>
                    <div>
                        <label class="form-label">Leeftijd</label>
                        <input type="number" name="age" class="ds-input" required
                               value="<?= htmlspecialchars($data['StudentsAge'] ?? '') ?>">
                    </div>
                </div>
                <div>
                    <label class="form-label">Adres</label>
                    <input type="text" name="address" class="ds-input" required
                           value="<?= htmlspecialchars($data['StudentsAddress'] ?? '') ?>">
                </div>
                <div class="ds-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));">
                    <div>
                        <label class="form-label">Telefoonnummer</label>
                        <input type="text" name="phone" class="ds-input" required
                               value="<?= htmlspecialchars($data['StudentsPhoneNumber'] ?? '') ?>">
                    </div>
                    <div>
                        <label class="form-label">E-mailadres</label>
                        <input type="email" name="email" class="ds-input" required
                               value="<?= htmlspecialchars($data['StudentsEmail'] ?? '') ?>">
                    </div>
                </div>
                <div class="ds-stack" style="justify-content: space-between; margin-top:10px;">
                    <a href="HomepageLeerling.php" class="ds-btn ds-btn-outline">Terug naar dashboard</a>
                    <button type="submit" class="ds-btn ds-btn-primary">Profiel opslaan</button>
                </div>
            </form>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
