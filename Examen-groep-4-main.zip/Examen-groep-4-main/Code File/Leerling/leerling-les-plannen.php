<?php
// Bootstrap config
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../includes/Algemeen/schedule-class.php';
session_start();

if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit;
}

$schedule = new Schedule();
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = $_POST['date'] ?? '';
    $time = $_POST['time'] ?? '';
    $subject = trim($_POST['subject'] ?? '');
    $pickLoc = trim($_POST['pickloc'] ?? '');
    $car = trim($_POST['car'] ?? '');

    if (!$date || !$time) {
        $message = 'Kies een datum en tijd.';
        $messageType = 'danger';
    } else {
        $dt = $date . ' ' . $time;
        try {
            $schedule->createLessonForStudent((int)$_SESSION['student_id'], null, $dt, $pickLoc, $subject, $car);
            $message = 'Les succesvol ingepland.';
            $messageType = 'success';
        } catch (Exception $e) {
            $message = 'Fout bij plannen: ' . $e->getMessage();
            $messageType = 'danger';
        }
    }
}

$pageTitle = "Les plannen";
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-section">
    <h1 class="ds-section-title" style="margin-top:0;">Les plannen</h1>
    <div class="ds-card" style="max-width: 720px;">
        <?php if ($message): ?>
            <div class="ds-pill <?= $messageType === 'success' ? 'success' : 'warn' ?>" style="display:block; margin-bottom:10px;">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>
        <form method="post" class="ds-form">
            <div class="ds-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));">
                <div>
                    <label for="date">Datum</label>
                    <input type="date" id="date" name="date" class="ds-input" required>
                </div>
                <div>
                    <label for="time">Tijd</label>
                    <input type="time" id="time" name="time" class="ds-input" required>
                </div>
            </div>
            <div>
                <label for="subject">Te behandelen onderdeel</label>
                <input type="text" id="subject" name="subject" class="ds-input" placeholder="Bijv. fileparkeren">
            </div>
            <div>
                <label for="pickloc">Ophaallocatie</label>
                <input type="text" id="pickloc" name="pickloc" class="ds-input" placeholder="Adres of punt">
            </div>
            <div>
                <label for="car">Gewenste auto (optioneel)</label>
                <input type="text" id="car" name="car" class="ds-input" placeholder="Kenteken of type">
            </div>
            <div class="ds-stack" style="justify-content: space-between;">
                <a href="HomepageLeerling.php" class="ds-btn ds-btn-outline">Terug</a>
                <button type="submit" class="ds-btn ds-btn-primary">Plan les</button>
            </div>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
