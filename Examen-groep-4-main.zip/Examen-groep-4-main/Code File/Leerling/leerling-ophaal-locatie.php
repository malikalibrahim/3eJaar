<?php
// Bootstrap config
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../includes/Algemeen/schedule-class.php';
session_start();

if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit;
}

$scheduleId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$schedule = new Schedule();
$lesson = $schedule->getById($scheduleId);

if (!$lesson || (int)$lesson['ScheduleStudentId'] !== (int)$_SESSION['student_id']) {
    http_response_code(403);
    echo "Je mag deze les niet aanpassen.";
    exit;
}

$message = '';
$messageType = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pickLoc = trim($_POST['pickloc'] ?? '');
    if ($pickLoc === '') {
        $message = 'Ophaallocatie mag niet leeg zijn.';
        $messageType = 'danger';
    } else {
        $schedule->updatePickupLocation($scheduleId, (int)$_SESSION['student_id'], $pickLoc);
        $message = 'Ophaallocatie bijgewerkt.';
        $messageType = 'success';
    }
}

$pageTitle = "Ophaallocatie aanpassen";
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-section">
    <h1 class="ds-section-title" style="margin-top:0;">Ophaallocatie aanpassen</h1>
    <div class="ds-card" style="max-width: 720px;">
        <p class="ds-text-muted" style="text-align:center;">Les op: <strong><?= htmlspecialchars($lesson['ScheduleDateTime']) ?></strong></p>
        <?php if ($message): ?>
            <div class="ds-pill <?= $messageType === 'success' ? 'success' : 'warn' ?>" style="display:block; margin-bottom:10px; text-align:center;">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>
        <form method="post" class="ds-form">
            <div>
                <label for="pickloc" class="form-label">Nieuwe ophaallocatie</label>
                <input type="text" id="pickloc" name="pickloc" class="ds-input" value="<?= htmlspecialchars($lesson['SchedulePickLoc'] ?? '') ?>" required>
            </div>
            <div class="ds-stack" style="justify-content: space-between;">
                <a href="HomepageLeerling.php" class="ds-btn ds-btn-outline">Terug</a>
                <button type="submit" class="ds-btn ds-btn-primary">Opslaan</button>
            </div>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
