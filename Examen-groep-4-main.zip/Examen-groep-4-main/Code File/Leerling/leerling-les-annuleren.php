<?php
// Bootstrap: zoek omhoog naar project root config.php en include indien aanwezig
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../includes/Algemeen/schedule-class.php';
session_start();

if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit;
}

$scheduleId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$schedule = new Schedule();
$lesson = $schedule->getById($scheduleId);

if (!$lesson || (int)$lesson['ScheduleStudentId'] !== (int)$_SESSION['student_id']) {
    http_response_code(403);
    echo "Je mag deze les niet annuleren.";
    exit;
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reason = htmlspecialchars($_POST['reason'] ?? '');
    if ($reason === '') {
        $message = 'Geef een reden op.';
    } else {
        $schedule->cancelLesson($scheduleId, $reason);
        header('Location: HomepageLeerling.php');
        exit;
    }
}

$pageTitle = "Les Annuleren";
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-section">
    <h1 class="ds-section-title" style="margin-top:0;">Les annuleren</h1>
    <div class="ds-card" style="max-width: 720px;">
        <p class="ds-text-muted" style="text-align:center;">Weet je zeker dat je de les op <strong><?= htmlspecialchars($lesson['ScheduleDateTime']) ?></strong> wilt annuleren?</p>
        <?php if ($message): ?>
            <div class="ds-pill warn" style="display:block; margin-bottom:10px;"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        <form method="post" class="ds-form">
            <div>
                <label for="reason" class="form-label">Reden van annuleren</label>
                <textarea id="reason" name="reason" class="ds-textarea" rows="4" required></textarea>
            </div>
            <div class="ds-stack" style="justify-content: space-between;">
                <a href="HomepageLeerling.php" class="ds-btn ds-btn-outline">Nee, ga terug</a>
                <button type="submit" class="ds-btn ds-btn-primary">Ja, annuleer deze les</button>
            </div>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
