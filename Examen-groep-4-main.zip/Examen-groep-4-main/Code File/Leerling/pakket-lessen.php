<?php
// Bootstrap config
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../Database/db.php';
session_start();

if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit;
}

$studentId = (int)$_SESSION['student_id'];

// Haal student + stripcard info op
$stmt = $pdo->prepare("SELECT StudentsName, StudentsStripCard FROM students WHERE idStudents = :id");
$stmt->execute(['id' => $studentId]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

$pakketAantal = (int)($student['StudentsStripCard'] ?? 0);

// Aantal afgeronde lessen binnen pakket (status 'done')
$stmt = $pdo->prepare("SELECT * FROM schedule WHERE ScheduleStudentId = :sid AND ScheduleStatus = 'done' ORDER BY ScheduleDateTime DESC");
$stmt->execute(['sid' => $studentId]);
$completedLessons = $stmt->fetchAll(PDO::FETCH_ASSOC);

$gebruikt = count($completedLessons);
$resterend = max(0, $pakketAantal - $gebruikt);

$pageTitle = "Mijn lespakket";
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-section">
    <h1 class="ds-section-title" style="margin-top:0;">Lespakket voortgang</h1>
    <div class="ds-card">
        <div class="ds-grid" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));">
            <div class="ds-card" style="box-shadow:none; border:1px solid var(--border);">
                <strong>Aantal lessen in pakket</strong>
                <div style="font-size:20px; margin-top:6px;"><?= $pakketAantal ?></div>
            </div>
            <div class="ds-card" style="box-shadow:none; border:1px solid var(--border);">
                <strong>Reeds afgenomen</strong>
                <div style="font-size:20px; margin-top:6px;"><?= $gebruikt ?></div>
            </div>
            <div class="ds-card" style="box-shadow:none; border:1px solid var(--border);">
                <strong>Resterend</strong>
                <div style="font-size:20px; margin-top:6px;"><?= $resterend ?></div>
            </div>
        </div>

        <h3 class="ds-section-title">Afgeronde lessen</h3>
        <?php if (empty($completedLessons)): ?>
            <p class="ds-text-muted">Nog geen afgeronde lessen.</p>
        <?php else: ?>
            <table class="ds-table">
                <thead>
                    <tr>
                        <th>Datum/tijd</th>
                        <th>Onderwerp</th>
                        <th>Ophaallocatie</th>
                        <th>Opmerking instructeur</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($completedLessons as $lesson): ?>
                    <tr>
                        <td><?= htmlspecialchars($lesson['ScheduleDateTime']) ?></td>
                        <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '') ?></td>
                        <td><?= htmlspecialchars($lesson['SchedulePickLoc'] ?? '') ?></td>
                        <td>
                            <?php if (!empty($lesson['ScheduleTeacherRemark'])): ?>
                                <span class="ds-text-muted"><?= htmlspecialchars(substr($lesson['ScheduleTeacherRemark'], 0, 80)) ?>...</span>
                            <?php else: ?>
                                <span class="ds-text-muted">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <div class="ds-stack" style="justify-content: space-between; margin-top:12px;">
            <a href="HomepageLeerling.php" class="ds-btn ds-btn-outline">Terug</a>
            <a href="leerling-les-plannen.php" class="ds-btn ds-btn-primary">Nieuwe les plannen</a>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
