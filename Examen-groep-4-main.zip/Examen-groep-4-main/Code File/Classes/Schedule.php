<?php
class Schedule {
    private PDO $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function getToday(): array {
        $start = (new DateTime('today'))->format('Y-m-d 00:00:00');
        $end   = (new DateTime('today'))->format('Y-m-d 23:59:59');

        $sql = "SELECT idSchedule, ScheduleDateTime, ScheduleCar, SchedulePickLoc
                FROM schedule
                WHERE ScheduleDateTime BETWEEN :start AND :end
                ORDER BY ScheduleDateTime ASC";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['start' => $start, 'end' => $end]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}