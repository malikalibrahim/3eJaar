<?php
class Car {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function getAll(): array {
        $sql = "SELECT idCars, CarsType, CarsWear, CarsUsed, CarsODO, CarsMaintenance FROM cars ORDER BY idCars ASC";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}