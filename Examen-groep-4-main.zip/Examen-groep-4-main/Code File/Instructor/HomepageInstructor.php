<?php
session_start();
require_once __DIR__ . '/../includes/Algemeen/announcement-class.php';
require_once __DIR__ . '/../../Database/database.php';

// Sessie-waarden consistent maken
$instructorId = $_SESSION['user_id'] ?? $_SESSION['teacher_id'] ?? null;
$instructorName = $_SESSION['user_name'] ?? 'Instructeur';
$role = $_SESSION['role'] ?? null;

// Database verbinding
$db = new Database('127.0.0.1', 'drivesmart', 'root', '');
$pdo = $db->getPdo();

// Fallback: haal ID op wanneer alleen naam/rol bekend is
if (!$instructorId && isset($_SESSION['user_name']) && in_array($role, ['teacher', 'instructeur'], true)) {
    try {
        $stmt = $pdo->prepare("SELECT idTeachers FROM teachers WHERE TeachersName = :name LIMIT 1");
        $stmt->execute([':name' => $_SESSION['user_name']]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($result) {
            $instructorId = $result['idTeachers'];
            $_SESSION['user_id'] = $instructorId;
            $_SESSION['teacher_id'] = $instructorId;
        }
    } catch (PDOException $e) {
        $errorMsg = "Kon instructeur ID niet ophalen: " . $e->getMessage();
    }
}

$selectedDate = $_GET['date'] ?? date('Y-m-d');
$todaySchedule = [];
$teacherAnnouncements = [];

if ($instructorId) {
    try {
        $sql = "SELECT 
                    s.idSchedule,
                    s.ScheduleDateTime,
                    s.ScheduleCar,
                    s.SchedulePickLoc,
                    s.ScheduleSubject,
                    s.ScheduleStatus,
                    st.StudentsName,
                    t.TeachersName
                FROM schedule s
                LEFT JOIN students st ON s.ScheduleStudentId = st.idStudents
                LEFT JOIN teachers t ON s.ScheduleTeacherId = t.idTeachers
                WHERE DATE(s.ScheduleDateTime) = :date
                  AND s.ScheduleTeacherId = :instructorId
                  AND (s.ScheduleStatus = 'planned' OR s.ScheduleStatus IS NULL)
                ORDER BY s.ScheduleDateTime ASC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':date' => $selectedDate,
            ':instructorId' => $instructorId
        ]);
        $todaySchedule = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $announcement = new Announcement();
        $teacherAnnouncements = $announcement->getForTarget('teacher');
    } catch (PDOException $e) {
        $errorMsg = "Fout bij ophalen rooster: " . $e->getMessage();
    }
}

$pageTitle = 'DriveSmart - Instructeur';
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-hero">
    <div>
        <div class="ds-tag">Instructeur dashboard</div>
        <h1>Welkom, <?= htmlspecialchars($instructorName) ?>!</h1>
        <p>Hier vind je jouw dagrooster en snelle acties.</p>
        <div class="ds-stack">
            <a class="ds-btn ds-btn-primary" href="weekrooster.php">Weekrooster / nieuwe les</a>
            <a class="ds-btn ds-btn-outline" href="kilometersinv.php">Kilometers</a>
            <a class="ds-btn ds-btn-outline" href="ziekmeld.php">Ziek melden</a>
        </div>
    </div>
    <div class="ds-card">
        <h3 class="ds-section-title" style="margin-top:0;">Snelle links</h3>
        <ul style="padding-left:16px; margin:0; color:var(--muted); line-height:1.6;">
            <li><a href="day-schedule.php">Volledige lessenlijst</a></li>
            <li><a href="print-dayrooster.php?date=<?= htmlspecialchars($selectedDate) ?>" target="_blank">Print dagrooster</a></li>
            <li><a href="../Database/logout.php">Uitloggen</a></li>
        </ul>
    </div>
</section>

<section class="ds-section">
    <h2 class="ds-section-title">Dagrooster - <?= date('l d F Y', strtotime($selectedDate)) ?></h2>
    <div class="ds-card">
        <div class="ds-stack" style="justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <form method="get" class="ds-form" style="grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); margin:0;">
                <label for="date">Selecteer datum:</label>
                <div class="ds-stack" style="align-items: center;">
                    <input type="date" id="date" name="date" value="<?= htmlspecialchars($selectedDate) ?>" class="ds-input" style="max-width:180px;">
                    <button type="submit" class="ds-btn ds-btn-primary">Toon</button>
                </div>
            </form>
            <div class="ds-stack">
                <a class="ds-btn ds-btn-outline" href="?date=<?= date('Y-m-d') ?>">Vandaag</a>
                <a class="ds-btn ds-btn-outline" href="weekrooster.php">Weekrooster</a>
            </div>
        </div>

        <?php if (isset($errorMsg)): ?>
            <div class="ds-pill warn" style="display:block; margin-bottom:10px;"><?= htmlspecialchars($errorMsg) ?></div>
        <?php endif; ?>

        <?php if (!$instructorId): ?>
            <p class="ds-text-muted">Je bent niet ingelogd als instructeur. Log opnieuw in.</p>
        <?php elseif (empty($todaySchedule)): ?>
            <p class="ds-text-muted"><strong>Geen lessen ingepland voor deze dag.</strong></p>
        <?php else: ?>
            <table class="ds-table">
                <thead>
                    <tr>
                        <th>Tijd</th>
                        <th>Leerling</th>
                        <th>Auto</th>
                        <th>Ophaalplaats</th>
                        <th>Onderwerp</th>
                        <th>Status</th>
                        <th>Acties</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($todaySchedule as $lesson): 
                    $dateTime = new DateTime($lesson['ScheduleDateTime']);
                ?>
                        <tr>
                            <td><?= $dateTime->format('H:i') ?></td>
                            <td><?= htmlspecialchars($lesson['StudentsName'] ?? 'Onbekend') ?></td>
                            <td><?= htmlspecialchars($lesson['ScheduleCar'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($lesson['SchedulePickLoc'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '-') ?></td>
                            <td><span class="ds-pill info"><?= htmlspecialchars(ucfirst($lesson['ScheduleStatus'] ?? 'planned')) ?></span></td>
                            <td>
                                <div class="ds-stack">
                                    <a class="ds-btn ds-btn-outline" href="instructor-lesson-remark.php?id=<?= (int)$lesson['idSchedule'] ?>">Opmerking</a>
                                    <a class="ds-btn ds-btn-primary" href="instructor-lesson-edit.php?id=<?= (int)$lesson['idSchedule'] ?>">Aanpassen</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div class="ds-pill success" style="display:inline-block; margin-top:12px;">
                Totaal vandaag: <?= count($todaySchedule) ?> les(sen)
            </div>
        <?php endif; ?>
    </div>
</section>

<section class="ds-section">
    <h2 class="ds-section-title">Mededelingen voor instructeurs</h2>
    <div class="ds-card">
        <?php if (empty($teacherAnnouncements)): ?>
            <p class="ds-text-muted">Geen mededelingen.</p>
        <?php else: ?>
            <?php foreach ($teacherAnnouncements as $a): ?>
                <div class="ds-card" style="margin-bottom:10px;">
                    <h4 style="margin:0 0 6px;"><?= htmlspecialchars($a['Title']) ?></h4>
                    <p class="ds-text-muted" style="margin:0 0 6px;"><?= htmlspecialchars($a['Message']) ?></p>
                    <small class="ds-text-muted"><?= htmlspecialchars($a['CreatedAt']) ?></small>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
