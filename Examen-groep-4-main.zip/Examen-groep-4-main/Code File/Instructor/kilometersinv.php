<?php
session_start();
require_once __DIR__ . '/../../Database/database.php';

$db = new Database('127.0.0.1', 'drivesmart', 'root', '');
$pdo = $db->getPdo();

$instructorId = $_SESSION['teacher_id'] ?? ($_SESSION['user_id'] ?? null);
$instructorName = $_SESSION['user_name'] ?? 'Instructeur';

if (!$instructorId) {
    die('Je moet ingelogd zijn als instructeur om deze pagina te bekijken.');
}

$errors = [];
$successMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_odo'])) {
    $carId = (int) ($_POST['car_id'] ?? 0);
    $newOdo = (int) ($_POST['odo_value'] ?? 0);
    
    if (!$carId) {
        $errors[] = 'Kies een auto.';
    }
    if ($newOdo <= 0) {
        $errors[] = 'Voer een geldige kilometerstand in.';
    }
    
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("SELECT CarsODO, CarsType FROM cars WHERE idCars = :carId");
            $stmt->execute([':carId' => $carId]);
            $car = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($car) {
                $currentOdo = (int) $car['CarsODO'];
                
                if ($newOdo < $currentOdo) {
                    $errors[] = "Nieuwe kilometerstand ($newOdo km) kan niet lager zijn dan de huidige stand ($currentOdo km).";
                } else {
                    $stmt = $pdo->prepare("UPDATE cars SET CarsODO = :odo WHERE idCars = :carId");
                    $stmt->execute([
                        ':odo' => $newOdo,
                        ':carId' => $carId
                    ]);
                    
                    $kmDriven = $newOdo - $currentOdo;
                    $successMessage = "Kilometerstand bijgewerkt. {$car['CarsType']}: $currentOdo km → $newOdo km (+$kmDriven km gereden)";
                }
            } else {
                $errors[] = 'Auto niet gevonden.';
            }
        } catch (Exception $e) {
            $errors[] = 'Fout bij bijwerken kilometerstand: ' . $e->getMessage();
        }
    }
}

try {
    $stmt = $pdo->query("SELECT idCars, CarsType, CarLicensep, CarsODO, CarsMaintenance FROM cars ORDER BY CarsType");
    $cars = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $cars = [];
    $errors[] = 'Fout bij ophalen auto\'s: ' . $e->getMessage();
}

$pageTitle = 'DriveSmart - Kilometerstand';
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-hero">
    <div>
        <div class="ds-tag">Instructeur • Kilometerstand</div>
        <h1>Kilometerstand bijwerken</h1>
        <p>Ingelogd als <?= htmlspecialchars($instructorName) ?></p>
        <div class="ds-stack">
            <a class="ds-btn ds-btn-outline" href="HomepageInstructor.php">Dashboard</a>
            <a class="ds-btn ds-btn-outline" href="weekrooster.php">Weekrooster</a>
        </div>
    </div>
</section>

<?php if ($successMessage): ?>
    <div class="ds-pill success" style="display:block; margin-bottom:10px;"><?= htmlspecialchars($successMessage) ?></div>
<?php endif; ?>

<?php if (!empty($errors)): ?>
    <div class="ds-card" style="border:1px solid var(--accent-yellow);">
        <strong>Fouten:</strong>
        <ul style="margin: 4px 0 0 16px;">
            <?php foreach ($errors as $error): ?>
                <li><?= htmlspecialchars($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<section class="ds-section">
    <div class="ds-grid" style="grid-template-columns: 1.2fr 1fr;">
        <div class="ds-card">
            <h3 class="ds-section-title" style="margin-top:0;">Huidige kilometerstanden</h3>
            <table class="ds-table">
                <thead>
                    <tr>
                        <th>Auto</th>
                        <th>Kenteken</th>
                        <th>Kilometerstand</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($cars)): ?>
                        <tr>
                            <td colspan="4" class="ds-text-muted">Geen auto's gevonden</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($cars as $car): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($car['CarsType']) ?></strong></td>
                                <td><?= htmlspecialchars($car['CarLicensep'] ?? '-') ?></td>
                                <td><?= number_format($car['CarsODO'] ?? 0, 0, ',', '.') ?> km</td>
                                <td>
                                    <?php if ($car['CarsMaintenance'] == 1): ?>
                                        <span class="ds-pill warn">Onderhoud nodig</span>
                                    <?php else: ?>
                                        <span class="ds-pill success">Beschikbaar</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="ds-card">
            <h3 class="ds-section-title" style="margin-top:0;">Kilometerstand invoeren</h3>
            <form method="post" class="ds-form">
                <input type="hidden" name="update_odo" value="1">
                <div>
                    <label for="car_id">Kies auto *</label>
                    <select name="car_id" id="car_id" class="ds-select" required>
                        <option value="">-- Selecteer een auto --</option>
                        <?php foreach ($cars as $car): ?>
                            <option value="<?= $car['idCars'] ?>">
                                <?= htmlspecialchars($car['CarsType']) ?> (<?= htmlspecialchars($car['CarLicensep'] ?? 'Geen kenteken') ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label for="odo_value">Nieuwe kilometerstand *</label>
                    <input type="number" id="odo_value" name="odo_value" class="ds-input" min="1" required placeholder="bijv. 12000">
                </div>

                <div class="ds-stack" style="justify-content: flex-end;">
                    <button type="submit" class="ds-btn ds-btn-primary">Bijwerken</button>
                </div>
            </form>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
