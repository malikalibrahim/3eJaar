<?php
require_once __DIR__ . '/../Database/db.php';

class Teacher {
    private $db;

    public function __construct() {
        $this->db = new DB();
    }

    public function login($email) {
        return $this->db->run(
            "SELECT * FROM teachers WHERE TeachersEmail = :email",
            ["email" => $email]
        )->fetch();
    }

    public function create($name, $email, $phone, $password) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        return $this->db->run(
            "INSERT INTO teachers (TeachersName, TeachersEmail, TeachersPhoneNumber, TeachersPsw, Avaiblilty)
             VALUES (:name, :email, :phone, :password, 1)",
            [
                "name" => $name,
                "email" => $email,
                "phone" => $phone,
                "password" => $hash
            ]
        );
    }

    public function getById($id) {
        return $this->db->run(
            "SELECT * FROM teachers WHERE idTeachers = :id",
            ["id" => $id]
        )->fetch();
    }
}


