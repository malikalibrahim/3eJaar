<?php
session_start();
require_once __DIR__ . '/../../Database/database.php';

if (!isset($_SESSION['teacher_id'])) {
    die('Niet ingelogd.');
}

$instructorId = $_SESSION['teacher_id'];
$selectedDate = $_GET['date'] ?? date('Y-m-d');

$db = new Database('127.0.0.1', 'drivesmart', 'root', '');
$pdo = $db->getPdo();

$lessons = [];
try {
    $stmt = $pdo->prepare(
        "SELECT s.ScheduleDateTime, s.ScheduleCar, s.SchedulePickLoc, s.ScheduleSubject, st.StudentsName
         FROM schedule s
         LEFT JOIN students st ON s.ScheduleStudentId = st.idStudents
         WHERE DATE(s.ScheduleDateTime) = :date AND s.ScheduleTeacherId = :tid
         ORDER BY s.ScheduleDateTime ASC"
    );
    $stmt->execute([':date' => $selectedDate, ':tid' => $instructorId]);
    $lessons = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Fout bij ophalen rooster: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Dagrooster <?= htmlspecialchars($selectedDate) ?></title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { margin-bottom: 10px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #444; padding: 8px; font-size: 13px; }
        th { background: #eee; }
        @media print {
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="no-print" style="margin-bottom: 10px;">
        <button onclick="window.print()">Print</button>
        <a href="HomepageInstructor.php?date=<?= htmlspecialchars($selectedDate) ?>">Terug</a>
    </div>

    <h1>Dagrooster <?= htmlspecialchars(date('l d F Y', strtotime($selectedDate))) ?></h1>
    <?php if (empty($lessons)): ?>
        <p>Geen lessen ingepland.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Tijd</th>
                    <th>Leerling</th>
                    <th>Auto</th>
                    <th>Ophaalplaats</th>
                    <th>Onderwerp</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($lessons as $lesson): 
                    $dt = new DateTime($lesson['ScheduleDateTime']);
                ?>
                    <tr>
                        <td><?= $dt->format('H:i') ?></td>
                        <td><?= htmlspecialchars($lesson['StudentsName'] ?? '') ?></td>
                        <td><?= htmlspecialchars($lesson['ScheduleCar'] ?? '') ?></td>
                        <td><?= htmlspecialchars($lesson['SchedulePickLoc'] ?? '') ?></td>
                        <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '') ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</body>
</html>
