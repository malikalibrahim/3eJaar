<?php
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../includes/Algemeen/schedule-class.php';
require_once __DIR__ . '/../../Database/database.php';
session_start();

if (!isset($_SESSION['teacher_id'])) {
    header('Location: login.php');
    exit;
}

$scheduleId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$schedule = new Schedule();
$lesson = $schedule->getById($scheduleId);

if (!$lesson || (int)$lesson['ScheduleTeacherId'] !== (int)$_SESSION['teacher_id']) {
    http_response_code(403);
    echo "Je mag deze les niet aanpassen.";
    exit;
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dt = $_POST['datetime'] ?? '';
    $car = htmlspecialchars($_POST['car'] ?? '');
    $loc = htmlspecialchars($_POST['pickloc'] ?? '');
    $subject = htmlspecialchars($_POST['subject'] ?? '');
    $status = htmlspecialchars($_POST['status'] ?? 'planned');

    if ($dt === '' || $car === '' || $loc === '') {
        $message = 'Vul alle verplichte velden in.';
    } else {
        try {
            $schedule->updateLesson($scheduleId, $dt, $loc, $subject, $status, $car);
            header('Location: HomepageInstructor.php');
            exit;
        } catch (Exception $e) {
            $message = 'Fout bij opslaan: ' . $e->getMessage();
        }
    }
}

$cars = [];
try {
    $db = new Database('127.0.0.1', 'drivesmart', 'root', '');
    $pdo = $db->getPdo();
    // Toon alleen beschikbare auto's (niet in onderhoud)
    $stmt = $pdo->query("SELECT idCars, CarsType, CarLicensep FROM cars WHERE CarsMaintenance = 0 ORDER BY CarsType");
    $cars = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // als ophalen faalt, laat dropdown leeg maar voorkom fatal
    $cars = [];
}

$pageTitle = "Les aanpassen";
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-section">
    <h1 class="ds-section-title" style="margin-top:0;">Les aanpassen</h1>
    <div class="ds-card" style="max-width: 720px;">
        <?php if ($message): ?>
            <div class="ds-pill warn" style="display:block; margin-bottom:10px;"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        <form method="post" class="ds-form">
            <div>
                <label for="datetime">Datum en tijd *</label>
                <input type="datetime-local" id="datetime" name="datetime" class="ds-input" required
                       value="<?= htmlspecialchars(str_replace(' ', 'T', $lesson['ScheduleDateTime'])) ?>">
            </div>
            <div>
                <label for="car">Auto *</label>
                <?php if ($cars): ?>
                    <select id="car" name="car" class="ds-select" required>
                        <option value="">Kies een auto</option>
                        <?php foreach ($cars as $c): 
                            $display = trim(($c['CarsType'] ?? '') . ' ' . ($c['CarLicensep'] ?? ''));
                            $selected = ($lesson['ScheduleCar'] ?? '') === $display ? 'selected' : '';
                        ?>
                            <option value="<?= htmlspecialchars($display) ?>" <?= $selected ?>>
                                <?= htmlspecialchars($display) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                <?php else: ?>
                    <input type="text" id="car" name="car" class="ds-input" required value="<?= htmlspecialchars($lesson['ScheduleCar'] ?? '') ?>">
                <?php endif; ?>
            </div>
            <div>
                <label for="pickloc">Ophaallocatie *</label>
                <input type="text" id="pickloc" name="pickloc" class="ds-input" required value="<?= htmlspecialchars($lesson['SchedulePickLoc'] ?? '') ?>">
            </div>
            <div>
                <label for="subject">Onderwerp</label>
                <input type="text" id="subject" name="subject" class="ds-input" value="<?= htmlspecialchars($lesson['ScheduleSubject'] ?? '') ?>">
            </div>
            <div>
                <label for="status">Status</label>
                <select id="status" name="status" class="ds-select">
                    <option value="planned" <?= ($lesson['ScheduleStatus'] ?? '') === 'planned' ? 'selected' : '' ?>>Gepland</option>
                    <option value="done" <?= ($lesson['ScheduleStatus'] ?? '') === 'done' ? 'selected' : '' ?>>Voltooid</option>
                    <option value="cancelled" <?= ($lesson['ScheduleStatus'] ?? '') === 'cancelled' ? 'selected' : '' ?>>Geannuleerd</option>
                </select>
            </div>
            <div class="ds-stack" style="justify-content: space-between;">
                <a href="HomepageInstructor.php" class="ds-btn ds-btn-outline">Annuleren</a>
                <button type="submit" class="ds-btn ds-btn-primary">Opslaan</button>
            </div>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
