<?php
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../includes/Algemeen/schedule-class.php';
require_once __DIR__ . '/../includes/Algemeen/announcement-class.php';
session_start();

if (!isset($_SESSION['teacher_id']) && !isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$teacherId = $_SESSION['teacher_id'] ?? ($_SESSION['user_id'] ?? null);
$schedule = new Schedule();
$announcement = new Announcement();

$lessons = $schedule->getTeacherLessons($teacherId);
$announcements = $announcement->getForTarget('teacher');
$debugLessonsCount = count($lessons);

$pageTitle = "Instructeur - Lessenlijst";
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-hero">
    <div>
        <div class="ds-tag">Instructeur • Lessenlijst</div>
        <h1>Mijn lessen</h1>
        <p>Overzicht van al jouw lessen en opmerkingen.</p>
        <div class="ds-stack">
            <a class="ds-btn ds-btn-outline" href="HomepageInstructor.php">Dashboard</a>
            <a class="ds-btn ds-btn-outline" href="weekrooster.php">Weekrooster</a>
        </div>
    </div>
</section>

<section class="ds-section">
    <div class="ds-grid" style="grid-template-columns: 2fr 1fr;">
        <div class="ds-card">
            <h3 class="ds-section-title" style="margin-top:0;">Mijn lessen</h3>
            <?php if ($debugLessonsCount === 0): ?>
                <p class="ds-text-muted">Geen lessen gevonden voor instructeur ID <?= (int)$teacherId ?>.</p>
            <?php endif; ?>
            <table class="ds-table">
                <thead>
                <tr>
                    <th>Datum/tijd</th>
                    <th>Leerling</th>
                    <th>Onderwerp</th>
                    <th>Status</th>
                    <th>Annuleringsreden</th>
                    <th>Leerling opmerking</th>
                    <th>Mijn opmerking</th>
                    <th>Acties</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($lessons as $lesson): ?>
                    <tr>
                        <td><?= htmlspecialchars($lesson['ScheduleDateTime']) ?></td>
                        <td><?= htmlspecialchars($lesson['StudentsName'] ?? 'Onbekend') ?></td>
                        <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '') ?></td>
                        <td><?= htmlspecialchars($lesson['ScheduleStatus']) ?></td>
                        <td>
                            <?php if (!empty($lesson['ScheduleCancelReason'])): ?>
                                <span class="ds-text-muted"><?= htmlspecialchars(substr($lesson['ScheduleCancelReason'], 0, 50)) ?>...</span>
                            <?php else: ?>
                                <span class="ds-text-muted">Geen reden</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!empty($lesson['ScheduleStudentRemark'])): ?>
                                <span class="ds-text-muted"><?= htmlspecialchars(substr($lesson['ScheduleStudentRemark'], 0, 50)) ?>...</span>
                            <?php else: ?>
                                <span class="ds-text-muted">Geen opmerking</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!empty($lesson['ScheduleTeacherRemark'])): ?>
                                <span class="ds-text-muted"><?= htmlspecialchars(substr($lesson['ScheduleTeacherRemark'], 0, 50)) ?>...</span>
                            <?php else: ?>
                                <span class="ds-text-muted">Geen opmerking</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="ds-stack" style="flex-wrap: wrap;">
                                <a href="instructor-lesson-remark.php?id=<?= (int)$lesson['idSchedule'] ?>" class="ds-btn ds-btn-outline">Opmerking</a>
                                <a href="instructor-lesson-edit.php?id=<?= (int)$lesson['idSchedule'] ?>" class="ds-btn ds-btn-primary">Aanpassen</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="ds-card">
            <h3 class="ds-section-title" style="margin-top:0;">Mededelingen</h3>
            <?php if (!$announcements): ?>
                <p class="ds-text-muted">Geen mededelingen.</p>
            <?php else: ?>
                <?php foreach ($announcements as $a): ?>
                    <div class="ds-card" style="margin-bottom:10px;">
                        <h4 style="margin:0 0 6px;"><?= htmlspecialchars($a['Title']) ?></h4>
                        <p class="ds-text-muted" style="margin:0 0 6px;"><?= htmlspecialchars($a['Message']) ?></p>
                        <small class="ds-text-muted"><?= htmlspecialchars($a['CreatedAt']) ?></small>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
