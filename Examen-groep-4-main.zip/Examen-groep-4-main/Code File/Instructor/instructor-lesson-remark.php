<?php
// Bootstrap: zoek omhoog naar project root config.php en include indien aanwezig
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../includes/Algemeen/schedule-class.php';
session_start();

if (!isset($_SESSION['teacher_id'])) {
    header('Location: login.php');
    exit;
}

$scheduleId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$schedule = new Schedule();
$lesson = $schedule->getById($scheduleId);

if (!$lesson || (int)$lesson['ScheduleTeacherId'] !== (int)$_SESSION['teacher_id']) {
    http_response_code(403);
    echo "Je mag voor deze les geen opmerking plaatsen.";
    exit;
}

$message = '';
$messageType = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $remark = htmlspecialchars($_POST['remark'] ?? '');
    if ($remark === '') {
        $message = 'Opmerking mag niet leeg zijn.';
        $messageType = 'danger';
    } else {
        try {
            $schedule->addTeacherRemark($scheduleId, $remark);
            $message = 'Opmerking succesvol toegevoegd.';
            $messageType = 'success';
        } catch (Exception $e) {
            $message = 'Fout bij het opslaan van de opmerking: ' . $e->getMessage();
            $messageType = 'danger';
        }
    }
}

$pageTitle = "Opmerking Toevoegen";
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-section">
    <h1 class="ds-section-title" style="margin-top:0;">Opmerking toevoegen</h1>
    <div class="ds-card" style="max-width: 640px;">
        <p class="ds-text-muted" style="text-align:center;">Les op: <strong><?= htmlspecialchars($lesson['ScheduleDateTime']) ?></strong></p>
        <?php if ($message): ?>
            <div class="ds-pill <?= $messageType === 'success' ? 'success' : 'warn' ?>" style="display:block; margin-bottom:10px; text-align:center;">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>
        <form method="post" class="ds-form">
            <div>
                <label for="remark" class="form-label">Jouw opmerking over de les</label>
                <textarea id="remark" name="remark" class="ds-textarea" rows="4" required></textarea>
            </div>
            <div class="ds-stack" style="justify-content: space-between;">
                <a href="day-schedule.php" class="ds-btn ds-btn-outline">Terug naar lessenlijst</a>
                <button type="submit" class="ds-btn ds-btn-primary">Opmerking opslaan</button>
            </div>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
