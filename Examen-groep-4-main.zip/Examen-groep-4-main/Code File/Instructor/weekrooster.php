<?php
session_start();
require_once __DIR__ . '/../../Database/database.php';

$db = new Database('127.0.0.1', 'drivesmart', 'root', '');
$pdo = $db->getPdo();

$instructorId = $_SESSION['teacher_id'] ?? ($_SESSION['user_id'] ?? null);
$instructorName = $_SESSION['user_name'] ?? 'Instructeur';

if (!$instructorId) {
    die('Je moet ingelogd zijn als instructeur om deze pagina te bekijken.');
}

$errors = [];
$successMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete_lesson'])) {
        $lessonId = (int) $_POST['lesson_id'];
        try {
            $stmt = $pdo->prepare("DELETE FROM schedule WHERE idSchedule = :id AND ScheduleTeacherId = :teacherId");
            $stmt->execute([':id' => $lessonId, ':teacherId' => $instructorId]);
            $successMessage = 'Les succesvol verwijderd!';
        } catch (PDOException $e) {
            $errors[] = 'Les kon niet worden verwijderd: ' . $e->getMessage();
        }
    } elseif (isset($_POST['create_lesson'])) {
        $studentId = (int) ($_POST['student_id'] ?? 0);
        $date = $_POST['date'] ?? '';
        $startTime = $_POST['start_time'] ?? '';
        $endTime = $_POST['end_time'] ?? '';
        $pickupLoc = $_POST['pickup_loc'] ?? '';
        $subject = $_POST['subject'] ?? '';
        $teacherRemark = $_POST['teacher_remark'] ?? '';

        if (!$studentId) {
            $errors[] = 'Kies een leerling.';
        }
        if (!$date || !$startTime || !$endTime) {
            $errors[] = 'Datum, begintijd en eindtijd zijn verplicht.';
        }

        if (empty($errors)) {
            try {
                $dateTime = new DateTime("$date $startTime");
                $endDateTime = new DateTime("$date $endTime");

                if ($endDateTime <= $dateTime) {
                    $errors[] = 'Eindtijd moet later zijn dan begintijd.';
                } else {
                    $stmt = $pdo->prepare("
                        INSERT INTO schedule (ScheduleDateTime, SchedulePickLoc, 
                                            ScheduleStudentId, ScheduleTeacherId, ScheduleSubject, 
                                            ScheduleStatus, ScheduleTeacherRemark)
                        VALUES (:datetime, :pickup, :studentId, :teacherId, :subject, 
                                'planned', :teacherRemark)
                    ");
                    $stmt->execute([
                        ':datetime' => $dateTime->format('Y-m-d H:i:s'),
                        ':pickup' => $pickupLoc,
                        ':studentId' => $studentId,
                        ':teacherId' => $instructorId,
                        ':subject' => $subject,
                        ':teacherRemark' => $teacherRemark
                    ]);
                    $successMessage = 'Les succesvol aangemaakt!';
                }
            } catch (Exception $e) {
                $errors[] = 'Fout bij aanmaken les: ' . $e->getMessage();
            }
        }
    } elseif (isset($_POST['report_defect'])) {
        $carId = (int) ($_POST['car_id'] ?? 0);
        $defectDescription = trim($_POST['defect_description'] ?? '');

        if (!$carId) {
            $errors[] = 'Kies een auto.';
        }
        if (empty($defectDescription)) {
            $errors[] = 'Beschrijf het mankement.';
        }

        if (empty($errors)) {
            try {
                $stmt = $pdo->prepare("SELECT CarsWear FROM cars WHERE idCars = :carId");
                $stmt->execute([':carId' => $carId]);
                $car = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($car) {
                    $currentWear = $car['CarsWear'];
                    $newWear = $currentWear;

                    if (!empty($currentWear)) {
                        $newWear = $currentWear . ' | ' . $defectDescription;
                    } else {
                        $newWear = $defectDescription;
                    }

                    $stmt = $pdo->prepare("
                        UPDATE cars 
                        SET CarsWear = :wear, CarsMaintenance = 1 
                        WHERE idCars = :carId
                    ");
                    $stmt->execute([
                        ':wear' => $newWear,
                        ':carId' => $carId
                    ]);

                    $successMessage = 'Mankement succesvol gemeld! Auto is nu gemarkeerd voor onderhoud.';
                } else {
                    $errors[] = 'Auto niet gevonden.';
                }
            } catch (Exception $e) {
                $errors[] = 'Fout bij melden mankement: ' . $e->getMessage();
            }
        }
    }
}

$week = $_GET['week'] ?? date('o-\WW');
$weekYear = substr($week, 0, 4);
$weekNr = substr($week, 6, 2);

$weekStart = new DateTime();
$weekStart->setISODate((int) $weekYear, (int) $weekNr);
$weekEnd = (clone $weekStart)->modify('+7 days');

try {
    $stmt = $pdo->prepare("
        SELECT s.*, 
               st.StudentsName
        FROM schedule s
        LEFT JOIN students st ON s.ScheduleStudentId = st.idStudents
        WHERE s.ScheduleTeacherId = :teacherId
          AND s.ScheduleDateTime >= :weekStart
          AND s.ScheduleDateTime < :weekEnd
        ORDER BY s.ScheduleDateTime ASC
    ");
    $stmt->execute([
        ':teacherId' => $instructorId,
        ':weekStart' => $weekStart->format('Y-m-d 00:00:00'),
        ':weekEnd' => $weekEnd->format('Y-m-d 00:00:00')
    ]);
    $lessons = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $errors[] = 'Fout bij ophalen lessen: ' . $e->getMessage();
    $lessons = [];
}

// Haal ook de lessen voor volgende week op (handig als huidige week leeg is)
$nextWeekStart = (clone $weekStart)->modify('+1 week');
$nextWeekEnd = (clone $nextWeekStart)->modify('+7 days');

try {
    $stmt = $pdo->prepare("
        SELECT s.*, 
               st.StudentsName
        FROM schedule s
        LEFT JOIN students st ON s.ScheduleStudentId = st.idStudents
        WHERE s.ScheduleTeacherId = :teacherId
          AND s.ScheduleDateTime >= :weekStart
          AND s.ScheduleDateTime < :weekEnd
        ORDER BY s.ScheduleDateTime ASC
    ");
    $stmt->execute([
        ':teacherId' => $instructorId,
        ':weekStart' => $nextWeekStart->format('Y-m-d 00:00:00'),
        ':weekEnd' => $nextWeekEnd->format('Y-m-d 00:00:00')
    ]);
    $nextWeekLessons = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = 'Fout bij ophalen lessen voor volgende week: ' . $e->getMessage();
    $nextWeekLessons = [];
}

$debugLessonsCount = count($lessons);
$debugNextLessonsCount = count($nextWeekLessons);

// Haal alle komende lessen (vanaf vandaag) als extra fallback
try {
    $stmt = $pdo->prepare("
        SELECT s.*, st.StudentsName
        FROM schedule s
        LEFT JOIN students st ON s.ScheduleStudentId = st.idStudents
        WHERE s.ScheduleTeacherId = :teacherId
          AND s.ScheduleDateTime >= :today
        ORDER BY s.ScheduleDateTime ASC
        LIMIT 100
    ");
    $stmt->execute([
        ':teacherId' => $instructorId,
        ':today' => date('Y-m-d 00:00:00')
    ]);
    $upcomingLessons = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = 'Fout bij ophalen komende lessen: ' . $e->getMessage();
    $upcomingLessons = [];
}

// Haal alle lessen (laatste 50) ter debug/overzicht
try {
    $stmt = $pdo->prepare("
        SELECT s.*, st.StudentsName
        FROM schedule s
        LEFT JOIN students st ON s.ScheduleStudentId = st.idStudents
        WHERE s.ScheduleTeacherId = :teacherId
        ORDER BY s.ScheduleDateTime DESC
        LIMIT 50
    ");
    $stmt->execute([
        ':teacherId' => $instructorId
    ]);
    $allLessons = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = 'Fout bij ophalen alle lessen: ' . $e->getMessage();
    $allLessons = [];
}

try {
    $stmt = $pdo->query("SELECT idStudents, StudentsName FROM students ORDER BY StudentsName");
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $students = [];
}

try {
    $stmt = $pdo->query("SELECT idCars, CarsType, CarLicensep, CarsMaintenance FROM cars ORDER BY CarsType");
    $cars = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $cars = [];
}

$prevWeek = (clone $weekStart)->modify('-1 week')->format('o-\WW');
$nextWeek = (clone $weekStart)->modify('+1 week')->format('o-\WW');
$currentWeek = (new DateTime())->format('o-\WW');

$pageTitle = 'DriveSmart - Weekrooster';
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-hero">
    <div>
        <div class="ds-tag">Instructeur • Week <?= htmlspecialchars($weekNr) ?></div>
        <h1>Weekrooster</h1>
        <p>Ingelogd als <?= htmlspecialchars($instructorName) ?> | <?= htmlspecialchars($weekYear) ?></p>
        <div class="ds-stack">
            <a class="ds-btn ds-btn-outline" href="?week=<?= htmlspecialchars($prevWeek) ?>">&laquo; Vorige week</a>
            <a class="ds-btn ds-btn-primary" href="?week=<?= htmlspecialchars($currentWeek) ?>">Deze week</a>
            <a class="ds-btn ds-btn-outline" href="?week=<?= htmlspecialchars($nextWeek) ?>">Volgende week &raquo;</a>
        </div>
    </div>
    <div class="ds-card">
        <h3 class="ds-section-title" style="margin-top:0;">Snelle links</h3>
        <ul style="padding-left:16px; margin:0; color:var(--muted); line-height:1.6;">
            <li><a href="HomepageInstructor.php">Dashboard</a></li>
            <li><a href="kilometersinv.php">Kilometers</a></li>
            <li><a href="ziekmeld.php">Ziek melden</a></li>
        </ul>
    </div>
</section>

<?php if ($successMessage): ?>
    <div class="ds-pill success" style="display:block; margin-bottom:10px;"><?= htmlspecialchars($successMessage) ?></div>
<?php endif; ?>

<?php if (!empty($errors)): ?>
    <div class="ds-card" style="border:1px solid var(--accent-yellow);">
        <strong>Fout:</strong>
        <ul style="margin: 6px 0 0 16px;">
            <?php foreach ($errors as $err): ?>
                <li><?= htmlspecialchars($err) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<section class="ds-section">
    <div class="ds-grid" style="grid-template-columns: 2fr 1fr;">
        <div class="ds-card">
            <h3 class="ds-section-title" style="margin-top:0;">Mijn lessen deze week (<?= count($lessons) ?>)</h3>
            <?php if ($debugLessonsCount === 0): ?>
                <p class="ds-text-muted">Geen lessen gevonden voor deze week voor instructeur ID <?= (int)$instructorId ?> (week <?= htmlspecialchars($week) ?>).</p>
            <?php endif; ?>
            <table class="ds-table">
                <thead>
                    <tr>
                        <th>Datum/tijd</th>
                        <th>Leerling</th>
                        <th>Ophaallocatie</th>
                        <th>Onderwerp</th>
                        <th>Status</th>
                        <th>Actie</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($lessons)): ?>
                        <tr>
                            <td colspan="6" class="ds-text-muted">Geen lessen gepland</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($lessons as $lesson): 
                            $dt = new DateTime($lesson['ScheduleDateTime']);
                        ?>
                            <tr>
                                <td><?= $dt->format('d-m H:i') ?></td>
                                <td><?= htmlspecialchars($lesson['StudentsName'] ?? 'Onbekend') ?></td>
                                <td><?= htmlspecialchars($lesson['SchedulePickLoc'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($lesson['ScheduleStatus'] ?? 'planned') ?></td>
                                <td>
                                    <form method="post" style="margin:0;" onsubmit="return confirm('Verwijderen?');">
                                        <input type="hidden" name="lesson_id" value="<?= $lesson['idSchedule'] ?>">
                                        <input type="hidden" name="delete_lesson" value="1">
                                        <button type="submit" class="ds-btn ds-btn-outline">Verwijder</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="ds-grid" style="grid-template-columns: 1fr;">
            <div class="ds-card">
                <h3 class="ds-section-title" style="margin-top:0;">Nieuwe les</h3>
                <form method="post" class="ds-form">
                    <input type="hidden" name="create_lesson" value="1">
                    <div>
                        <label>Leerling *</label>
                        <select name="student_id" class="ds-select" required>
                            <option value="">Kies leerling</option>
                            <?php foreach ($students as $s): ?>
                                <option value="<?= $s['idStudents'] ?>"><?= htmlspecialchars($s['StudentsName']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="ds-grid" style="grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));">
                        <div>
                            <label>Datum *</label>
                            <input type="date" name="date" class="ds-input" required value="<?= date('Y-m-d') ?>">
                        </div>
                        <div>
                            <label>Begintijd *</label>
                            <input type="time" name="start_time" class="ds-input" required>
                        </div>
                        <div>
                            <label>Eindtijd *</label>
                            <input type="time" name="end_time" class="ds-input" required>
                        </div>
                    </div>
                    <div>
                        <label>Ophaallocatie</label>
                        <input type="text" name="pickup_loc" class="ds-input" placeholder="Adres">
                    </div>
                    <div>
                        <label>Onderwerp</label>
                        <input type="text" name="subject" class="ds-input" placeholder="Bijv. Parkeren">
                    </div>
                    <div>
                        <label>Opmerking instructeur</label>
                        <textarea name="teacher_remark" class="ds-textarea" rows="2"></textarea>
                    </div>
                    <div class="ds-stack" style="justify-content: flex-end;">
                        <button type="submit" class="ds-btn ds-btn-primary">Les opslaan</button>
                    </div>
                </form>
            </div>

            <div class="ds-card">
                <h3 class="ds-section-title" style="margin-top:0;">Mankement melden</h3>
                <form method="post" class="ds-form">
                    <input type="hidden" name="report_defect" value="1">
                    <div>
                        <label>Auto *</label>
                        <select name="car_id" class="ds-select" required>
                            <option value="">Kies auto</option>
                            <?php foreach ($cars as $car): ?>
                                <option value="<?= $car['idCars'] ?>">
                                    <?= htmlspecialchars($car['CarsType']) ?> (<?= htmlspecialchars($car['CarLicensep'] ?? 'Geen kenteken') ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label>Beschrijving mankement *</label>
                        <textarea name="defect_description" class="ds-textarea" rows="3" required placeholder="Beschrijf het mankement in detail..."></textarea>
                    </div>
                    <div class="ds-stack" style="justify-content: flex-end;">
                        <button type="submit" class="ds-btn ds-btn-primary">Mankement melden</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<section class="ds-section">
    <div class="ds-card">
        <h3 class="ds-section-title" style="margin-top:0;">Volgende week (<?= $nextWeekStart->format('o-\WW') ?>) - <?= count($nextWeekLessons) ?> les(sen)</h3>
        <?php if ($debugNextLessonsCount === 0): ?>
            <p class="ds-text-muted">Geen lessen gepland voor volgende week voor instructeur ID <?= (int)$instructorId ?>.</p>
        <?php else: ?>
            <table class="ds-table">
                <thead>
                    <tr>
                        <th>Datum/tijd</th>
                        <th>Leerling</th>
                        <th>Ophaallocatie</th>
                        <th>Onderwerp</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($nextWeekLessons as $lesson): 
                        $dt = new DateTime($lesson['ScheduleDateTime']);
                    ?>
                        <tr>
                            <td><?= $dt->format('d-m H:i') ?></td>
                            <td><?= htmlspecialchars($lesson['StudentsName'] ?? 'Onbekend') ?></td>
                            <td><?= htmlspecialchars($lesson['SchedulePickLoc'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($lesson['ScheduleStatus'] ?? 'planned') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</section>

<section class="ds-section">
    <div class="ds-card">
        <h3 class="ds-section-title" style="margin-top:0;">Volgende week (<?= $nextWeekStart->format('o-\WW') ?>) - <?= count($nextWeekLessons) ?> les(sen)</h3>
        <?php if ($debugNextLessonsCount === 0): ?>
            <p class="ds-text-muted">Geen lessen gepland voor volgende week voor instructeur ID <?= (int)$instructorId ?>.</p>
        <?php else: ?>
            <table class="ds-table">
                <thead>
                    <tr>
                        <th>Datum/tijd</th>
                        <th>Leerling</th>
                        <th>Ophaallocatie</th>
                        <th>Onderwerp</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($nextWeekLessons as $lesson): 
                        $dt = new DateTime($lesson['ScheduleDateTime']);
                    ?>
                        <tr>
                            <td><?= $dt->format('d-m H:i') ?></td>
                            <td><?= htmlspecialchars($lesson['StudentsName'] ?? 'Onbekend') ?></td>
                            <td><?= htmlspecialchars($lesson['SchedulePickLoc'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($lesson['ScheduleStatus'] ?? 'planned') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</section>

<section class="ds-section">
    <div class="ds-card">
        <h3 class="ds-section-title" style="margin-top:0;">Komende lessen (alle vanaf vandaag) - <?= count($upcomingLessons) ?> gevonden</h3>
        <?php if (empty($upcomingLessons)): ?>
            <p class="ds-text-muted">Geen lessen gevonden vanaf vandaag voor instructeur ID <?= (int)$instructorId ?>. Controleer of het juiste teacher_id in de schedule-tabel staat.</p>
        <?php else: ?>
            <table class="ds-table">
                <thead>
                    <tr>
                        <th>Datum/tijd</th>
                        <th>Leerling</th>
                        <th>Onderwerp</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($upcomingLessons as $lesson): 
                        $dt = new DateTime($lesson['ScheduleDateTime']);
                    ?>
                        <tr>
                            <td><?= $dt->format('d-m H:i') ?></td>
                            <td><?= htmlspecialchars($lesson['StudentsName'] ?? 'Onbekend') ?></td>
                            <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($lesson['ScheduleStatus'] ?? 'planned') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</section>

<section class="ds-section">
    <div class="ds-card">
        <h3 class="ds-section-title" style="margin-top:0;">Alle lessen (laatste 50) voor instructeur ID <?= (int)$instructorId ?> - <?= count($allLessons) ?></h3>
        <?php if (empty($allLessons)): ?>
            <p class="ds-text-muted">Geen lessen gevonden in de database voor deze instructeur. Controleer of de kolom ScheduleTeacherId = <?= (int)$instructorId ?> gevuld is.</p>
        <?php else: ?>
            <table class="ds-table">
                <thead>
                    <tr>
                        <th>Datum/tijd</th>
                        <th>Leerling</th>
                        <th>Onderwerp</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($allLessons as $lesson): 
                        $dt = new DateTime($lesson['ScheduleDateTime']);
                    ?>
                        <tr>
                            <td><?= $dt->format('d-m H:i') ?></td>
                            <td><?= htmlspecialchars($lesson['StudentsName'] ?? 'Onbekend') ?></td>
                            <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($lesson['ScheduleStatus'] ?? 'planned') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
