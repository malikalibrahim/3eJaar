<?php
session_start();
require_once __DIR__ . '/../../Database/database.php';

$db = new Database('127.0.0.1', 'drivesmart', 'root', '');
$pdo = $db->getPdo();

$melding = '';
$meldingClass = 'info';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $naam = $_POST['naam'] ?? '';
    $datum = $_POST['datum'] ?? '';
    $reden = $_POST['reden'] ?? '';

    if (empty($naam) || empty($datum) || empty($reden)) {
        $melding = "Vul alle verplichte velden in.";
        $meldingClass = 'error';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT idTeachers FROM teachers WHERE TeachersName = :naam LIMIT 1");
            $stmt->execute([':naam' => $naam]);
            $result = $stmt->fetch();
            $instructeur_id = $result['idTeachers'] ?? null;

            if (!$instructeur_id) {
                $melding = "Instructeur niet gevonden in het systeem.";
                $meldingClass = 'error';
            } else {
                $stmt = $pdo->prepare("
                    INSERT INTO ziekmelding (instructeur_id, datum, tijd, reden) 
                    VALUES (:instructeur_id, :datum, :tijd, :reden)
                ");
                $stmt->execute([
                    ':instructeur_id' => $instructeur_id,
                    ':datum' => $datum,
                    ':tijd' => date('H:i:s'),
                    ':reden' => $reden
                ]);
                $melding = "Ziekmelding opgeslagen voor: $naam op $datum.";
                $meldingClass = 'success';
            }
        } catch (PDOException $e) {
            $melding = "Fout bij opslaan: " . $e->getMessage();
            $meldingClass = 'error';
        }
    }
}

$pageTitle = 'Ziekmelding - Instructeur';
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-section">
    <h1 class="ds-section-title" style="margin-top:0;">Ziek melden</h1>
    <div class="ds-card" style="max-width: 640px;">
        <?php if (!empty($melding)): ?>
            <div class="ds-pill <?= $meldingClass === 'success' ? 'success' : 'warn' ?>" style="display:block; margin-bottom:10px;">
                <?= htmlspecialchars($melding, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form method="post" class="ds-form">
            <div>
                <label for="naam">Naam instructeur</label>
                <input type="text" id="naam" name="naam" class="ds-input" placeholder="Voor- en achternaam" required>
                <div class="ds-text-muted" style="margin-top:4px;">Gebruik je volledige naam zoals geregistreerd.</div>
            </div>

            <div>
                <label for="datum">Datum ziekmelding</label>
                <input type="date" id="datum" name="datum" class="ds-input" required value="<?= date('Y-m-d'); ?>">
            </div>

            <div>
                <label for="reden">Reden / toelichting</label>
                <textarea id="reden" name="reden" class="ds-textarea" rows="3" placeholder="Bijv. griep, verkoudheid, andere reden..." required></textarea>
            </div>

            <div class="ds-stack" style="justify-content: flex-end;">
                <button type="submit" class="ds-btn ds-btn-primary">Ziekmelding verzenden</button>
            </div>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
