<footer class="ds-footer">
    <div class="ds-footer__inner">
        <div>
            <div class="ds-logo">DriveSmart</div>
            <p>Professionele rijschool voor iedereen. Blauw, geel en olijfgroen als vaste huisstijl.</p>
        </div>
        <div class="ds-footer__links">
            <a href="<?= $rootPrefix ?>index.php">Home</a>
            <a href="<?= $rootPrefix ?>Code%20File/UserInteractive/aboutus.php">Over ons</a>
            <a href="<?= $rootPrefix ?>Code%20File/Database/login.php">Inloggen</a>
        </div>
        <div class="ds-footer__meta">
            <p><?= date('Y') ?> © DriveSmart</p>
            <p>Alle rechten voorbehouden.</p>
        </div>
    </div>
</footer>
</main>
</body>
</html>
