<?php
// Shared header for DriveSmart pages
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Locate config.php so PROJECT_ROOT is available for path calculations
if (!defined('PROJECT_ROOT')) {
    $dir = __DIR__;
    for ($i = 0; $i < 6; $i++) {
        if (file_exists($dir . '/../../config.php')) {
            require_once $dir . '/../../config.php';
            break;
        }
        $parent = dirname($dir);
        if ($parent === $dir) {
            break;
        }
        $dir = $parent;
    }
}

// Fallback when config was not found
if (!defined('PROJECT_ROOT')) {
    define('PROJECT_ROOT', realpath(__DIR__ . '/../../..'));
}

// Compute a prefix (e.g. ../../) from the executing script to project root so links work everywhere
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_FILENAME'] ?? __FILE__));
$projectRoot = str_replace('\\', '/', PROJECT_ROOT);
$relativePath = str_replace($projectRoot, '', $scriptDir);
$relativePath = ltrim($relativePath, '/');
$depth = $relativePath === '' ? 0 : substr_count($relativePath, '/') + 1;
$rootPrefix = str_repeat('../', $depth);

$role = $_SESSION['role'] ?? 'guest';
$userName = $_SESSION['user_name'] ?? null;

$navItems = [
    'guest' => [
        ['label' => 'Home', 'href' => 'index.php'],
        ['label' => 'Over ons', 'href' => 'Code File/UserInteractive/aboutus.php'],
        ['label' => 'Inloggen', 'href' => 'Code File/Database/login.php'],
    ],
    'student' => [
        ['label' => 'Dashboard', 'href' => 'Code File/Leerling/HomepageLeerling.php'],
        ['label' => 'Les plannen', 'href' => 'Code File/Leerling/leerling-les-plannen.php'],
        ['label' => 'Profiel', 'href' => 'Code File/Leerling/profile.php'],
    ],
    'teacher' => [
        ['label' => 'Dashboard', 'href' => 'Code File/Instructor/HomepageInstructor.php'],
        ['label' => 'Weekrooster', 'href' => 'Code File/Instructor/weekrooster.php'],
        ['label' => 'Kilometers', 'href' => 'Code File/Instructor/kilometersinv.php'],
        ['label' => 'Ziek melden', 'href' => 'Code File/Instructor/ziekmeld.php'],
        ['label' => 'Lessenlijst', 'href' => 'Code File/Instructor/day-schedule.php'],
        ['label' => 'Nieuwe les', 'href' => 'Code File/Instructor/weekrooster.php#create-lesson'],
        ['label' => 'Mankement melden', 'href' => 'Code File/Instructor/weekrooster.php#defect'],
    ],
    'admin' => [
        ['label' => 'Dashboard', 'href' => 'Code File/Admin/HomepageAdmin.php'],
        ['label' => 'Mededelingen', 'href' => 'Code File/Admin/Mededeling.php'],
        ['label' => 'Wagenpark', 'href' => 'Code File/Admin/Wagenpark.php'],
        ['label' => 'Lespakketten', 'href' => 'Code File/Admin/lespakketen.php'],
        ['label' => 'Voorwaarden', 'href' => 'Code File/Admin/terms.php'],
    ],
];

$activeMenu = $navItems[$role] ?? $navItems['guest'];
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'DriveSmart', ENT_QUOTES, 'UTF-8') ?></title>
    <link rel="stylesheet" href="<?= $rootPrefix ?>Code%20File/Styling/global.css?v=2">
    <?php if (!empty($extraStyles) && is_array($extraStyles)): ?>
        <?php foreach ($extraStyles as $style): ?>
            <link rel="stylesheet" href="<?= htmlspecialchars($rootPrefix . ltrim($style, '/'), ENT_QUOTES, 'UTF-8') ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body>
<header class="ds-header">
    <div class="ds-header__inner">
        <a class="ds-logo" href="<?= $rootPrefix ?>index.php">DriveSmart</a>
        <nav class="ds-nav">
            <?php foreach ($activeMenu as $item): ?>
                <a href="<?= $rootPrefix . str_replace(' ', '%20', $item['href']) ?>">
                    <?= htmlspecialchars($item['label'], ENT_QUOTES, 'UTF-8') ?>
                </a>
            <?php endforeach; ?>
        </nav>
        <div class="ds-actions">
            <?php if ($userName): ?>
                <span class="ds-username">Hallo, <?= htmlspecialchars($userName, ENT_QUOTES, 'UTF-8') ?></span>
                <a class="ds-btn ds-btn-outline" href="<?= $rootPrefix ?>Code%20File/Database/logout.php">Uitloggen</a>
            <?php else: ?>
                <a class="ds-btn ds-btn-ghost" href="<?= $rootPrefix ?>Code%20File/Database/User-register.php">Registreren</a>
                <a class="ds-btn ds-btn-primary" href="<?= $rootPrefix ?>Code%20File/Database/login.php">Inloggen</a>
            <?php endif; ?>
        </div>
    </div>
</header>
<main class="ds-main">
