<?php

$melding = ""; // Variabele voor eventuele fout- of infomeldingen

// Controleren of het formulier verstuurd is via POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $rol = $_POST['rol'] ?? '';
    $email = $_POST['email'] ?? '';
    $wachtwoord = $_POST['wachtwoord'] ?? '';

    // Map de frontend waarden naar interne rol-namen
    $roleMap = [
        'leerling' => 'student',
        'instructeur' => 'teacher',
        'admin' => 'admin'
    ];
    $canonicalRole = $roleMap[$rol] ?? null;

    if (empty($canonicalRole) || empty($email) || empty($wachtwoord)) {
        $melding = "Vul alle velden in.";
    } else {
        require_once '../Database/db.php';
        $userData = null;

        if ($canonicalRole === 'student') {
            require_once '../Database/User-class.php';
            $userClass = new Student($pdo);
            $userData = $userClass->LoginUsers($email);
        } elseif ($canonicalRole === 'teacher') {
            require_once '../Database/teacher-class.php';
            $instructorClass = new Teachers($pdo);
            $userData = $instructorClass->LoginTeacher($email);
        } elseif ($canonicalRole === 'admin') {
            require_once '../Database/Admin-class.php';
            $adminClass = new Admin($pdo);
            $userData = $adminClass->LoginAdmin($email);
        } else {
            $melding = "Ongeldige rol geselecteerd.";
            $userData = null;
        }

        if ($userData) {
            $passwordVerified = false;
            if ($canonicalRole === 'student' && password_verify($wachtwoord, $userData['StudentsPsw'])) {
                $passwordVerified = true;
            } elseif ($canonicalRole === 'teacher' && password_verify($wachtwoord, $userData['TeachersPsw'])) {
                $passwordVerified = true;
            } elseif ($canonicalRole === 'admin' && password_verify($wachtwoord, $userData['AdminPsw'])) {
                $passwordVerified = true;
            }

            if ($passwordVerified) {
                session_start();
                $_SESSION['role'] = $canonicalRole;
                $_SESSION['user_id'] = $userData['id'] ?? $userData['idStudents'] ?? $userData['idTeachers'] ?? $userData['idAdmin'] ?? null;

                if ($canonicalRole === 'student') {
                    $_SESSION['student_id'] = $userData['idStudents'] ?? $userData['StudentsID'] ?? $userData['id'] ?? null;
                    $_SESSION['student_name'] = $userData['StudentsName'] ?? $userData['name'] ?? 'Leerling';
                    $_SESSION['user_name'] = $_SESSION['student_name'];
                    header("Location: ../Leerling/HomepageLeerling.php");
                    exit();
                } elseif ($canonicalRole === 'teacher') {
                    $_SESSION['teacher_id'] = $userData['idTeachers'] ?? $userData['TeachersID'] ?? $userData['id'] ?? null;
                    $_SESSION['teacher_name'] = $userData['TeachersName'] ?? $userData['name'] ?? 'Instructeur';
                    $_SESSION['user_name'] = $_SESSION['teacher_name'];
                    header("Location: ../Instructor/HomepageInstructor.php");
                    exit();
                } elseif ($canonicalRole === 'admin') {
                    $_SESSION['admin_id'] = $userData['idAdmin'] ?? $userData['AdminID'] ?? $userData['id'] ?? null;
                    $_SESSION['admin_name'] = $userData['AdminName'] ?? $userData['name'] ?? 'Admin';
                    $_SESSION['user_name'] = $_SESSION['admin_name'];
                    header("Location: ../Admin/HomepageAdmin.php");
                    exit();
                } else {
                    header("Location: ../UserInteractive/MainPage.php");
                    exit();
                }
            } else {
                $melding = "Ongeldig e-mailadres of wachtwoord.";
            }
        } else {
            $melding = "Ongeldig e-mailadres of wachtwoord.";
        }
    }
}

$pageTitle = 'Inloggen - DriveSmart';
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-section">
    <h1 class="ds-section-title" style="margin-top:0;">Inloggen</h1>
    <div class="ds-card">
        <?php if (!empty($melding)): ?>
            <div class="ds-pill warn" style="display:block; margin-bottom:10px; text-align:center;">
                <?= htmlspecialchars($melding, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form method="post" action="" class="ds-form">
            <div>
                <label for="rol">Rol</label>
                <select name="rol" id="rol" class="ds-select" required>
                    <option value="">-- Kies je rol --</option>
                    <option value="leerling">Leerling</option>
                    <option value="instructeur">Instructeur</option>
                    <option value="admin">Admin</option>
                </select>
                <div class="ds-text-muted" style="margin-top:4px;">Kies of je als leerling, instructeur of administrator wilt inloggen.</div>
            </div>

            <div>
                <label for="email">E-mailadres</label>
                <input type="email" id="email" name="email" class="ds-input" placeholder="voorbeeld@mail.nl" required>
            </div>

            <div>
                <label for="wachtwoord">Wachtwoord</label>
                <input type="password" id="wachtwoord" name="wachtwoord" class="ds-input" placeholder="Je wachtwoord" required>
            </div>

            <div class="ds-stack" style="justify-content: space-between; align-items: center;">
                <div class="ds-text-muted">Nog geen account? <a href="User-register.php">Registreer als leerling</a> of <a href="Teacher-register.php">als instructeur</a>.</div>
                <button type="submit" class="ds-btn ds-btn-primary">Inloggen</button>
            </div>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
