<?php
$pageTitle = 'Uitloggen';
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-section">
    <div class="ds-card" style="max-width: 520px; margin: 0 auto;">
        <h1 class="ds-section-title" style="margin-top:0;">Uitloggen</h1>
        <p>Weet je zeker dat je wilt uitloggen?</p>
        <form method="POST" class="ds-stack" style="justify-content: space-between;">
            <button type="submit" name="confirm_logout" class="ds-btn ds-btn-primary">Ja, uitloggen</button>
            <a class="ds-btn ds-btn-outline" href="../UserInteractive/MainPage.php">Nee, annuleren</a>
        </form>
    </div>
</section>

<?php
// Als de uitlog knop is ingedrukt
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_logout'])) {
    session_start();
    
    // Sessie opschonen
    $_SESSION = array();
    
    // Sessie cookie verwijderen
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    // Sessie vernietigen
    session_destroy();
    
    // Terugsturen naar de homepagina
    header("Location: ../../index.php");
    exit();
}

require_once __DIR__ . '/../includes/layout/footer.php';
?>
