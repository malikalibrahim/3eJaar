<?php
require "db.php";


Class Admin {
public $pdo;



public function __construct($db) {
$this->pdo = $db;
    // Zorg dat de mededelingen-tabel bestaat om runtime errors te voorkomen
    $this->ensureMededelingenTable();
}

public function LoginAdmin($email) {
    $stmt = $this->pdo->prepare("SELECT * FROM admin WHERE AdminEmail = :email");
    $stmt->execute(['email' => $email]); 
    return $stmt->fetch(PDO::FETCH_ASSOC); 
}

public function RegisterAdmin($name, $email, $password) {
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $this->pdo->prepare("INSERT INTO admin (AdminName, AdminEmail, AdminPsw) VALUES (:name, :email, :password)");
    return $stmt->execute(['name'=> $name, 'email' => $email, 'password' => $hashedPassword]);
}

 public function login($name) {
        $stmt = $this->pdo->prepare("SELECT * FROM admin WHERE AdminName = :name");
        $stmt->execute(['name' => $name]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getTerms() {
        $stmt = $this->pdo->query("SELECT AdminTerms FROM admin LIMIT 1");
        return $stmt ? $stmt->fetchColumn() : null;
    }

    public function updateTerms($terms) {
        // simpele implementatie: update eerste admin-record
        $stmt = $this->pdo->prepare("UPDATE admin SET AdminTerms = :terms LIMIT 1");
        return $stmt->execute(['terms' => $terms]);
    }

    private function ensureMededelingenTable() {
        // Maak de mededelingen tabel aan als deze ontbreekt (voorkomt PDO 42S02 fouten)
        $sql = "
            CREATE TABLE IF NOT EXISTS mededelingen (
                id INT AUTO_INCREMENT PRIMARY KEY,
                titel VARCHAR(255) NOT NULL,
                inhoud TEXT NOT NULL,
                admin_id INT NULL,
                target_audience VARCHAR(50) DEFAULT 'alle',
                is_urgent TINYINT(1) DEFAULT 0,
                datum_aangemaakt DATETIME DEFAULT CURRENT_TIMESTAMP,
                datum_bewerkt DATETIME NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ";
        $this->pdo->exec($sql);
    }

//MEDEDELINGEN METHODS

public function createMededeling($titel, $inhoud, $admin_id, $target_audience = 'alle', $is_urgent = false) {
    $stmt = $this->pdo->prepare(
        "INSERT INTO mededelingen (titel, inhoud, admin_id, target_audience, is_urgent) 
         VALUES (:titel, :inhoud, :admin_id, :target_audience, :is_urgent)"
    );
    return $stmt->execute([
        'titel' => $titel,
        'inhoud' => $inhoud,
        'admin_id' => $admin_id,
        'target_audience' => $target_audience,
        'is_urgent' => $is_urgent ? 1 : 0
    ]);
}

public function getMededelingen($target_audience = null, $limit = 50) {
    if ($target_audience && $target_audience !== 'alle') {
        $sql = "SELECT * FROM mededelingen 
                WHERE target_audience = :target_audience OR target_audience = 'alle'
                ORDER BY is_urgent DESC, datum_aangemaakt DESC 
                LIMIT :limit";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':target_audience', $target_audience, PDO::PARAM_STR);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    } else {
        $sql = "SELECT * FROM mededelingen 
                ORDER BY is_urgent DESC, datum_aangemaakt DESC 
                LIMIT :limit";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    }
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

public function getMededelingById($id) {
    $stmt = $this->pdo->prepare("SELECT * FROM mededelingen WHERE id = :id");
    $stmt->execute(['id' => $id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

public function updateMededeling($id, $titel, $inhoud, $target_audience, $is_urgent) {
    $stmt = $this->pdo->prepare(
        "UPDATE mededelingen 
         SET titel = :titel, inhoud = :inhoud, target_audience = :target_audience, 
             is_urgent = :is_urgent, datum_bewerkt = NOW()
         WHERE id = :id"
    );
    return $stmt->execute([
        'id' => $id,
        'titel' => $titel,
        'inhoud' => $inhoud,
        'target_audience' => $target_audience,
        'is_urgent' => $is_urgent ? 1 : 0
    ]);
}

public function deleteMededeling($id) {
    $stmt = $this->pdo->prepare("DELETE FROM mededelingen WHERE id = :id");
    return $stmt->execute(['id' => $id]);
}
}
