<?php
require "db.php";


Class Teachers {
public $pdo;



public function __construct($db) {
$this->pdo = $db;
}

public function LoginTeacher($email) {
    $stmt = $this->pdo->prepare("SELECT * FROM teachers WHERE TeachersEmail = :email");
    $stmt->execute(['email' => $email]); 
    return $stmt->fetch(PDO::FETCH_ASSOC); 
}

public function RegisterTeacher($name, $email, $password) {
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $this->pdo->prepare("INSERT INTO Teachers (TeachersName, TeachersEmail, TeachersPsw) VALUES (:name, :email, :password)");
    return $stmt->execute(['name'=> $name, 'email' => $email, 'password' => $hashedPassword]);

}


}






?>
