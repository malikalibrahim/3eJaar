<?php
require_once 'db.php';
require_once 'User-class.php';

$student = new Student($pdo);
$message = '';
$messageType = 'warn';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $age = $_POST['age'] ?? '';            
    $address = $_POST['address'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    if ($name === '') {
        $message = 'Name required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Valid email required';
    } elseif (strlen($password) < 6) {
        $message = 'Password must be at least 6 characters';
    } elseif ($password !== $password_confirm) {
        $message = 'Passwords do not match';
    } elseif ($student->emailExists($email)) {
        $message = 'Email already used';
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $id = $student->create([
            'name' => $name,
            'age' => $age,                
            'address' => $address,
            'phone' => $phone,
            'email' => $email,
            'password_hash' => $hash
        ]);
        if ($id > 0) {
            header('Location: login.php');
            exit;
        } else {
            $message = 'Could not create account';
        }
    }
}

$pageTitle = 'Leerling registreren';
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-section">
    <h1 class="ds-section-title" style="margin-top:0;">Registreren</h1>
    <div class="ds-card" style="max-width: 720px;">
        <?php if ($message): ?>
            <div class="ds-pill <?= $message === 'Could not create account' || str_contains(strtolower($message), 'error') ? 'warn' : 'info' ?>" style="display:block; margin-bottom:10px;">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>
        <form method="post" class="ds-form">
            <div class="ds-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));">
                <div>
                    <label>Name</label>
                    <input name="name" type="text" class="ds-input" required value="<?= htmlspecialchars($name ?? '') ?>">
                </div>
                <div>
                    <label>Age</label>
                    <input name="age" type="number" class="ds-input" required value="<?= htmlspecialchars($age ?? '') ?>">
                </div>
            </div>
            <div>
                <label>Address</label>
                <input name="address" type="text" class="ds-input" required value="<?= htmlspecialchars($address ?? '') ?>">
            </div>
            <div class="ds-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));">
                <div>
                    <label>Phone</label>
                    <input name="phone" type="text" class="ds-input" required value="<?= htmlspecialchars($phone ?? '') ?>">
                </div>
                <div>
                    <label>Email</label>
                    <input name="email" type="email" class="ds-input" required value="<?= htmlspecialchars($email ?? '') ?>">
                </div>
            </div>
            <div class="ds-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));">
                <div>
                    <label>Password</label>
                    <input name="password" type="password" class="ds-input" required>
                </div>
                <div>
                    <label>Confirm password</label>
                    <input name="password_confirm" type="password" class="ds-input" required>
                </div>
            </div>
            <div class="ds-stack" style="justify-content: space-between;">
                <a class="ds-btn ds-btn-outline" href="login.php">Terug naar login</a>
                <button type="submit" class="ds-btn ds-btn-primary">Account aanmaken</button>
            </div>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
