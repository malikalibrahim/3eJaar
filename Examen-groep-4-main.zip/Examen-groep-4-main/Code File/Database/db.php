<?php
/**
 * Centrale DB bootstrap.
 * - Houdt dezelfde PDO in leven in $pdo (voor oudere code die dat verwacht).
 * - Biedt een simpele DB helper class met een run() methode voor prepared statements.
 */

$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'drivesmart';

// Hergebruik een bestaande PDO als die er al is (ingeladen via config.php bijvoorbeeld)
if (!isset($pdo) || !($pdo instanceof PDO)) {
    try {
        $pdo = new PDO(
            "mysql:host=$db_host;dbname=$db_name;charset=utf8",
            $db_user,
            $db_pass,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]
        );
    } catch (PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
}

/**
 * Eenvoudige helper voor prepared statements.
 * Gebruik: $db = new DB(); $db->run("SELECT * FROM users WHERE id=:id", ["id" => 1]);
 * In een setup met meerdere db-bestanden voorkomen we dubbele class-definitie.
 */
if (!class_exists('DB')) {
    class DB {
        private PDO $pdo;

        public function __construct(PDO $pdo = null) {
            // Gebruik globale $pdo als er geen specifieke verbinding wordt meegegeven
            if ($pdo instanceof PDO) {
                $this->pdo = $pdo;
            } else {
                global $pdo;
                $this->pdo = $pdo;
            }
        }

        /**
         * Prepare + execute in één en geef de statement terug.
         */
        public function run(string $sql, array $params = []): PDOStatement {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        }

        public function pdo(): PDO {
            return $this->pdo;
        }
    }
}
