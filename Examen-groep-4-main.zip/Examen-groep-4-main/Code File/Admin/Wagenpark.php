<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../Database/login.php');
    exit;
}
require_once __DIR__ . '/../../Database/database.php';

$db = new Database('127.0.0.1', 'drivesmart', 'root', '');
$pdo = $db->getPdo();

// Zorg dat de kolom AssignedTeacher bestaat om PDO-fouten te voorkomen
try {
    $pdo->query("ALTER TABLE cars ADD COLUMN IF NOT EXISTS AssignedTeacher INT NULL");
} catch (PDOException $e) {
    // Ignoreren als de databaseversie IF NOT EXISTS niet ondersteunt; proberen we bij select te vermijden
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $type = trim($_POST['type'] ?? '');
        $license = trim($_POST['license'] ?? '');
        if ($type !== '') {
            $sql = "INSERT INTO cars (CarsType, CarsWear, CarsUsed, CarsODO, CarsMaintenance, Carlicensep)
                    VALUES (:type, '', 0, 0, 0, :license)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':type' => $type, ':license' => $license ?: null]);
        }
    }

    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $stmt = $pdo->prepare("DELETE FROM cars WHERE idCars = :id");
            $stmt->execute([':id' => $id]);
        }
    }

    if ($action === 'toggle_maint') {
        $id = (int)($_POST['id'] ?? 0);
        $new = (int)($_POST['value'] ?? 0);
        if ($id) {
            $stmt = $pdo->prepare("UPDATE cars SET CarsMaintenance = :m WHERE idCars = :id");
            $stmt->execute([':m' => $new, ':id' => $id]);
        }
    }

    if ($action === 'assign_teacher') {
        $car_id = (int)($_POST['car_id'] ?? 0);
        $teacher_id = (int)($_POST['teacher_id'] ?? 0);
        if ($car_id) {
            $stmt = $pdo->prepare("UPDATE cars SET AssignedTeacher = :teacher WHERE idCars = :id");
            $stmt->execute([':teacher' => $teacher_id ?: null, ':id' => $car_id]);
        }
    }

    header('Location: Wagenpark.php');
    exit;
}

// Haal alle auto's op, probeer AssignedTeacher, zo niet fallback zonder die kolom
try {
    $stmt = $pdo->query("SELECT idCars, CarsType, CarsWear, CarsUsed, CarsMaintenance, CarsODO, Carlicensep, AssignedTeacher FROM cars ORDER BY idCars");
    $cars = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $stmt = $pdo->query("SELECT idCars, CarsType, CarsWear, CarsUsed, CarsMaintenance, CarsODO, Carlicensep FROM cars ORDER BY idCars");
    $cars = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // vul lege kolom zodat template niet breekt
    foreach ($cars as &$c) {
        $c['AssignedTeacher'] = null;
    }
}

// Haal alle instructeurs op
$stmt = $pdo->query("SELECT idTeachers, TeachersName FROM teachers ORDER BY TeachersName");
$teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Wagenpark - Admin';
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-hero">
    <div>
        <div class="ds-tag">Admin • Wagenpark</div>
        <h1>Beheer het wagenpark</h1>
        <p>Voeg auto's toe, beheer onderhoud en koppel ze aan instructeurs.</p>
    </div>
    <div class="ds-card">
        <h3 class="ds-section-title" style="margin-top:0;">Snelle links</h3>
        <ul style="padding-left:16px; margin:0; color:var(--muted); line-height:1.6;">
            <li><a href="HomepageAdmin.php">Dashboard</a></li>
            <li><a href="Mededeling.php">Mededelingen</a></li>
            <li><a href="lespakketen.php">Lespakketten</a></li>
        </ul>
    </div>
</section>

<section class="ds-section">
    <h2 class="ds-section-title">Nieuwe auto toevoegen</h2>
    <div class="ds-card" style="max-width: 640px;">
        <form method="post" class="ds-form">
            <input type="hidden" name="action" value="add">
            <div>
                <label>Type</label>
                <input name="type" type="text" class="ds-input" placeholder="Type (bv. BMW)" required>
            </div>
            <div>
                <label>Kenteken (optioneel)</label>
                <input name="license" type="text" class="ds-input" placeholder="Bijv. AB-CD-EF">
            </div>
            <div class="ds-stack" style="justify-content: flex-end;">
                <button type="submit" class="ds-btn ds-btn-primary">Toevoegen</button>
            </div>
        </form>
    </div>
</section>

<section class="ds-section">
    <h2 class="ds-section-title">Overzicht auto's</h2>
    <div class="ds-card">
        <?php if (empty($cars)): ?>
            <p class="ds-text-muted">Nog geen auto's geregistreerd.</p>
        <?php else: ?>
            <table class="ds-table">
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>Kenteken</th>
                        <th>ODO</th>
                        <th>Onderhoud</th>
                        <th>Toegewezen</th>
                        <th>Acties</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cars as $c): ?>
                        <tr>
                            <td><?= htmlspecialchars($c['CarsType']) ?></td>
                            <td><?= htmlspecialchars($c['Carlicensep'] ?? '-') ?></td>
                            <td><?= (int)($c['CarsODO'] ?? 0) ?> km</td>
                            <td>
                                <?php if (!empty($c['CarsMaintenance'])): ?>
                                    <span class="ds-pill warn">Onderhoud</span>
                                <?php else: ?>
                                    <span class="ds-pill success">OK</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                    $assignedName = '-';
                                    if (!empty($c['AssignedTeacher'])) {
                                        foreach ($teachers as $t) {
                                            if ((int)$t['idTeachers'] === (int)$c['AssignedTeacher']) {
                                                $assignedName = $t['TeachersName'];
                                                break;
                                            }
                                        }
                                    }
                                    echo htmlspecialchars($assignedName);
                                ?>
                            </td>
                            <td>
                                <div class="ds-stack">
                                    <form method="post" style="margin:0;">
                                        <input type="hidden" name="action" value="toggle_maint">
                                        <input type="hidden" name="id" value="<?= (int)$c['idCars'] ?>">
                                        <input type="hidden" name="value" value="<?= $c['CarsMaintenance'] ? 0 : 1 ?>">
                                        <button type="submit" class="ds-btn ds-btn-outline">
                                            <?= $c['CarsMaintenance'] ? 'Markeer OK' : 'Onderhoud' ?>
                                        </button>
                                    </form>
                                    <form method="post" style="margin:0;" onsubmit="return confirm('Verwijder deze auto?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?= (int)$c['idCars'] ?>">
                                        <button type="submit" class="ds-btn ds-btn-outline">Verwijder</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</section>

<section class="ds-section">
    <h2 class="ds-section-title">Auto toewijzen aan instructeur</h2>
    <div class="ds-card" style="max-width: 720px;">
        <form method="post" class="ds-form">
            <input type="hidden" name="action" value="assign_teacher">
            <div>
                <label>Selecteer auto</label>
                <select name="car_id" class="ds-select" required>
                    <option value="">-- Kies een auto --</option>
                    <?php foreach ($cars as $c): ?>
                        <option value="<?= (int)$c['idCars'] ?>">
                            <?= htmlspecialchars($c['CarsType']) ?> - <?= htmlspecialchars($c['Carlicensep'] ?? 'Geen kenteken') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label>Selecteer instructeur</label>
                <select name="teacher_id" class="ds-select" required>
                    <option value="0">-- Geen (verwijder toewijzing) --</option>
                    <?php foreach ($teachers as $t): ?>
                        <option value="<?= (int)$t['idTeachers'] ?>">
                            <?= htmlspecialchars($t['TeachersName']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="ds-stack" style="justify-content: flex-end;">
                <button type="submit" class="ds-btn ds-btn-primary">Auto toewijzen</button>
            </div>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
