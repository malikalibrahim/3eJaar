<?php
session_start();
$Admin_Name = $_SESSION['admin_name'] ?? ($_SESSION['user_name'] ?? 'Onbekend');
$Admin_ID = $_SESSION['admin_id'] ?? null;
if (!$Admin_ID) {
    header('Location: ../Database/login.php');
    exit;
}

require_once __DIR__ . '/../Database/db.php';
require_once __DIR__ . '/../Database/Admin-class.php';

$admin = new Admin($pdo);

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        try {
            if ($_POST['action'] === 'create') {
                $titel = trim($_POST['titel'] ?? '');
                $inhoud = trim($_POST['inhoud'] ?? '');
                $target_audience = $_POST['target_audience'] ?? 'alle';
                $is_urgent = isset($_POST['is_urgent']) ? 1 : 0;

                if (empty($titel) || empty($inhoud)) {
                    throw new Exception('Titel en inhoud zijn verplicht.');
                }

                if (empty($Admin_ID)) {
                    throw new Exception('Admin niet ingelogd.');
                }

                if ($admin->createMededeling($titel, $inhoud, $Admin_ID, $target_audience, $is_urgent)) {
                    $message = 'Mededeling succesvol aangemaakt!';
                    $messageType = 'success';
                    $_POST = [];
                } else {
                    throw new Exception('Fout bij het aanmaken van de mededeling.');
                }
            } elseif ($_POST['action'] === 'update') {
                $id = (int)$_POST['id'];
                $titel = trim($_POST['titel'] ?? '');
                $inhoud = trim($_POST['inhoud'] ?? '');
                $target_audience = $_POST['target_audience'] ?? 'alle';
                $is_urgent = isset($_POST['is_urgent']) ? 1 : 0;

                if (empty($titel) || empty($inhoud)) {
                    throw new Exception('Titel en inhoud zijn verplicht.');
                }

                if ($admin->updateMededeling($id, $titel, $inhoud, $target_audience, $is_urgent)) {
                    $message = 'Mededeling succesvol bijgewerkt!';
                    $messageType = 'success';
                    header('Location: Mededeling.php');
                    exit;
                } else {
                    throw new Exception('Fout bij het bijwerken van de mededeling.');
                }
            } elseif ($_POST['action'] === 'delete') {
                $id = (int)$_POST['id'];
                if ($admin->deleteMededeling($id)) {
                    $message = 'Mededeling succesvol verwijderd!';
                    $messageType = 'success';
                } else {
                    throw new Exception('Fout bij het verwijderen van de mededeling.');
                }
            }
        } catch (Exception $e) {
            $message = $e->getMessage();
            $messageType = 'error';
        }
    }
}
$editId = isset($_GET['edit']) ? (int)$_GET['edit'] : null;
$editData = null;
if ($editId) {
    $editData = $admin->getMededelingById($editId);
}

$mededelingen = $admin->getMededelingen();

$pageTitle = 'Mededelingen Beheren - DriveSmart';
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-section">
    <h1 class="ds-section-title" style="margin-top:0;">Mededelingen beheren</h1>
    <p class="ds-text-muted">Ingelogd als: <strong><?= htmlspecialchars($Admin_Name) ?></strong></p>

    <?php if (!empty($message)): ?>
        <div class="ds-pill <?= $messageType === 'success' ? 'success' : 'warn' ?>" style="display:block; margin-bottom:10px;">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <div class="ds-grid" style="grid-template-columns: 1.2fr 1fr; align-items: start;">
        <div class="ds-card">
            <h3 class="ds-section-title" style="margin-top:0;"><?= $editId ? 'Mededeling bewerken' : 'Nieuwe mededeling' ?></h3>
            <form method="POST" class="ds-form">
                <input type="hidden" name="action" value="<?= $editId ? 'update' : 'create' ?>">
                <?php if ($editId): ?>
                    <input type="hidden" name="id" value="<?= $editId ?>">
                <?php endif; ?>

                <div>
                    <label for="titel">Titel *</label>
                    <input type="text" id="titel" name="titel" class="ds-input" required maxlength="255"
                           value="<?= $editData ? htmlspecialchars($editData['titel']) : '' ?>"
                           placeholder="Bijv. Rijschool gesloten op maandag">
                </div>

                <div>
                    <label for="inhoud">Inhoud *</label>
                    <textarea id="inhoud" name="inhoud" class="ds-textarea" required rows="6"
                              placeholder="Voer hier uw mededeling in..."><?= $editData ? htmlspecialchars($editData['inhoud']) : '' ?></textarea>
                </div>

                <div class="ds-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));">
                    <div>
                        <label for="target_audience">Zichtbaar voor *</label>
                        <select id="target_audience" name="target_audience" class="ds-select" required>
                            <option value="alle" <?= (!$editData || $editData['target_audience'] === 'alle') ? 'selected' : '' ?>>Iedereen</option>
                            <option value="instructeurs" <?= ($editData && $editData['target_audience'] === 'instructeurs') ? 'selected' : '' ?>>Alleen Instructeurs</option>
                            <option value="studenten" <?= ($editData && $editData['target_audience'] === 'studenten') ? 'selected' : '' ?>>Alleen Studenten</option>
                        </select>
                    </div>

                    <div class="ds-stack" style="align-items:center; margin-top: 8px;">
                        <label style="display:flex; gap:8px; align-items:center;">
                            <input type="checkbox" name="is_urgent" value="1"
                                   <?= ($editData && $editData['is_urgent']) ? 'checked' : '' ?>>
                            Urgent
                        </label>
                    </div>
                </div>

                <div class="ds-stack" style="justify-content: flex-end;">
                    <button type="submit" class="ds-btn ds-btn-primary"><?= $editId ? 'Bijwerken' : 'Plaatsen' ?></button>
                    <?php if ($editId): ?>
                        <a href="Mededeling.php" class="ds-btn ds-btn-outline">Annuleren</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <div class="ds-card">
            <h3 class="ds-section-title" style="margin-top:0;">Alle Mededelingen (<?= count($mededelingen); ?>)</h3>
            <?php if (empty($mededelingen)): ?>
                <p class="ds-text-muted">Nog geen mededelingen geplaatst.</p>
            <?php else: ?>
                <div class="ds-grid">
                    <?php foreach ($mededelingen as $med): ?>
                        <div class="ds-card" style="box-shadow:none; border:1px solid var(--border);">
                            <div class="ds-stack" style="justify-content: space-between; align-items:center;">
                                <h4 style="margin:0;"><?= htmlspecialchars($med['titel']); ?></h4>
                                <span class="ds-pill <?= $med['is_urgent'] ? 'warn' : 'info' ?>">
                                    <?= $med['is_urgent'] ? 'URGENT' : ucfirst(str_replace('_', ' ', $med['target_audience'])) ?>
                                </span>
                            </div>
                            <p class="ds-text-muted" style="margin:8px 0 6px;"><?= nl2br(htmlspecialchars(substr($med['inhoud'], 0, 200))); ?><?= strlen($med['inhoud']) > 200 ? '...' : ''; ?></p>
                            <small class="ds-text-muted"><?= date('d-m-Y H:i', strtotime($med['datum_aangemaakt'])); ?></small>
                            <div class="ds-stack" style="margin-top:8px; justify-content: flex-end;">
                                <a href="Mededeling.php?edit=<?= $med['id']; ?>" class="ds-btn ds-btn-outline">Bewerken</a>
                                <form method="POST" style="margin:0;" onsubmit="return confirm('Weet u zeker dat u deze mededeling wilt verwijderen?');">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= $med['id']; ?>">
                                    <button type="submit" class="ds-btn ds-btn-primary">Verwijderen</button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
