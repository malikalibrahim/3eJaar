<?php
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/admin-class.php';
$admin = new Admin();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $terms = $_POST['terms'] ?? '';
    $admin->updateTerms($terms);
    $message = 'Voorwaarden opgeslagen.';
}

$currentTerms = $admin->getTerms();
$pageTitle = 'Algemene voorwaarden';
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-section">
    <h1 class="ds-section-title" style="margin-top:0;">Algemene voorwaarden beheren</h1>
    <div class="ds-card" style="max-width: 900px;">
        <?php if ($message): ?>
            <div class="ds-pill success" style="display:block; margin-bottom:10px;"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        <form method="post" class="ds-form">
            <div>
                <label class="form-label">Inhoud voorwaarden</label>
                <textarea name="terms" class="ds-textarea" rows="10"><?= htmlspecialchars($currentTerms ?? '') ?></textarea>
            </div>
            <div class="ds-stack" style="justify-content: space-between;">
                <a href="HomepageAdmin.php" class="ds-btn ds-btn-outline">Terug</a>
                <button type="submit" class="ds-btn ds-btn-primary">Opslaan</button>
            </div>
        </form>
    </div>
</section>

<section class="ds-section">
    <h2 class="ds-section-title">Gepubliceerde voorwaarden</h2>
    <div class="ds-card">
        <pre style="white-space: pre-wrap; margin:0; font-family: Arial, sans-serif;"><?= htmlspecialchars($currentTerms ?? '') ?></pre>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
