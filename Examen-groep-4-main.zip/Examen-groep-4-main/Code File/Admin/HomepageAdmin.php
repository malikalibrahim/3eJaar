<?php
session_start();
require_once __DIR__ . '/../../Database/database.php';
require_once __DIR__ . '/../Classes/Schedule.php';
require_once __DIR__ . '/../Classes/Lesson.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$db = new Database('127.0.0.1', 'drivesmart', 'root', '');
$pdo = $db->getPdo();

$schedule = new Schedule($pdo);
$lesson = new Lesson($pdo);

$todaySchedule = $schedule->getToday();
$lessons = $lesson->getAll();
$adminName = $_SESSION['admin_name'] ?? 'Admin';
$pageTitle = 'DriveSmart - Admin';
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-hero">
    <div>
        <div class="ds-tag">Admin dashboard</div>
        <h1>Welkom, <?= htmlspecialchars($adminName) ?></h1>
        <p>Beheer mededelingen, wagenpark, pakketten en voorwaarden vanuit één plek.</p>
        <div class="ds-stack">
            <a class="ds-btn ds-btn-primary" href="Mededeling.php">Mededelingen</a>
            <a class="ds-btn ds-btn-outline" href="Wagenpark.php">Wagenpark</a>
            <a class="ds-btn ds-btn-outline" href="lespakketen.php">Lespakketten</a>
        </div>
    </div>
    <div class="ds-card">
        <h3 class="ds-section-title" style="margin-top:0;">Snelle links</h3>
        <ul style="padding-left:16px; margin:0; color:var(--muted); line-height:1.6;">
            <li><a href="terms.php">Algemene voorwaarden</a></li>
            <li><a href="../Database/logout.php">Uitloggen</a></li>
        </ul>
    </div>
</section>

<section class="ds-section">
    <h2 class="ds-section-title">Vandaag in het rooster</h2>
    <div class="ds-card">
        <?php if (empty($todaySchedule)): ?>
            <p class="ds-text-muted">Geen lessen gepland voor vandaag.</p>
        <?php else: ?>
            <table class="ds-table">
                <thead>
                    <tr>
                        <th>Datum/tijd</th>
                        <th>Student</th>
                        <th>Instructeur</th>
                        <th>Onderwerp</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($todaySchedule as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['ScheduleDateTime'] ?? '') ?></td>
                            <td><?= htmlspecialchars($item['StudentsName'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($item['TeachersName'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($item['ScheduleSubject'] ?? '-') ?></td>
                            <td><span class="ds-pill info"><?= htmlspecialchars($item['ScheduleStatus'] ?? 'planned') ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
