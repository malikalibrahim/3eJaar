<?php
require_once __DIR__ . '/../Database/db.php';
session_start();

if (isset($_SESSION['admin_id'])) {
    header('Location: HomepageAdmin.php');
    exit;
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($name) || empty($password)) {
        $error = 'Vul alle velden in.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM admin WHERE AdminName = :name");
        $stmt->execute(['name' => $name]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['AdminPsw'])) {
            $_SESSION['admin_id'] = $admin['idAdmin'];
            $_SESSION['admin_name'] = $admin['AdminName'];
            $_SESSION['user_id'] = $admin['idAdmin'];
            $_SESSION['user_name'] = $admin['AdminName'];
            $_SESSION['role'] = 'admin';
            header('Location: HomepageAdmin.php');
            exit;
        } else {
            $error = 'Ongeldige inloggegevens.';
    }
}}

$pageTitle = "Admin Inloggen";
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-section">
    <h1 class="ds-section-title" style="margin-top:0;">Admin inloggen</h1>
    <div class="ds-card" style="max-width: 520px;">
        <?php if ($error): ?>
            <div class="ds-pill warn" style="display:block; margin-bottom:10px;"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="post" class="ds-form">
            <div>
                <label for="name">Gebruikersnaam</label>
                <input type="text" id="name" name="name" class="ds-input" required>
            </div>
            <div>
                <label for="password">Wachtwoord</label>
                <input type="password" id="password" name="password" class="ds-input" required>
            </div>
            <div class="ds-stack" style="justify-content: flex-end;">
                <button type="submit" class="ds-btn ds-btn-primary">Inloggen</button>
            </div>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
