<?php
session_start();

if (!isset($_SESSION['custom_packages'])) {
    $_SESSION['custom_packages'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lessons = $_POST['lessons'] ?? '';
    $price = $_POST['price'] ?? '';
    
    if (!empty($lessons) && !empty($price) && $lessons > 0 && $price > 0) {
        $_SESSION['custom_packages'][] = [
            'lessons' => $lessons,
            'price' => $price
        ];
    }
}

$pageTitle = 'Lespakketten - Admin';
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-hero">
    <div>
        <div class="ds-tag">Admin • Lespakketten</div>
        <h1>Beheer rijlespakketten</h1>
        <p>Voeg nieuwe pakketten toe of pas prijzen aan zodat leerlingen meteen de juiste opties zien.</p>
    </div>
    <div class="ds-card">
        <h3 class="ds-section-title" style="margin-top:0;">Snel naar</h3>
        <ul style="padding-left:16px; margin:0; color:var(--muted); line-height:1.6;">
            <li><a href="HomepageAdmin.php">Dashboard</a></li>
            <li><a href="Wagenpark.php">Wagenpark</a></li>
            <li><a href="Mededeling.php">Mededelingen</a></li>
        </ul>
    </div>
</section>

<section class="ds-section">
    <h2 class="ds-section-title">Nieuw pakket</h2>
    <div class="ds-card" style="max-width: 640px;">
        <form method="POST" class="ds-form">
            <div>
                <label for="lessons">Aantal rijlessen</label>
                <input type="number" id="lessons" name="lessons" min="1" class="ds-input" placeholder="bijv. 10" required>
            </div>
            <div>
                <label for="price">Prijs (€)</label>
                <input type="number" id="price" name="price" min="0" class="ds-input" placeholder="bijv. 600" required>
            </div>
            <div class="ds-stack" style="justify-content: flex-end;">
                <button type="submit" class="ds-btn ds-btn-primary">Pakket toevoegen</button>
            </div>
        </form>
    </div>
</section>

<section class="ds-section">
    <h2 class="ds-section-title">Beschikbare pakketten</h2>
    <div class="ds-grid">
        <div class="ds-card">
            <h3>Basis pakket</h3>
            <p class="ds-text-muted">10 rijlessen van 50 min.</p>
            <strong>€599</strong>
        </div>
        <div class="ds-card">
            <h3>Standaard pakket</h3>
            <p class="ds-text-muted">30 rijlessen + praktijkexamen</p>
            <strong>€2000</strong>
        </div>
        <div class="ds-card">
            <h3>Compleet pakket</h3>
            <p class="ds-text-muted">40 rijlessen + praktijkexamen</p>
            <strong>€2400</strong>
        </div>
        <?php foreach ($_SESSION['custom_packages'] as $package): ?>
            <div class="ds-card">
                <h3>Eigen pakket</h3>
                <p class="ds-text-muted"><?= htmlspecialchars($package['lessons']) ?> rijlessen van 50 min.</p>
                <strong>€<?= htmlspecialchars($package['price']) ?></strong>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
