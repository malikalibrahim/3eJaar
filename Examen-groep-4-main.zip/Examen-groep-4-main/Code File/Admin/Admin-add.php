<?php
require_once __DIR__ . '/../Instructor/teacher-class.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$teacher = new Teacher();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name'] ?? '');
    $email = htmlspecialchars($_POST['email'] ?? '');
    $phone = htmlspecialchars($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($name === '' || $email === '' || $phone === '' || $password === '') {
        $message = 'Vul alle velden in.';
    } else {
        $teacher->create($name, $email, $phone, $password);
        $message = 'Instructeur-account is aangemaakt.';
    }
}

$pageTitle = "Instructeur aanmaken";
require_once __DIR__ . '/../includes/layout/header.php';
?>

<section class="ds-section">
    <h1 class="ds-section-title" style="margin-top:0;">Instructeur aanmaken</h1>
    <div class="ds-card" style="max-width: 720px;">
        <?php if ($message): ?>
            <div class="ds-pill success" style="display:block; margin-bottom:10px;"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        <form method="post" class="ds-form">
            <div class="ds-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));">
                <div>
                    <label>Naam</label>
                    <input type="text" name="name" class="ds-input" required>
                </div>
                <div>
                    <label>E-mail</label>
                    <input type="email" name="email" class="ds-input" required>
                </div>
            </div>
            <div class="ds-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));">
                <div>
                    <label>Telefoon</label>
                    <input type="text" name="phone" class="ds-input" required>
                </div>
                <div>
                    <label>Wachtwoord</label>
                    <input type="password" name="password" class="ds-input" required>
                </div>
            </div>
            <div class="ds-stack" style="justify-content: flex-end;">
                <button type="submit" class="ds-btn ds-btn-primary">Aanmaken</button>
            </div>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
