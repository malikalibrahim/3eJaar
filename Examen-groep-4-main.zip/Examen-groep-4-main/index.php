<?php
$pageTitle = 'DriveSmart - Rijschool';
require_once __DIR__ . '/Code File/includes/layout/header.php';
?>

<section class="ds-hero" style="background: linear-gradient(135deg, rgba(13,71,161,0.9), rgba(85,107,47,0.85)), url('https://images.unsplash.com/photo-1503736334956-4c8f8e92946d?auto=format&fit=crop&w=1400&q=80') center/cover no-repeat;">
    <div>
        <div class="ds-tag">Samen vooruit</div>
        <h1>Rij veilig en zeker met DriveSmart</h1>
        <p>Professionele rijlessen met aandacht voor jouw tempo. Kies voor ervaring, moderne auto's en een persoonlijke aanpak.</p>
        <div class="ds-stack">
            <a class="ds-btn ds-btn-primary" href="Code File/Database/login.php">Inloggen</a>
            <a class="ds-btn ds-btn-outline" href="Code File/Database/User-register.php">Start met lessen</a>
        </div>
    </div>
    <div class="ds-card" style="background: #0d47a1; color:#fff; border: none;">
        <h3 class="ds-section-title" style="margin-top:0; color:#fff;">Klaar om te starten?</h3>
        <p class="ds-text-muted" style="color:#e8f0ff;">Log in of registreer om te plannen.</p>
        <div class="ds-stack">
            <a class="ds-btn ds-btn-primary" href="Code File/Database/login.php">Log in</a>
            <a class="ds-btn ds-btn-outline" href="Code File/Database/User-register.php">Registreer leerling</a>
        </div>
    </div>
</section>

<section class="ds-section">
    <h2 class="ds-section-title">Waarom onze rijschool?</h2>
    <div class="ds-grid">
        <div class="ds-card">
            <img src="https://images.unsplash.com/photo-1522778119026-d647f0596c20?auto=format&fit=crop&w=800&q=70" alt="Instructeur" style="width:100%; border-radius:8px; margin-bottom:10px;">
            <h3>Ervaren team</h3>
            <p class="ds-text-muted">Gecertificeerde instructeurs met jaren praktijkervaring.</p>
        </div>
        <div class="ds-card">
            <img src="https://images.unsplash.com/photo-1503736334956-4c8f8e92946d?auto=format&fit=crop&w=800&q=70" alt="Wagenpark" style="width:100%; border-radius:8px; margin-bottom:10px;">
            <h3>Modern wagenpark</h3>
            <p class="ds-text-muted">Auto's met de nieuwste veiligheidsopties en aanpassingen.</p>
        </div>
        <div class="ds-card">
            <img src="https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&w=800&q=70" alt="Persoonlijk plan" style="width:100%; border-radius:8px; margin-bottom:10px;">
            <h3>Persoonlijk plan</h3>
            <p class="ds-text-muted">Lesplan op maat, ook voor leerlingen met een beperking.</p>
        </div>
        <div class="ds-card">
            <img src="https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=800&q=70" alt="Heldere prijzen" style="width:100%; border-radius:8px; margin-bottom:10px;">
            <h3>Heldere prijzen</h3>
            <p class="ds-text-muted">Transparant, zonder verborgen kosten.</p>
        </div>
    </div>
</section>

<section class="ds-section">
    <h2 class="ds-section-title">Voor instructeurs</h2>
    <div class="ds-grid">
        <div class="ds-card">
            <h3>Week- en dagroosters</h3>
            <p class="ds-text-muted">Altijd zicht op je lessen, ophaallocaties en onderwerpen.</p>
        </div>
        <div class="ds-card">
            <h3>Mankementen melden</h3>
            <p class="ds-text-muted">Geef direct onderhoud door en houd auto's veilig.</p>
        </div>
        <div class="ds-card">
            <h3>Kilometerstanden</h3>
            <p class="ds-text-muted">Voer eenvoudig je kilometers aan het einde van de dag in.</p>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/Code File/includes/layout/footer.php'; ?>
