-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2025 at 03:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drivesmart`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `idAdmin` int(11) NOT NULL,
  `AdminName` varchar(255) NOT NULL,
  `AdminPsw` varchar(255) NOT NULL,
  `AdminEmail` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`idAdmin`, `AdminName`, `AdminPsw`, `AdminEmail`) VALUES
(1, '1', '$2y$10$GSupwQe6OvGd87WYBJG2qegzH6c1J76oIjY/0SdgrcxNuhHfgyf1q', '1@gmail.com'),
(2, 'admintest', '$2y$10$.YevqGuuKqy6ytLxq6fmrekRySbtXjOs9ddzHojgVTGB5wyV0Hfre', '2@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `idAnnouncements` int(11) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Message` varchar(500) NOT NULL,
  `TargetGroup` varchar(20) NOT NULL,
  `CreatedAt` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `idCars` int(11) NOT NULL,
  `CarsType` varchar(255) NOT NULL,
  `CarsWear` varchar(255) NOT NULL,
  `CarsUsed` tinyint(4) NOT NULL,
  `Carscol` varchar(45) DEFAULT NULL,
  `CarsODO` int(11) DEFAULT NULL,
  `CarsMaintenance` tinyint(1) DEFAULT NULL,
  `CarLicensep` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`idCars`, `CarsType`, `CarsWear`, `CarsUsed`, `Carscol`, `CarsODO`, `CarsMaintenance`, `CarLicensep`) VALUES
(2, 'BMW', '', 0, NULL, 0, 1, 'HD-21-OP'),
(3, 'Volkswagen', '', 0, NULL, 0, 0, 'AB-23-JK');

-- --------------------------------------------------------

--
-- Table structure for table `lessons`
--

CREATE TABLE `lessons` (
  `remark` varchar(255) DEFAULT NULL,
  `Subject` varchar(255) DEFAULT NULL,
  `Price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `idSchedule` int(11) NOT NULL,
  `ScheduleDateTime` datetime NOT NULL,
  `ScheduleCar` varchar(255) NOT NULL,
  `SchedulePickLoc` varchar(255) NOT NULL,
  `ScheduleStudentId` int(11) DEFAULT NULL,
  `ScheduleTeacherId` int(11) DEFAULT NULL,
  `ScheduleSubject` varchar(255) DEFAULT NULL,
  `ScheduleStatus` varchar(50) DEFAULT 'planned',
  `ScheduleCancelReason` varchar(255) DEFAULT NULL,
  `ScheduleStudentRemark` varchar(255) DEFAULT NULL,
  `ScheduleTeacherRemark` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stripcard`
--

CREATE TABLE `stripcard` (
  `idStripCard` int(11) NOT NULL,
  `StripCardAmount` int(11) NOT NULL,
  `StripCardHolder` varchar(255) NOT NULL COMMENT 'FK'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `idStudents` int(11) NOT NULL,
  `StudentsName` varchar(255) NOT NULL,
  `StudentsAge` int(11) NOT NULL,
  `StudentsAddress` varchar(255) NOT NULL,
  `StudentsPhoneNumber` int(11) NOT NULL,
  `StudentsEmail` varchar(255) NOT NULL,
  `StudentsPsw` varchar(255) NOT NULL,
  `StudentsStripCard` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`idStudents`, `StudentsName`, `StudentsAge`, `StudentsAddress`, `StudentsPhoneNumber`, `StudentsEmail`, `StudentsPsw`, `StudentsStripCard`) VALUES
(1, 'Test', 1, 'erwer', 123, 'hi@gmail.com', '$2y$10$lG/xktl5DnrMr/SvUz.WhewQIAbGknjk9KtXcJhpoXMzwiND47UIy', 0);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `idTeachers` int(11) NOT NULL,
  `TeachersName` varchar(255) NOT NULL,
  `TeachersEmail` varchar(255) NOT NULL,
  `TeachersPhoneNumber` int(11) NOT NULL,
  `TeachersPsw` varchar(255) NOT NULL,
  `Avaiblilty` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`idTeachers`, `TeachersName`, `TeachersEmail`, `TeachersPhoneNumber`, `TeachersPsw`, `Avaiblilty`) VALUES
(1, 'test teacher', '1@gmail.com', 0, '$2y$10$q5.jZPr6UG9nyPZb/emVreMXzTD3Aiirt601nu0rRPLGsRNkgpXIu', NULL),
(2, 'test teacher', '1@gmail.com', 0, '$2y$10$OQ1KQxHZKZ5mZWDxmh7BRuSoBQMK7Z9xUERTsDxC9oko8/HbXyy9q', NULL),
(3, 'Teacher', '1@gmail.com', 0, '$2y$10$O1nO0cjm0rFOJpwg1zHU0eTfNhWxUiZijzXT8SzhhIRd3jPnu2T8i', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ziekmelding`
--

CREATE TABLE `ziekmelding` (
  `idZiekmelding` int(11) NOT NULL,
  `instructeur_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `datum` date NOT NULL,
  `tijd` time NOT NULL,
  `reden` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`idAdmin`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`idAnnouncements`);

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`idCars`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`idSchedule`);

--
-- Indexes for table `stripcard`
--
ALTER TABLE `stripcard`
  ADD PRIMARY KEY (`idStripCard`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`idStudents`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`idTeachers`);

--
-- Indexes for table `ziekmelding`
--
ALTER TABLE `ziekmelding`
  ADD PRIMARY KEY (`idZiekmelding`),
  ADD KEY `instructeur_id` (`instructeur_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `idAdmin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `idAnnouncements` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `idCars` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `idSchedule` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `stripcard`
--
ALTER TABLE `stripcard`
  MODIFY `idStripCard` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `idStudents` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `idTeachers` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ziekmelding`
--
ALTER TABLE `ziekmelding`
  MODIFY `idZiekmelding` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ziekmelding`
--
ALTER TABLE `ziekmelding`
  ADD CONSTRAINT `ziekmelding_ibfk_1` FOREIGN KEY (`instructeur_id`) REFERENCES `teachers` (`idTeachers`) ON DELETE SET NULL,
  ADD CONSTRAINT `ziekmelding_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `students` (`idStudents`) ON DELETE SET NULL,
  ADD CONSTRAINT `ziekmelding_ibfk_3` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`idAdmin`) ON DELETE SET NULL;
COMMIT;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`idAnnouncements`, `Title`, `Message`, `TargetGroup`, `CreatedAt`) VALUES
(1, 'Welkom nieuwe leerlingen!', 'Beste nieuwe leerlingen, welkom bij DriveSmart! We kijken ernaar uit om jullie te helpen slagen.', 'student', '2025-12-01 10:00:00'),
(2, 'Belangrijke update lesroosters', 'Instructeurs, controleer alstublieft de nieuwe functionaliteit voor het aanpassen van lessen.', 'teacher', '2025-12-02 14:30:00'),
(3, 'Algemene mededeling', 'DriveSmart is nu ook beschikbaar op mobiel!', 'all', '2025-11-28 09:00:00');

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`idSchedule`, `ScheduleDateTime`, `ScheduleCar`, `SchedulePickLoc`, `ScheduleStudentId`, `ScheduleTeacherId`, `ScheduleSubject`, `ScheduleStatus`, `ScheduleCancelReason`, `ScheduleStudentRemark`, `ScheduleTeacherRemark`) VALUES
(1, '2025-12-10 10:00:00', 'BMW', 'School', 1, 1, 'Rijles 1', 'planned', NULL, 'Graag focussen op parkeren.', NULL),
(2, '2025-12-05 14:00:00', 'Volkswagen', 'Thuis', 1, 1, 'Rijles 2', 'done', NULL, NULL, 'Student heeft goed gepresteerd.'),
(3, '2025-12-12 11:00:00', 'BMW', 'Station', 1, 1, 'Rijles 3', 'cancelled', 'Auto in onderhoud', 'Kan ik een nieuwe afspraak maken?', NULL),
(4, '2025-12-15 09:00:00', 'BMW', 'School', 1, 1, 'Rijles 4', 'planned', NULL, NULL, NULL),
(5, '2025-12-08 13:00:00', 'Volkswagen', 'Werk', 1, 2, 'Rijles 5', 'planned', NULL, NULL, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
