<?php
// config.php - central bootstrap for the project
// Defines a project root constant and helper for path-based includes.

// PROJECT_ROOT points to the repository root (this file's folder)
define('PROJECT_ROOT', __DIR__);

/**
 * Require a file relative to the project root.
 * Usage: project_require('Code File/Database/db.php');
 */
function project_require(string $relativePath)
{
    $path = PROJECT_ROOT . '/' . ltrim($relativePath, '/\\');
    if (file_exists($path)) {
        require_once $path;
    } else {
        // Emit a warning but continue; helps debugging missing include paths
        trigger_error("project_require: file not found: $path", E_USER_WARNING);
    }
}

// Try to include the most likely db.php file so $pdo becomes available.
// The project contains multiple db files; prefer the one under Code File/Database first.
if (file_exists(PROJECT_ROOT . '/Code File/Database/db.php')) {
    require_once PROJECT_ROOT . '/Code File/Database/db.php';
} elseif (file_exists(PROJECT_ROOT . '/Database/database.php')) {
    require_once PROJECT_ROOT . '/Database/database.php';
}

// NOTE: Older versions used `Code File/Drivesmart/includes/db.php`.
// That folder was archived to `archive/Drivesmart_old` to avoid confusion.

// You can add additional global helpers/config values here as needed.
