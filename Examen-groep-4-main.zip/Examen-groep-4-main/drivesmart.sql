-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Gegenereerd op: 05 dec 2025 om 03:47
-- Serverversie: 10.4.28-MariaDB
-- PHP-versie: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drivesmart`
--
CREATE DATABASE IF NOT EXISTS `drivesmart` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `drivesmart`;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `admin`
--

CREATE TABLE `admin` (
  `idAdmin` int(11) NOT NULL,
  `AdminName` varchar(255) NOT NULL,
  `AdminPsw` varchar(255) NOT NULL,
  `AdminEmail` varchar(255) DEFAULT NULL,
  `AdminTerms` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `admin`
--

INSERT INTO `admin` (`idAdmin`, `AdminName`, `AdminPsw`, `AdminEmail`, `AdminTerms`) VALUES
(1, '1', '$2y$10$GSupwQe6OvGd87WYBJG2qegzH6c1J76oIjY/0SdgrcxNuhHfgyf1q', '1@gmail.com', 'Algemene voorwaarden praktijk auto\r\n \r\n\r\nArtikel 1: algemene voorwaarden\r\n1.1 Deze voorwaarden zijn van toepassing op alle lespakketten, inclusief aanbiedingen van Rijschool Amsterdam B.V. gevestigd te Amsterdam, Den Brielstraat 4b, hierna te noemen rijschool.\r\n1.2 Het betalen en volgen van rijlessen geldt als acceptatie van de voorwaarden van rijschool.\r\n1.3 Bijzondere van de voorwaarden van rijschool afwijkende bepalingen zijn slechts bindend indien dit schriftelijk is overeengekomen.\r\n\r\nArtikel 2: verplichtingen rijschool\r\n2.1 Rijschool zorgt ervoor dat de rijlessen worden gegeven door rijinstructeurs / rijinstructrices die voldoen aan de bepalingen van de Wet Rijonderricht Motorrijtuigen (WRM).\r\n2.2 Rijschool heeft een bedrijfsverzekering afgesloten tegen aansprakelijkheidsrisico’s tijdens de rijles.\r\n\r\nArtikel 3: verplichtingen kandidaat\r\n3.1 Om lessen te kunnen volgen dient de kandidaat 16,5 jaar te zijn. De kandidaat is verplicht om tijdens de lessen altijd een legitimatiebewijs bij zich te hebben.\r\n3.2 De kandidaat zorgt er voor om op tijd en op de afgesproken plaats voor de rijles klaar te staan. Indien de kandidaat iets te laat is, dan wacht de rijinstructeur 15 minuten op de afgesproken plaats. Indien de kandidaat er na 15 minuten nog steeds niet is, dan heeft rijschool het recht om de les in rekening te brengen.\r\n3.3 De kandidaat zal, tijdens de les, de volgende kandidaat ophalen met de rijinstructeur en wordt ook weer teruggereden naar de startlocatie door de volgende kandidaat, tenzij de kandidaat de laatste kandidaat is op de dag.\r\n3.4 De kandidaat dient de rijschool te informeren indien de kandidaat een rijontzegging heeft of niet in staat is om fysiek en/of mentaal een auto te besturen.\r\n3.5 Als de kandidaat iets verzwijgt uit hetgeen in 3.4 vermeld staat, heeft rijschool het recht de lessen (lespakket) per direct te doen beëindigen zonder enige restitutie van lesgelden.\r\n3.6 Bij schade ontstaan als gevolg van de in 3.4 genoemde situaties heeft de rijschool het recht dit te verhalen op de kandidaat.\r\n\r\nArtikel 4: theoriecertificaat\r\n4.1 De kandidaat mag rijlessen volgen zonder dat de kandidaat in bezit is van een theoriecertificaat.\r\n4.2 De kandidaat is zelf verantwoordelijk voor het tijdig behalen van het theoriecertificaat. Zonder geldig theoriecertificaat kan er geen tussentijdse toets of rij(her)examen afgenomen worden.\r\n\r\nArtikel 5: intake & lespakket\r\n5.1 De rijinstructeur geeft tijdens de intake advies over een passend lespakket en advies over een passende rijinstructeur. De kandidaat is niet verplicht om het advies van de rijinstructeur op te volgen.\r\n5.2 De kandidaat ontvangt inloggegevens van de app planrijles om eigen lessen in te plannen. Een rijles/intake duurt 50 minuten.\r\n5.3 Rijschool boekt het tussentijdse toets of praktijkexamen aan de hand van de doorgegeven beschikbaarheid van de kandidaat.\r\n5.4 Bij rijschool kun je alléén een blokuur van 100 minuten inplannen (2 x 50 minuten) per keer.\r\n5.5 De overeengekomen lestijd zal volledig worden benut voor rijlessen en rijinstructie, tenzij: rijschool of kandidaat hiervan wenst af te wijken. Als zich dit voordoet, is rijschool niet gehouden het lesgeld aan de kandidaat te restitueren.\r\n5.6 Het overeengekomen lespakket zal tot aan het einde worden nagekomen, tenzij rijschool of de kandidaat hiervan wenst af te wijken.\r\n5.7 Het aantal lessen dat in een lespakket wordt aangeboden komt niet overeen met de opleidingsduur. Als de kandidaat aan het einde van het pakket nog niet toe is aan het praktijkexamen, dient de kandidaat eerst extra lessen te volgen tot hij of zij klaar is voor het praktijkexamen.\r\n5.8 Als de kandidaat niet of te laat is op het (her) examen of tussentijdse toets, zijn de kosten van de gemiste en nieuwe examen voor de kandidaat.\r\n5.9 Het rijexamen zal afgenomen worden met het voertuig waarin de rijlessen zijn gegeven. In geval van overmacht zal de kandidaat\r\n5.10 Als de lessen niet door kunnen gaan als gevolg van ziekte van de rijinstructeur of een ongeval, weer- en/of verkeersomstandigheden wordt de kandidaat hiervan tijdig op de hoogte gesteld en wordt er een nieuwe afspraak gemaakt of een vervangende rijinstructeur ingezet.\r\n5.11 Het is mogelijk om binnen een periode van 6 maanden de rijopleiding tijdelijk te onderbreken, bijvoorbeeld door (stage) buitenland, zwangerschap of andere oorzaken die de opleiding verhinderen. De kandidaat dient dit bij rijschool schriftelijk kenbaar te maken. In het geval dat de rijopleiding wordt onderbroken, zonder opgave van reden en er gedurende een periode van 1 jaar na de laatste gereden rijles geen enkel contact is geweest vervallen alle rechten.\r\n5.12 De lespakketten zijn 12 maanden geldig en niet overdraagbaar. Er is geen restitutie mogelijk.\r\n5.13 Als de kandidaat ontevreden is over een rijinstructeur, heeft de kandidaat de mogelijkheid om rijlessen voort te zetten bij een andere rijinstructeur van rijschool.\r\n\r\nArtikel 6: wijze van betaling\r\n6.1 De intake en proefles betaald te worden, voordat ze plaatsvinden. Rijschool stuurt altijd een factuur naar het opgegeven e-mailadres. De factuur dient via de betaallink betaald te worden.\r\n6.2 De lespakketten kunnen in 1 keer of in maximaal 4 termijnen betaald worden. De laatste termijn dient altijd voor het praktijkexamen betaald te zijn. Als het laatste termijn niet vooraf het praktijkexamen betaald is, kan het praktijkexamen niet worden afgenomen.'),
(2, 'admintest', '$2y$10$.YevqGuuKqy6ytLxq6fmrekRySbtXjOs9ddzHojgVTGB5wyV0Hfre', '2@gmail.com', NULL),
(3, 'TestAdmin_1764807526', '$2y$10$bLADe.HDztBFzZujitbgV.C/w8S5ILirWsnFn6OmRoylM8SKv3fYC', 'admin_test_1764807526@example.com', NULL),
(4, 'TestAdmin_1764807589', '$2y$10$2Z4CPcuY0Kh1IFaImeqkyOJzfBh7e/23Z6JoE3TR1pZ.xXx7Ka9p6', 'admin_test_1764807589@example.com', NULL),
(5, 'TestAdmin_1764807690', '$2y$10$cif3No0MZgFs/Q8aU.PXaezTxoZRurTP7q6jVge5FkJ02nOS7Zkbm', 'admin_test_1764807690@example.com', NULL),
(6, 'TestAdmin_1764807744', '$2y$10$3aydF6dmZnDtrMBnpBDYpusBkGDSNzFsLYE2BL55ZkV40SDNU91ou', 'admin_test_1764807744@example.com', 'Terms and conditions for DriveSmart driving school. All students must agree to these terms.'),
(7, 'admin', '$2y$10$Oa1fz22yzCdeOcBAPyAtBOYXVXeMLSOZPayQuX0Jgmdtji1qiCLN6', 'admin@test.local', NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `announcements`
--

CREATE TABLE `announcements` (
  `idAnnouncements` int(11) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Message` varchar(500) NOT NULL,
  `TargetGroup` varchar(20) NOT NULL,
  `CreatedAt` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `announcements`
--

INSERT INTO `announcements` (`idAnnouncements`, `Title`, `Message`, `TargetGroup`, `CreatedAt`) VALUES
(0, 'Test Announcement for Students', 'This is a test announcement for all students', 'student', '2025-12-04 01:18:46'),
(0, 'Test Announcement for Teachers', 'This is a test announcement for all instructors', 'teacher', '2025-12-04 01:18:46'),
(0, 'Test Announcement for Students', 'This is a test announcement for all students', 'student', '2025-12-04 01:19:49'),
(0, 'Test Announcement for Teachers', 'This is a test announcement for all instructors', 'teacher', '2025-12-04 01:19:49'),
(0, 'Test Announcement for Students', 'This is a test announcement for all students', 'student', '2025-12-04 01:21:30'),
(0, 'Test Announcement for Teachers', 'This is a test announcement for all instructors', 'teacher', '2025-12-04 01:21:30'),
(0, 'Test Announcement for Students', 'This is a test announcement for all students', 'student', '2025-12-04 01:22:24'),
(0, 'Test Announcement for Teachers', 'This is a test announcement for all instructors', 'teacher', '2025-12-04 01:22:24'),
(0, 'Welkom bij DriveSmart', 'Welkom bij onze rijschool! Neem contact op bij vragen.', 'student', '2025-12-04 03:36:40'),
(0, 'Nieuwe lestijden', 'Vanaf volgende week starten we om 9:00 uur.', 'student', '2025-12-04 03:36:40'),
(0, 'Instructeur vergadering', 'Team meeting volgende week donderdag.', 'teacher', '2025-12-04 03:36:40'),
(0, 'Nieuwe veiligheidsprotocollen', 'Lees de nieuwe veiligheidsrichtlijnen.', 'teacher', '2025-12-04 03:36:40'),
(0, 'Welkom bij DriveSmart', 'Welkom bij onze rijschool! Neem contact op bij vragen.', 'student', '2025-12-04 03:51:55'),
(0, 'Nieuwe lestijden', 'Vanaf volgende week starten we om 9:00 uur.', 'student', '2025-12-04 03:51:55'),
(0, 'Instructeur vergadering', 'Team meeting volgende week donderdag.', 'teacher', '2025-12-04 03:51:55'),
(0, 'Nieuwe veiligheidsprotocollen', 'Lees de nieuwe veiligheidsrichtlijnen.', 'teacher', '2025-12-04 03:51:55'),
(0, 'Welkom bij DriveSmart', 'Welkom bij onze rijschool! Neem contact op bij vragen.', 'student', '2025-12-04 04:01:25'),
(0, 'Nieuwe lestijden', 'Vanaf volgende week starten we om 9:00 uur.', 'student', '2025-12-04 04:01:25'),
(0, 'Instructeur vergadering', 'Team meeting volgende week donderdag.', 'teacher', '2025-12-04 04:01:25'),
(0, 'Nieuwe veiligheidsprotocollen', 'Lees de nieuwe veiligheidsrichtlijnen.', 'teacher', '2025-12-04 04:01:25');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `cars`
--

CREATE TABLE `cars` (
  `idCars` int(11) NOT NULL,
  `CarsType` varchar(255) NOT NULL,
  `CarsWear` varchar(255) NOT NULL,
  `CarsUsed` tinyint(4) NOT NULL,
  `Carscol` varchar(45) DEFAULT NULL,
  `CarsODO` int(11) DEFAULT NULL,
  `CarsMaintenance` tinyint(1) DEFAULT NULL,
  `CarLicensep` varchar(50) DEFAULT NULL,
  `AssignedTeacher` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `cars`
--

INSERT INTO `cars` (`idCars`, `CarsType`, `CarsWear`, `CarsUsed`, `Carscol`, `CarsODO`, `CarsMaintenance`, `CarLicensep`, `AssignedTeacher`) VALUES
(2, 'BMW', '', 0, NULL, 0, 1, 'HD-21-OP', NULL),
(3, 'Volkswagen', '', 0, NULL, 0, 0, 'AB-23-JK', NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `lessons`
--

CREATE TABLE `lessons` (
  `remark` varchar(255) DEFAULT NULL,
  `Subject` varchar(255) DEFAULT NULL,
  `Price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `mededelingen`
--

CREATE TABLE `mededelingen` (
  `id` int(11) NOT NULL,
  `titel` varchar(255) NOT NULL,
  `inhoud` text NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `target_audience` varchar(50) DEFAULT 'alle',
  `is_urgent` tinyint(1) DEFAULT 0,
  `datum_aangemaakt` datetime DEFAULT current_timestamp(),
  `datum_bewerkt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `schedule`
--

CREATE TABLE `schedule` (
  `idSchedule` int(11) NOT NULL,
  `ScheduleDateTime` datetime NOT NULL,
  `ScheduleCar` varchar(255) NOT NULL,
  `SchedulePickLoc` varchar(255) NOT NULL,
  `ScheduleStudentId` int(11) DEFAULT NULL,
  `ScheduleTeacherId` int(11) DEFAULT NULL,
  `ScheduleSubject` varchar(255) DEFAULT NULL,
  `ScheduleStatus` varchar(50) DEFAULT 'planned',
  `ScheduleCancelReason` varchar(255) DEFAULT NULL,
  `ScheduleStudentRemark` varchar(255) DEFAULT NULL,
  `ScheduleTeacherRemark` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `schedule`
--

INSERT INTO `schedule` (`idSchedule`, `ScheduleDateTime`, `ScheduleCar`, `SchedulePickLoc`, `ScheduleStudentId`, `ScheduleTeacherId`, `ScheduleSubject`, `ScheduleStatus`, `ScheduleCancelReason`, `ScheduleStudentRemark`, `ScheduleTeacherRemark`) VALUES
(16, '2024-01-15 10:00:00', 'BMW', 'Amsterdam Centrum', 3, 7, 'Rijles basis', 'planned', NULL, NULL, NULL),
(17, '2024-01-16 14:00:00', 'Volkswagen', 'Amsterdam Noord', 3, 7, 'Rijles verkeer', 'planned', NULL, NULL, NULL),
(18, '2024-01-17 11:00:00', 'BMW', 'Amsterdam Zuid', 3, 7, 'Rijles stad', 'cancelled', 'h', 'a', 'ja'),
(19, '2025-12-05 03:26:00', '', 'school', 2, 7, 'Rijles 4', 'planned', NULL, NULL, '');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `stripcard`
--

CREATE TABLE `stripcard` (
  `idStripCard` int(11) NOT NULL,
  `StripCardAmount` int(11) NOT NULL,
  `StripCardHolder` varchar(255) NOT NULL COMMENT 'FK'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `students`
--

CREATE TABLE `students` (
  `idStudents` int(11) NOT NULL,
  `StudentsName` varchar(255) NOT NULL,
  `StudentsAge` int(11) NOT NULL,
  `StudentsAddress` varchar(255) NOT NULL,
  `StudentsPhoneNumber` int(11) NOT NULL,
  `StudentsEmail` varchar(255) NOT NULL,
  `StudentsPsw` varchar(255) NOT NULL,
  `StudentsStripCard` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `students`
--

INSERT INTO `students` (`idStudents`, `StudentsName`, `StudentsAge`, `StudentsAddress`, `StudentsPhoneNumber`, `StudentsEmail`, `StudentsPsw`, `StudentsStripCard`) VALUES
(1, 'Test', 1, 'erwer', 123, 'hi@gmail.com', '$2y$10$lG/xktl5DnrMr/SvUz.WhewQIAbGknjk9KtXcJhpoXMzwiND47UIy', 0),
(2, 'TestStudent_1764807526', 25, 'Test Street 123', 687654321, 'student_test_1764807526@example.com', '$2y$10$SkFiiwKK/phQbEP6jY40cO.Ov63NezmarQTzJLM8mzDnXjZQ3k2TW', 0),
(3, 'TestStudent_1764807589', 25, 'Test Street 123', 687654321, 'student_test_1764807589@example.com', '$2y$10$kgGZSQ75SrD8EGqHD2hC4.od6PrroS/0/v7xVw6zV/oozqA2p4U5a', 0),
(4, 'UpdatedStudent_1764807690', 26, 'New Street 456', 611111111, 'new_email@example.com', '$2y$10$2aHnv7Xm0Zle2UJvJawoYO/MI5cI/lMvDM8m76dye9eiAalPU03e.', 0),
(5, 'UpdatedStudent_1764807744', 26, 'New Street 456', 611111111, 'new_email@example.com', '$2y$10$hEC.Cy15HheGrW.Yh9Gf4up0844uXjBVfLhvOl07DviZ6tv1JQPlK', 0);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `teachers`
--

CREATE TABLE `teachers` (
  `idTeachers` int(11) NOT NULL,
  `TeachersName` varchar(255) NOT NULL,
  `TeachersEmail` varchar(255) NOT NULL,
  `TeachersPhoneNumber` int(11) NOT NULL,
  `TeachersPsw` varchar(255) NOT NULL,
  `Avaiblilty` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `teachers`
--

INSERT INTO `teachers` (`idTeachers`, `TeachersName`, `TeachersEmail`, `TeachersPhoneNumber`, `TeachersPsw`, `Avaiblilty`) VALUES
(1, 'test teacher', '1@gmail.com', 0, '$2y$10$q5.jZPr6UG9nyPZb/emVreMXzTD3Aiirt601nu0rRPLGsRNkgpXIu', NULL),
(2, 'test teacher', '1@gmail.com', 0, '$2y$10$OQ1KQxHZKZ5mZWDxmh7BRuSoBQMK7Z9xUERTsDxC9oko8/HbXyy9q', NULL),
(3, 'Teacher', '1@gmail.com', 0, '$2y$10$O1nO0cjm0rFOJpwg1zHU0eTfNhWxUiZijzXT8SzhhIRd3jPnu2T8i', NULL),
(4, 'TestTeacher_1764807526', 'teacher_test_1764807526@example.com', 612345678, '$2y$10$jlyf546l38eAUGs87tjz8OEPVvprtSmUn2v8ga8akDtchuQO6Z86e', 1),
(5, 'TestTeacher_1764807589', 'teacher_test_1764807589@example.com', 612345678, '$2y$10$r9t4FNPnVlAN2MeS/A4uqeNNG79BXma.f7BbfzQuBw7/NXzdAVs0O', 1),
(6, 'TestTeacher_1764807690', 'teacher_test_1764807690@example.com', 0, '$2y$10$UtEaOLmWwhmwNmw0hQik.O7led23aVJfLRnUyEbTbeakk2Pvcz2GK', NULL),
(7, 'TestTeacher_1764807744', 'teacher_test_1764807744@example.com', 0, '$2y$10$zB2c5Efj75e48Etq7VN5H.5vvd14uX5y.UaZfbpMxkSymOrHhyP/2', NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `ziekmelding`
--

CREATE TABLE `ziekmelding` (
  `idZiekmelding` int(11) NOT NULL,
  `instructeur_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `datum` date NOT NULL,
  `tijd` time NOT NULL,
  `reden` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`idAdmin`);

--
-- Indexen voor tabel `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`idCars`);

--
-- Indexen voor tabel `mededelingen`
--
ALTER TABLE `mededelingen`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`idSchedule`);

--
-- Indexen voor tabel `stripcard`
--
ALTER TABLE `stripcard`
  ADD PRIMARY KEY (`idStripCard`);

--
-- Indexen voor tabel `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`idStudents`);

--
-- Indexen voor tabel `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`idTeachers`);

--
-- Indexen voor tabel `ziekmelding`
--
ALTER TABLE `ziekmelding`
  ADD PRIMARY KEY (`idZiekmelding`),
  ADD KEY `instructeur_id` (`instructeur_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `idAdmin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT voor een tabel `cars`
--
ALTER TABLE `cars`
  MODIFY `idCars` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT voor een tabel `mededelingen`
--
ALTER TABLE `mededelingen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `schedule`
--
ALTER TABLE `schedule`
  MODIFY `idSchedule` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT voor een tabel `stripcard`
--
ALTER TABLE `stripcard`
  MODIFY `idStripCard` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `students`
--
ALTER TABLE `students`
  MODIFY `idStudents` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT voor een tabel `teachers`
--
ALTER TABLE `teachers`
  MODIFY `idTeachers` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT voor een tabel `ziekmelding`
--
ALTER TABLE `ziekmelding`
  MODIFY `idZiekmelding` int(11) NOT NULL AUTO_INCREMENT;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `ziekmelding`
--
ALTER TABLE `ziekmelding`
  ADD CONSTRAINT `ziekmelding_ibfk_1` FOREIGN KEY (`instructeur_id`) REFERENCES `teachers` (`idTeachers`) ON DELETE SET NULL,
  ADD CONSTRAINT `ziekmelding_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `students` (`idStudents`) ON DELETE SET NULL,
  ADD CONSTRAINT `ziekmelding_ibfk_3` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`idAdmin`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
