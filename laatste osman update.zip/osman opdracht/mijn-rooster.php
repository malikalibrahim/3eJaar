<?php
include_once __DIR__ . '/db.php';
include_once __DIR__ . '/header.php';

if (!isset($_SESSION['boom_user']) || ($_SESSION['boom_user']['rol'] ?? null) !== 'leerling') {
    echo '<div class="error">Je moet ingelogd zijn als leerling om je rooster te bekijken.</div>';
    echo '<p><a class="btn" href="' . BOOM_BASE_URL . '/User/login.php">Inloggen</a></p>';
    include_once __DIR__ . '/footer.php';
    exit;
}

$leerling = $_SESSION['boom_user'];
$klas_id = $leerling['klas_id'];

$klas = $myDb->execute("SELECT * FROM klassen WHERE id=?", [$klas_id])->fetch(PDO::FETCH_ASSOC);
if (!$klas) { echo '<div class="error">Klas niet gevonden.</div>'; include_once __DIR__ . '/footer.php'; exit; }

include_once __DIR__ . '/Rooster/rooster.php';
$roosterModel = new RoosterModel();
$week = isset($_GET['week']) ? max(1, min(53, (int)$_GET['week'])) : (int)date('W');
$rows = $roosterModel->byKlas((int)$klas_id, $week);

$dagen = ['maandag','dinsdag','woensdag','donderdag','vrijdag'];
$perDag = array_fill_keys($dagen, []);
foreach ($rows as $r) { $perDag[$r['dag']][] = $r; }
?>
<h2>Mijn Rooster - <?= htmlspecialchars($leerling['naam']) ?> (<?= htmlspecialchars($klas['naam']) ?>)</h2>
<form method="get" class="row" style="margin-bottom:12px">
  <label>Week</label>
  <input type="number" name="week" value="<?= htmlspecialchars($week) ?>" min="1" max="53" style="width:90px">
  <button class="button">Toon</button>
  <a class="button button--ghost" href="?week=<?= (int)date('W') ?>">Huidige week</a>
  <input type="hidden" name="_" value="1">
</form>
<div class="grid grid-2">
<?php foreach ($dagen as $dag): ?>
  <div class="card">
    <h3><?= ucfirst($dag) ?></h3>
    <?php if (count($perDag[$dag]) === 0): ?>
      <p class="muted">Geen lessen</p>
    <?php else: ?>
    <table class="table">
      <thead><tr><th>Van</th><th>Tot</th><th>Vak</th><th>Docent</th></tr></thead>
      <tbody>
        <?php foreach ($perDag[$dag] as $r): ?>
        <tr>
          <td><?= htmlspecialchars($r['les_van']) ?></td>
          <td><?= htmlspecialchars($r['les_tot']) ?></td>
          <td><?= htmlspecialchars($r['vak']) ?></td>
          <td><?= htmlspecialchars($r['docent'] ?? '-') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
<?php endforeach; ?>
</div>
<?php include_once __DIR__ . '/footer.php'; ?>


