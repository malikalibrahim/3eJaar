    </main>
    <footer>
        <p>&copy; <?php echo date('Y'); ?> Basisschool De Boom</p>
    </footer>
</body>
</html>
