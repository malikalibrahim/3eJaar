<?php
include_once __DIR__ . '/../db.php';
include_once __DIR__ . '/../header.php';
if (!isset($_SESSION['boom_user']) || ($_SESSION['boom_user']['rol'] ?? null) !== 'admin') { header('Location: ../User/login.php'); exit; }

$id = $_GET['id'] ?? null;
if (!$id) { header('Location: rooster-view.php'); exit; }

$klassen = $myDb->execute("SELECT id, naam FROM klassen ORDER BY naam")->fetchAll(PDO::FETCH_ASSOC);
$docenten = $myDb->execute("SELECT id, naam FROM docenten ORDER BY naam")->fetchAll(PDO::FETCH_ASSOC);

$row = $myDb->execute("SELECT * FROM roosters WHERE id=?", [$id])->fetch(PDO::FETCH_ASSOC);
if (!$row) { header('Location: rooster-view.php'); exit; }

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $klas_id = $_POST['klas_id'] ?? '';
    $dag = $_POST['dag'] ?? '';
    $les_van = $_POST['les_van'] ?? '';
    $les_tot = $_POST['les_tot'] ?? '';
    $vak = trim($_POST['vak'] ?? '');
    $docent_id = $_POST['docent_id'] ?? null;

    if ($klas_id === '') { $errors[] = 'Klas is verplicht.'; }
    if (!in_array($dag, ['maandag','dinsdag','woensdag','donderdag','vrijdag'])) { $errors[] = 'Dag is ongeldig.'; }
    if ($les_van === '' || $les_tot === '') { $errors[] = 'Tijden zijn verplicht.'; }
    if ($vak === '') { $errors[] = 'Vak is verplicht.'; }

    if (!$errors) {
        include_once __DIR__ . '/rooster.php';
        $roosterModel = new RoosterModel();
        $roosterModel->update((int)$id, (int)$klas_id, $dag, $les_van, $les_tot, $vak, $docent_id ? (int)$docent_id : null);
        header('Location: rooster-view.php');
        exit;
    }
}
?>
<h2>Les wijzigen</h2>
<?php if ($errors): ?><div class="error"><?php foreach ($errors as $e) { echo '<p>' . htmlspecialchars($e) . '</p>'; } ?></div><?php endif; ?>
<form method="post" class="stack">
  <label>Klas</label>
  <select name="klas_id" required>
    <?php foreach ($klassen as $k): ?>
      <option value="<?= $k['id'] ?>" <?= ($row['klas_id'] == $k['id']) ? 'selected' : '' ?>><?= htmlspecialchars($k['naam']) ?></option>
    <?php endforeach; ?>
  </select>

  <label>Dag</label>
  <?php $dagen = ['maandag','dinsdag','woensdag','donderdag','vrijdag']; ?>
  <select name="dag" required>
    <?php foreach ($dagen as $d) { $sel = ($row['dag'] === $d) ? 'selected' : ''; echo '<option ' . $sel . ' value="' . $d . '">' . ucfirst($d) . '</option>'; } ?>
  </select>

  <label>Van</label>
  <input type="time" name="les_van" value="<?= htmlspecialchars($row['les_van']) ?>" required>

  <label>Tot</label>
  <input type="time" name="les_tot" value="<?= htmlspecialchars($row['les_tot']) ?>" required>

  <label>Vak</label>
  <input type="text" name="vak" value="<?= htmlspecialchars($row['vak']) ?>" required>

  <label>Docent</label>
  <select name="docent_id">
    <option value="">-- optioneel --</option>
    <?php foreach ($docenten as $d): ?>
      <option value="<?= $d['id'] ?>" <?= (($row['docent_id']) == $d['id']) ? 'selected' : '' ?>><?= htmlspecialchars($d['naam']) ?></option>
    <?php endforeach; ?>
  </select>

  <input type="submit" value="Opslaan">
</form>
<?php include_once __DIR__ . '/../footer.php'; ?>
