<?php
include_once __DIR__ . '/../db.php';

class RoosterModel {
    private $db;
    public function __construct() {
        global $myDb;
        $this->db = $myDb;
    }

    public function overview(int $week): array {
        $sql = "SELECT r.id, r.week, k.naam AS klas, r.dag, r.les_van, r.les_tot, r.vak, d.naam AS docent
                FROM roosters r
                JOIN klassen k ON k.id = r.klas_id
                LEFT JOIN docenten d ON d.id = r.docent_id
                WHERE r.week = ?
                ORDER BY k.naam, FIELD(r.dag,'maandag','dinsdag','woensdag','donderdag','vrijdag'), r.les_van";
        return $this->db->execute($sql, [$week])->fetchAll(PDO::FETCH_ASSOC);
    }

    public function byKlas(int $klas_id, int $week): array {
        $sql = "SELECT r.*, d.naam AS docent
                FROM roosters r
                LEFT JOIN docenten d ON d.id = r.docent_id
                WHERE r.klas_id = ? AND r.week = ?
                ORDER BY FIELD(r.dag,'maandag','dinsdag','woensdag','donderdag','vrijdag'), r.les_van";
        return $this->db->execute($sql, [$klas_id, $week])->fetchAll(PDO::FETCH_ASSOC);
    }

    public function create(int $klas_id, int $week, string $dag, string $les_van, string $les_tot, string $vak, ?int $docent_id): void {
        $this->db->execute("INSERT INTO roosters (klas_id, week, dag, les_van, les_tot, vak, docent_id) VALUES (?,?,?,?,?,?,?)",
            [$klas_id, $week, $dag, $les_van, $les_tot, $vak, $docent_id]);
    }

    public function find(int $id): ?array {
        $row = $this->db->execute("SELECT * FROM roosters WHERE id=?", [$id])->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    public function update(int $id, int $klas_id, int $week, string $dag, string $les_van, string $les_tot, string $vak, ?int $docent_id): void {
    public function update(int $id, int $klas_id, int $week, string $dag, string $les_van, string $les_tot, string $vak, ?int $docent_id): void { // De week parameter was al aanwezig
        $this->db->execute("UPDATE roosters SET klas_id=?, week=?, dag=?, les_van=?, les_tot=?, vak=?, docent_id=? WHERE id=?",
            [$klas_id, $week, $dag, $les_van, $les_tot, $vak, $docent_id, $id]);
    }

    public function delete(int $id): void {
        $this->db->execute("DELETE FROM roosters WHERE id=?", [$id]);
    }
}


