<?php
include_once __DIR__ . '/../db.php';
include_once __DIR__ . '/../header.php';
if (!isset($_SESSION['boom_user']) || ($_SESSION['boom_user']['rol'] ?? null) !== 'admin') { header('Location: ../User/login.php'); exit; }

$klassen = $myDb->execute("SELECT id, naam FROM klassen ORDER BY naam")->fetchAll(PDO::FETCH_ASSOC);
$docenten = $myDb->execute("SELECT id, naam FROM docenten ORDER BY naam")->fetchAll(PDO::FETCH_ASSOC);

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $week = $_POST['week'] ?? '';
    $klas_id = $_POST['klas_id'] ?? '';
    $dag = $_POST['dag'] ?? '';
    $les_van = $_POST['les_van'] ?? '';
    $les_tot = $_POST['les_tot'] ?? '';
    $vak = trim($_POST['vak'] ?? '');
    $docent_id = $_POST['docent_id'] ?? null;

    if ($week === '' || !preg_match('/^\d+$/', $week) || (int)$week < 1 || (int)$week > 53) { $errors[] = 'Week moet tussen 1 en 53 zijn.'; }
    if ($klas_id === '') { $errors[] = 'Klas is verplicht.'; }
    if (!in_array($dag, ['maandag','dinsdag','woensdag','donderdag','vrijdag'])) { $errors[] = 'Dag is ongeldig.'; }
    if ($les_van === '' || $les_tot === '') { $errors[] = 'Tijden zijn verplicht.'; }
    if ($vak === '') { $errors[] = 'Vak is verplicht.'; }

    if (!$errors) {
        include_once __DIR__ . '/rooster.php';
        $roosterModel = new RoosterModel();
        $roosterModel->create((int)$klas_id, (int)$week, $dag, $les_van, $les_tot, $vak, $docent_id ? (int)$docent_id : null);
        $goWeek = (int)$week;
        header('Location: rooster-view.php?week=' . $goWeek);
        exit;
    }
}
?>
<h2>Les toevoegen</h2>
<?php if ($errors): ?><div class="error"><?php foreach ($errors as $e) { echo '<p>' . htmlspecialchars($e) . '</p>'; } ?></div><?php endif; ?>
<form method="post" class="stack">
  <label>Week (1-53)</label>
  <input type="number" name="week" min="1" max="53" value="<?= htmlspecialchars($_GET['week'] ?? $_POST['week'] ?? (int)date('W')) ?>" required>
  <label>Klas</label>
  <select name="klas_id" required>
    <option value="">-- kies klas --</option>
    <?php foreach ($klassen as $k): ?>
      <option value="<?= $k['id'] ?>" <?= (($_POST['klas_id'] ?? '') == $k['id']) ? 'selected' : '' ?>><?= htmlspecialchars($k['naam']) ?></option>
    <?php endforeach; ?>
  </select>

  <label>Dag</label>
  <select name="dag" required>
    <?php $dagen = ['maandag','dinsdag','woensdag','donderdag','vrijdag']; foreach ($dagen as $d) { $sel = (($_POST['dag'] ?? '') === $d) ? 'selected' : ''; echo '<option ' . $sel . ' value="' . $d . '">' . ucfirst($d) . '</option>'; } ?>
  </select>

  <label>Van</label>
  <input type="time" name="les_van" value="<?= htmlspecialchars($_POST['les_van'] ?? '') ?>" required>

  <label>Tot</label>
  <input type="time" name="les_tot" value="<?= htmlspecialchars($_POST['les_tot'] ?? '') ?>" required>

  <label>Vak</label>
  <input type="text" name="vak" value="<?= htmlspecialchars($_POST['vak'] ?? '') ?>" required>

  <label>Docent</label>
  <select name="docent_id">
    <option value="">-- optioneel --</option>
    <?php foreach ($docenten as $d): ?>
      <option value="<?= $d['id'] ?>" <?= (($_POST['docent_id'] ?? '') == $d['id']) ? 'selected' : '' ?>><?= htmlspecialchars($d['naam']) ?></option>
    <?php endforeach; ?>
  </select>

  <input type="submit" value="Opslaan">
</form>
<?php include_once __DIR__ . '/../footer.php'; ?>
