-- Database schema for Basisschool De Boom

CREATE DATABASE IF NOT EXISTS basisschool_boom CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE basisschool_boom;

-- Tabellen
CREATE TABLE IF NOT EXISTS klassen (
  id INT AUTO_INCREMENT PRIMARY KEY,
  naam VARCHAR(100) NOT NULL,
  jaar INT NOT NULL,
  UNIQUE KEY unique_klas (naam, jaar)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS docenten (
  id INT AUTO_INCREMENT PRIMARY KEY,
  naam VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS roosters (
  id INT AUTO_INCREMENT PRIMARY KEY,
  klas_id INT NOT NULL,
  week INT NOT NULL DEFAULT 1,
  dag ENUM('maandag','dinsdag','woensdag','donderdag','vrijdag') NOT NULL,
  les_van TIME NOT NULL,
  les_tot TIME NOT NULL,
  vak VARCHAR(120) NOT NULL,
  docent_id INT NULL,
  CONSTRAINT fk_rooster_klas FOREIGN KEY (klas_id) REFERENCES klassen(id) ON DELETE CASCADE,
  CONSTRAINT fk_rooster_docent FOREIGN KEY (docent_id) REFERENCES docenten(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(80) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  rol VARCHAR(20) NOT NULL DEFAULT 'admin'
) ENGINE=InnoDB;

-- Voorbeeld admin (wachtwoord: admin123)
INSERT INTO admins (username, password) VALUES (
  'admin', MD5('admin123')
) ON DUPLICATE KEY UPDATE username = username;

-- Voorbeelddata (optioneel)
INSERT INTO klassen (naam, jaar) VALUES
  ('Groep 7A', 2025),
  ('Groep 8B', 2025)
ON DUPLICATE KEY UPDATE naam = VALUES(naam), jaar = VALUES(jaar);

INSERT INTO docenten (naam, email) VALUES
  ('Meester Jan', 'jan@example.com'),
  ('Juf Sara', 'sara@example.com')
ON DUPLICATE KEY UPDATE naam = VALUES(naam), email = VALUES(email);

-- Leerlingen (students)
CREATE TABLE IF NOT EXISTS leerlingen (
  id INT AUTO_INCREMENT PRIMARY KEY,
  naam VARCHAR(120) NOT NULL,
  username VARCHAR(80) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  klas_id INT NOT NULL,
  CONSTRAINT fk_leerling_klas FOREIGN KEY (klas_id) REFERENCES klassen(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Voorbeeld leerling (wachtwoord: leerling123)
INSERT INTO leerlingen (naam, username, password, klas_id)
SELECT 'Pietje Puk', 'pietje', MD5('leerling123'), k.id
FROM klassen k
WHERE k.naam = 'Groep 7A' AND k.jaar = 2025
ON DUPLICATE KEY UPDATE username = username;

-- Unified users table (admin and leerling)
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  naam VARCHAR(120) NOT NULL,
  username VARCHAR(80) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  rol ENUM('admin','leerling') NOT NULL,
  klas_id INT NULL,
  CONSTRAINT fk_user_klas FOREIGN KEY (klas_id) REFERENCES klassen(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Seed unified users from existing data (idempotent-ish)
INSERT INTO users (naam, username, password, rol, klas_id)
VALUES ('Beheerder', 'admin', MD5('admin123'), 'admin', NULL)
ON DUPLICATE KEY UPDATE username = username;

INSERT INTO users (naam, username, password, rol, klas_id)
SELECT l.naam, l.username, l.password, 'leerling', l.klas_id
FROM leerlingen l
ON DUPLICATE KEY UPDATE username = username;