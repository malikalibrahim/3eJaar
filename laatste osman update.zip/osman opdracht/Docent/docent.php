<?php
include_once __DIR__ . '/../db.php';

class Docent {
    private $db;
    public function __construct() {
        global $myDb;
        $this->db = $myDb;
    }

    public function all(): array {
        return $this->db->execute("SELECT * FROM docenten ORDER BY naam ASC")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function find(int $id): ?array {
        $row = $this->db->execute("SELECT * FROM docenten WHERE id=?", [$id])->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    public function create(string $naam, string $email): void {
        $this->db->execute("INSERT INTO docenten (naam, email) VALUES (?, ?)", [$naam, $email]);
    }

    public function update(int $id, string $naam, string $email): void {
        $this->db->execute("UPDATE docenten SET naam=?, email=? WHERE id=?", [$naam, $email, $id]);
    }

    public function delete(int $id): void {
        $this->db->execute("DELETE FROM docenten WHERE id=?", [$id]);
    }
}


