<?php
include_once __DIR__ . '/../db.php';
include_once __DIR__ . '/../header.php';
if (!isset($_SESSION['boom_user']) || ($_SESSION['boom_user']['rol'] ?? null) !== 'admin') { header('Location: ../User/login.php'); exit; }

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $naam = trim($_POST['naam'] ?? '');
    $email = trim($_POST['email'] ?? '');
    if ($naam === '') { $errors[] = 'Naam is verplicht.'; }
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) { $errors[] = 'Geldig e-mailadres is verplicht.'; }
    if (!$errors) {
        include_once __DIR__ . '/docent.php';
        $docentModel = new Docent();
        $docentModel->create($naam, $email);
        header('Location: docent-view.php');
        exit;
    }
}
?>
<h2>Docent toevoegen</h2>
<?php if ($errors): ?><div class="error"><?php foreach ($errors as $e) { echo '<p>' . htmlspecialchars($e) . '</p>'; } ?></div><?php endif; ?>
<form method="post" class="stack">
  <label>Naam</label>
  <input type="text" name="naam" value="<?= htmlspecialchars($_POST['naam'] ?? '') ?>" required>
  <label>Email</label>
  <input type="text" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
  <input type="submit" value="Opslaan">
</form>
<?php include_once __DIR__ . '/../footer.php'; ?>
