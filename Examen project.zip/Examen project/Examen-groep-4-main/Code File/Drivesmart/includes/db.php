<?php
// Gebruik de bestaande PDO-verbinding uit ../Database/db.php
require_once __DIR__ . '/../Database/db.php';

class DB {
    protected $pdo;

    public function __construct() {
        // $pdo komt uit het geïmporteerde db.php-bestand
        global $pdo;
        $this->pdo = $pdo;
    }

    public function run($sql, $args = null) {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($args);
        return $stmt;
    }
}
?>
