<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uitloggen</title>
    <link rel="stylesheet" href="../Styling/Logout.css">
</head>
<body>
    <div class="logout-container">
        <h1>Uitloggen</h1>
        <p>Weet je zeker dat je wilt uitloggen?</p>
        
        <form method="POST">
            <button type="submit" name="confirm_logout">Ja, uitloggen</button>
            <a href="../UserInteractive/MainPage.php">Nee, annuleren</a>
        </form>
    </div>
</body>
</html>

<?php
// Als de uitlog knop is ingedrukt
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_logout'])) {
    session_start();
    
    // Sessie opschonen
    $_SESSION = array();
    
    // Sessie cookie verwijderen
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    // Sessie vernietigen
    session_destroy();
    
    // Terugsturen naar loginpagina
    header("Location: ../UserInteractive/MainPage.php");
    exit();
}
?>