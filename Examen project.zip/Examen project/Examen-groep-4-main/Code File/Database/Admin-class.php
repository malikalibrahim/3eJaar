<?php
require "db.php";


Class Admin {
public $pdo;



public function __construct($db) {
$this->pdo = $db;
}

public function LoginAdmin($email) {
    $stmt = $this->pdo->prepare("SELECT * FROM admin WHERE AdminEmail = :email");
    $stmt->execute(['email' => $email]); 
    return $stmt->fetch(PDO::FETCH_ASSOC); 
}

public function RegisterAdmin($name, $email, $password) {
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $this->pdo->prepare("INSERT INTO admin (AdminName, AdminEmail, AdminPsw) VALUES (:name, :email, :password)");
    return $stmt->execute(['name'=> $name, 'email' => $email, 'password' => $hashedPassword]);

}

}
?>
