<?php
// Simpele startpagina met keuze voor rol
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>DriveSmart - Inloggen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
    <h1 class="mb-4">DriveSmart portaal</h1>
    <p class="mb-3">Kies je rol om in te loggen:</p>
    <div class="list-group">
        <a href="student/login.php" class="list-group-item list-group-item-action">Leerling</a>
        <a href="teacher/login.php" class="list-group-item list-group-item-action">Instructeur</a>
        <a href="admin/login.php" class="list-group-item list-group-item-action">Rijschool / Admin</a>
    </div>
</div>
</body>
</html>


