<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DriveSmart - Admin</title>
    <link rel="stylesheet" href="../Styling/homepageadmin.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="h3 mb-0">Rijschool DriveSmart - Admin</h1>
        <div>
            <span class="me-3">Welkom, <?= htmlspecialchars($_SESSION['admin_name'] ?? 'Admin') ?></span>
            <a href="logout.php" class="btn btn-outline-danger btn-sm">Uitloggen</a>
        </div>
    </div>

    <nav class="mb-4">
        <ul class="nav nav-pills">
            <li class="nav-item"><a class="nav-link active" href="HomepageAdmin.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="Wagenpark.php">Wagenpark</a></li>
        </ul>
    </nav>

    <div class="row g-3">
        <div class="col-md-6">
            <div class="list-group">
                <a href="teacher-add.php" class="list-group-item list-group-item-action">
                    Instructeur-account aanmaken
                </a>
                <a href="terms.php" class="list-group-item list-group-item-action">
                    Algemene voorwaarden beheren
                </a>
            </div>
        </div>
    </div>
</div>
</body>
</html>