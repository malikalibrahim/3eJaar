<?php
require_once __DIR__ . '/../../Database/database.php';
require_once __DIR__ . '/../Classes/Car.php';

$db = new Database('127.0.0.1', 'drivesmart', 'root', '');
$pdo = $db->getPdo();
$car = new Car($pdo);

$cars = $car->getAll();
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Wagenpark</title>
    <link rel="stylesheet" href="../Styling/wagenpark.css">
</head>
<body>
    <h1>Wagenpark</h1>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Type</th>
                <th>Slijtage</th>
                <th>In gebruik</th>
                <th>Kilometerstand</th>
                <th>Onderhoud</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($cars as $c): ?>
                <tr>
                    <td><?= $c['idCars'] ?></td>
                    <td><?= $c['CarsType'] ?></td>
                    <td><?= $c['CarsWear'] ?></td>
                    <td><?= $c['CarsUsed'] ? 'Ja' : 'Nee' ?></td>
                    <td><?= $c['CarsODO'] ?> km</td>
                    <td><?= $c['CarsMaintenance'] ? 'Ja' : 'Nee' ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>