<?php
require_once __DIR__ . '/admin-class.php';
session_start();

if (isset($_SESSION['admin_id'])) {
    header('Location: HomepageAdmin.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $admin = new Admin();
    $name = htmlspecialchars($_POST['name'] ?? '');
    $password = $_POST['password'] ?? '';

    $row = $admin->login($name);
    if ($row && password_verify($password, $row['AdminPsw'])) {
        $_SESSION['admin_id'] = $row['idAdmin'];
        $_SESSION['admin_name'] = $row['AdminName'];
        header('Location: HomepageAdmin.php');
        exit;
    } else {
        $error = 'Ongeldige inloggegevens.';
    }
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Rijschool / Admin inloggen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
    <h2 class="mb-4">Admin inloggen</h2>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post" class="card card-body">
        <div class="mb-3">
            <label class="form-label">Gebruikersnaam</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Wachtwoord</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Inloggen</button>
        <a href="../index.php" class="btn btn-link">Terug</a>
    </form>
</div>
</body>
</html>


