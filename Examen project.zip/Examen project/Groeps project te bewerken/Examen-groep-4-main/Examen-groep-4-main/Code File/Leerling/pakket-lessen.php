<?php
// Bootstrap config
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../Database/db.php';
session_start();

if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit;
}

$studentId = (int)$_SESSION['student_id'];

// Haal student + stripcard info op
$stmt = $pdo->prepare("SELECT StudentsName, StudentsStripCard FROM students WHERE idStudents = :id");
$stmt->execute(['id' => $studentId]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

$pakketAantal = (int)($student['StudentsStripCard'] ?? 0);

// Aantal afgeronde lessen binnen pakket (status 'done')
$stmt = $pdo->prepare("SELECT * FROM schedule WHERE ScheduleStudentId = :sid AND ScheduleStatus = 'done' ORDER BY ScheduleDateTime DESC");
$stmt->execute(['sid' => $studentId]);
$completedLessons = $stmt->fetchAll(PDO::FETCH_ASSOC);

$gebruikt = count($completedLessons);
$resterend = max(0, $pakketAantal - $gebruikt);

$pageTitle = "Mijn lespakket";
require_once __DIR__ . '/../Admin/header.php';
?>

<div class="card mx-auto" style="max-width: 800px;">
    <div class="card-header d-flex justify-content-between align-items-center">
        <div>
            <h2 class="mb-0">Lespakket voortgang</h2>
            <small class="text-muted">Voor leerling: <?= htmlspecialchars($student['StudentsName'] ?? 'Onbekend') ?></small>
        </div>
        <span class="badge bg-info text-dark">Ingelogd als leerling</span>
    </div>
    <div class="card-body">
        <div class="row mb-3">
            <div class="col-md-4">
                <div class="p-3 border rounded">
                    <strong>Aantal lessen in pakket</strong>
                    <div class="fs-4"><?= $pakketAantal ?></div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-3 border rounded">
                    <strong>Reeds afgenomen</strong>
                    <div class="fs-4"><?= $gebruikt ?></div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-3 border rounded">
                    <strong>Resterend</strong>
                    <div class="fs-4"><?= $resterend ?></div>
                </div>
            </div>
        </div>

        <h4 class="mt-4">Afgeronde lessen</h4>
        <?php if (empty($completedLessons)): ?>
            <p class="text-muted">Nog geen afgeronde lessen.</p>
        <?php else: ?>
            <table class="table table-striped table-sm">
                <thead>
                    <tr>
                        <th>Datum/tijd</th>
                        <th>Onderwerp</th>
                        <th>Ophaallocatie</th>
                        <th>Opmerking instructeur</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($completedLessons as $lesson): ?>
                    <tr>
                        <td><?= htmlspecialchars($lesson['ScheduleDateTime']) ?></td>
                        <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '') ?></td>
                        <td><?= htmlspecialchars($lesson['SchedulePickLoc'] ?? '') ?></td>
                        <td>
                            <?php if (!empty($lesson['ScheduleTeacherRemark'])): ?>
                                <small class="text-muted"><?= htmlspecialchars(substr($lesson['ScheduleTeacherRemark'], 0, 80)) ?>...</small>
                            <?php else: ?>
                                <small class="text-muted">-</small>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <div class="d-flex justify-content-between mt-3">
            <a href="HomepageLeerling.php" class="btn btn-secondary">Terug</a>
            <a href="leerling-les-plannen.php" class="btn btn-primary">Nieuwe les plannen</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../Admin/footer.php'; ?>
