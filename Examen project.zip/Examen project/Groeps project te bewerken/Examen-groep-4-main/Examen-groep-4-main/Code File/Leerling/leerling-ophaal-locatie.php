<?php
// Bootstrap config
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../includes/Algemeen/schedule-class.php';
session_start();

if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit;
}

$scheduleId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$schedule = new Schedule();
$lesson = $schedule->getById($scheduleId);

if (!$lesson || (int)$lesson['ScheduleStudentId'] !== (int)$_SESSION['student_id']) {
    http_response_code(403);
    echo "Je mag deze les niet aanpassen.";
    exit;
}

$message = '';
$messageType = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pickLoc = trim($_POST['pickloc'] ?? '');
    if ($pickLoc === '') {
        $message = 'Ophaallocatie mag niet leeg zijn.';
        $messageType = 'danger';
    } else {
        $schedule->updatePickupLocation($scheduleId, (int)$_SESSION['student_id'], $pickLoc);
        $message = 'Ophaallocatie bijgewerkt.';
        $messageType = 'success';
    }
}

$pageTitle = "Ophaallocatie aanpassen";
require_once __DIR__ . '/../Admin/header.php';
?>

<div class="card mx-auto" style="max-width: 650px;">
    <div class="card-header">
        <h2 class="mb-0">Ophaallocatie aanpassen</h2>
    </div>
    <div class="card-body">
        <p class="text-muted text-center">Les op: <strong><?= htmlspecialchars($lesson['ScheduleDateTime']) ?></strong></p>
        <?php if ($message): ?>
            <div class="alert alert-<?= $messageType ?>"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        <form method="post" class="row g-3">
            <div class="col-12">
                <label for="pickloc" class="form-label">Nieuwe ophaallocatie</label>
                <input type="text" id="pickloc" name="pickloc" class="form-control" value="<?= htmlspecialchars($lesson['SchedulePickLoc'] ?? '') ?>" required>
            </div>
            <div class="col-12 d-flex justify-content-between">
                <a href="HomepageLeerling.php" class="btn btn-secondary">Terug</a>
                <button type="submit" class="btn btn-primary">Opslaan</button>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../Admin/footer.php'; ?>
