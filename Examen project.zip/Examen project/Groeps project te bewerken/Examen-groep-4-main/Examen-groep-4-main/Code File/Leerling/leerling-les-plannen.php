<?php
// Bootstrap config
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../includes/Algemeen/schedule-class.php';
session_start();

if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit;
}

$schedule = new Schedule();
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = $_POST['date'] ?? '';
    $time = $_POST['time'] ?? '';
    $subject = trim($_POST['subject'] ?? '');
    $pickLoc = trim($_POST['pickloc'] ?? '');
    $car = trim($_POST['car'] ?? '');

    if (!$date || !$time) {
        $message = 'Kies een datum en tijd.';
        $messageType = 'danger';
    } else {
        $dt = $date . ' ' . $time;
        try {
            $schedule->createLessonForStudent((int)$_SESSION['student_id'], null, $dt, $pickLoc, $subject, $car);
            $message = 'Les succesvol ingepland.';
            $messageType = 'success';
        } catch (Exception $e) {
            $message = 'Fout bij plannen: ' . $e->getMessage();
            $messageType = 'danger';
        }
    }
}

$pageTitle = "Les plannen";
require_once __DIR__ . '/../Admin/header.php';
?>

<div class="card mx-auto" style="max-width: 650px;">
    <div class="card-header">
        <h2 class="mb-0">Les plannen</h2>
    </div>
    <div class="card-body">
        <?php if ($message): ?>
            <div class="alert alert-<?= $messageType ?>"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        <form method="post" class="row g-3">
            <div class="col-md-6">
                <label for="date" class="form-label">Datum</label>
                <input type="date" id="date" name="date" class="form-control" required>
            </div>
            <div class="col-md-6">
                <label for="time" class="form-label">Tijd</label>
                <input type="time" id="time" name="time" class="form-control" required>
            </div>
            <div class="col-md-12">
                <label for="subject" class="form-label">Te behandelen onderdeel</label>
                <input type="text" id="subject" name="subject" class="form-control" placeholder="Bijv. fileparkeren">
            </div>
            <div class="col-md-12">
                <label for="pickloc" class="form-label">Ophaallocatie</label>
                <input type="text" id="pickloc" name="pickloc" class="form-control" placeholder="Adres of punt">
            </div>
            <div class="col-md-12">
                <label for="car" class="form-label">Gewenste auto (optioneel)</label>
                <input type="text" id="car" name="car" class="form-control" placeholder="Kenteken of type">
            </div>
            <div class="col-12 d-flex justify-content-between">
                <a href="HomepageLeerling.php" class="btn btn-secondary">Terug</a>
                <button type="submit" class="btn btn-primary">Plan les</button>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../Admin/footer.php'; ?>
