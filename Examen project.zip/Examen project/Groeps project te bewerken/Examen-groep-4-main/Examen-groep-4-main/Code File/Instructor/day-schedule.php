<?php
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../includes/Algemeen/schedule-class.php';
require_once __DIR__ . '/../includes/Algemeen/announcement-class.php';
session_start();

if (!isset($_SESSION['teacher_id'])) {
    header('Location: login.php');
    exit;
}

$teacherId = $_SESSION['teacher_id'];
$schedule = new Schedule();
$announcement = new Announcement();

$today = date('Y-m-d');
$lessons = $schedule->getTeacherLessons($teacherId);
$announcements = $announcement->getForTarget('teacher');

$pageTitle = "Instructeur Dashboard";
require_once __DIR__ . '/../Admin/header.php';
?>
<h1 class="mb-4">Instructeur Dashboard</h1>

    <div class="row g-4">
        <div class="col-md-8">
            <h4 class="mb-3">Mijn lessen</h4>
            <table class="table table-striped table-sm">
                <thead>
                <tr>
                    <th>Datum/tijd</th>
                    <th>Leerling</th>
                    <th>Onderwerp</th>
                    <th>Status</th>
                    <th>Annuleringsreden</th>
                    <th>Leerling opmerking</th>
                    <th>Mijn opmerking</th>
                    <th>Acties</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($lessons as $lesson): ?>
                    <tr>
                        <td><?= htmlspecialchars($lesson['ScheduleDateTime']) ?></td>
                        <td><?= htmlspecialchars($lesson['StudentsName'] ?? 'Onbekend') ?></td>
                        <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '') ?></td>
                        <td><?= htmlspecialchars($lesson['ScheduleStatus']) ?></td>
                        <td>
                            <?php if (!empty($lesson['ScheduleCancelReason'])): ?>
                                <small class="text-muted"><?= htmlspecialchars(substr($lesson['ScheduleCancelReason'], 0, 50)) ?>...</small>
                            <?php else: ?>
                                <small class="text-muted">Geen reden</small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!empty($lesson['ScheduleStudentRemark'])): ?>
                                <small class="text-muted"><?= htmlspecialchars(substr($lesson['ScheduleStudentRemark'], 0, 50)) ?>...</small>
                            <?php else: ?>
                                <small class="text-muted">Geen opmerking</small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!empty($lesson['ScheduleTeacherRemark'])): ?>
                                <small class="text-muted"><?= htmlspecialchars(substr($lesson['ScheduleTeacherRemark'], 0, 50)) ?>...</small>
                            <?php else: ?>
                                <small class="text-muted">Geen opmerking</small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="instructor-lesson-remark.php?id=<?= (int)$lesson['idSchedule'] ?>" class="btn btn-sm btn-primary">Opmerking</a>
                            <a href="instructor-lesson-edit.php?id=<?= (int)$lesson['idSchedule'] ?>" class="btn btn-sm btn-warning">Aanpassen</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="col-md-4">
            <h4 class="mb-3">Mededelingen</h4>
            <?php if (!$announcements): ?>
                <p class="text-muted">Geen mededelingen.</p>
            <?php else: ?>
                <?php foreach ($announcements as $a): ?>
                    <div class="card mb-2">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($a['Title']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($a['Message']) ?></p>
                            <small class="text-muted"><?= htmlspecialchars($a['CreatedAt']) ?></small>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

<?php require_once __DIR__ . '/../Admin/footer.php'; ?>
