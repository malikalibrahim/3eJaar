<?php
session_start();
require_once __DIR__ . '/../includes/Algemeen/announcement-class.php';
require_once __DIR__ . '/../../Database/database.php';

// Sessie-waarden consistent maken
$instructorId = $_SESSION['user_id'] ?? $_SESSION['teacher_id'] ?? null;
$instructorName = $_SESSION['user_name'] ?? 'Instructeur';
$role = $_SESSION['role'] ?? null;

// Database verbinding
$db = new Database('127.0.0.1', 'drivesmart', 'root', '');
$pdo = $db->getPdo();

// Fallback: haal ID op wanneer alleen naam/rol bekend is
if (!$instructorId && isset($_SESSION['user_name']) && in_array($role, ['teacher', 'instructeur'], true)) {
    try {
        $stmt = $pdo->prepare("SELECT idTeachers FROM teachers WHERE TeachersName = :name LIMIT 1");
        $stmt->execute([':name' => $_SESSION['user_name']]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($result) {
            $instructorId = $result['idTeachers'];
            $_SESSION['user_id'] = $instructorId;
            $_SESSION['teacher_id'] = $instructorId;
        }
    } catch (PDOException $e) {
        $errorMsg = "Kon instructeur ID niet ophalen: " . $e->getMessage();
    }
}

$selectedDate = $_GET['date'] ?? date('Y-m-d');
$todaySchedule = [];
$teacherAnnouncements = [];

if ($instructorId) {
    try {
        $sql = "SELECT 
                    s.idSchedule,
                    s.ScheduleDateTime,
                    s.ScheduleCar,
                    s.SchedulePickLoc,
                    s.ScheduleSubject,
                    s.ScheduleStatus,
                    st.StudentsName,
                    t.TeachersName
                FROM schedule s
                LEFT JOIN students st ON s.ScheduleStudentId = st.idStudents
                LEFT JOIN teachers t ON s.ScheduleTeacherId = t.idTeachers
                WHERE DATE(s.ScheduleDateTime) = :date
                  AND s.ScheduleTeacherId = :instructorId
                  AND (s.ScheduleStatus = 'planned' OR s.ScheduleStatus IS NULL)
                ORDER BY s.ScheduleDateTime ASC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':date' => $selectedDate,
            ':instructorId' => $instructorId
        ]);
        $todaySchedule = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $announcement = new Announcement();
        $teacherAnnouncements = $announcement->getForTarget('teacher');
    } catch (PDOException $e) {
        $errorMsg = "Fout bij ophalen rooster: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DriveSmart - Instructeur Dashboard</title>
    <link rel="stylesheet" href="../Styling/homepageinstructor.css">
</head>
<body>
    <nav class="top-nav">
        <ul>
            <li><a href="HomepageInstructor.php">Home</a></li>
            <li><a href="weekrooster.php">Weekrooster</a></li>
            <li><a href="kilometersinv.php">Kilometerstand invoeren</a></li>
            <li><a href="ziekmeld.php">Ziek melden</a></li>
            <li><a href="../Database/logout.php">Uitloggen</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="welcome-box d-flex justify-content-between align-items-center">
            <div>
                <h2>Welkom, <?= htmlspecialchars($instructorName) ?>!</h2>
                <span class="badge bg-info text-dark">Ingelogd als instructeur</span>
                <p class="mb-0">Hieronder vind je jouw dagrooster met alle lessen voor vandaag.</p>
            </div>
            <div class="d-flex flex-column gap-2">
                <a class="btn btn-outline-primary btn-sm" href="weekrooster.php">Weekrooster / nieuwe les</a>
                <a class="btn btn-outline-secondary btn-sm" href="day-schedule.php">Volledige lessenlijst</a>
                <a class="btn btn-outline-dark btn-sm" href="print-dayrooster.php?date=<?= htmlspecialchars($selectedDate) ?>" target="_blank">Print dagrooster</a>
                <a class="btn btn-outline-warning btn-sm" href="weekrooster.php#defect">Mankement melden</a>
                <a class="btn btn-outline-success btn-sm" href="kilometersinv.php">Kilometerstand invoeren</a>
                <a class="btn btn-outline-danger btn-sm" href="ziekmeld.php">Ziek melden</a>
            </div>
        </div>

        <h1>Dagrooster - <?= date('l d F Y', strtotime($selectedDate)) ?></h1>

        <div class="header-controls">
            <form method="get" class="date-picker">
                <label for="date">Selecteer datum:</label>
                <input type="date" id="date" name="date" value="<?= htmlspecialchars($selectedDate) ?>">
                <button type="submit" class="btn">Toon</button>
            </form>

            <a href="?date=<?= date('Y-m-d') ?>" class="btn">Vandaag</a>
            <a href="weekrooster.php" class="btn">Bekijk weekrooster</a>
        </div>

        <?php if (isset($errorMsg)): ?>
            <div class="error"><?= htmlspecialchars($errorMsg) ?></div>
        <?php endif; ?>

        <?php if (!$instructorId): ?>
            <div class="error">Je bent niet ingelogd als instructeur. Log opnieuw in.</div>
        <?php elseif (empty($todaySchedule)): ?>
            <div class="empty">
                <p><strong>Geen lessen ingepland voor deze dag.</strong></p>
                <p>Geniet van je vrije tijd!</p>
            </div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Tijd</th>
                        <th>Leerling</th>
                        <th>Auto</th>
                        <th>Ophaalplaats</th>
                        <th>Onderwerp</th>
                        <th>Status</th>
                        <th>Acties</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($todaySchedule as $lesson): 
                    $dateTime = new DateTime($lesson['ScheduleDateTime']);
                ?>
                        <tr>
                            <td>
                                <span class="time-badge"><?= $dateTime->format('H:i') ?></span>
                            </td>
                            <td><?= htmlspecialchars($lesson['StudentsName'] ?? 'Onbekend') ?></td>
                            <td><?= htmlspecialchars($lesson['ScheduleCar'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($lesson['SchedulePickLoc'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '-') ?></td>
                            <td>
                                <span class="status-badge status-planned">
                                    <?= htmlspecialchars(ucfirst($lesson['ScheduleStatus'] ?? 'planned')) ?>
                                </span>
                            </td>
                            <td>
                                <div class="d-flex flex-column gap-1">
                                    <a class="btn btn-sm btn-outline-primary" href="instructor-lesson-remark.php?id=<?= (int)$lesson['idSchedule'] ?>">Opmerking</a>
                                    <a class="btn btn-sm btn-outline-warning" href="instructor-lesson-edit.php?id=<?= (int)$lesson['idSchedule'] ?>">Aanpassen</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div style="margin-top: 20px; padding: 12px; background: #d4edda; border-radius: 8px; color: #155724;">
                <strong>Totaal vandaag:</strong> <?= count($todaySchedule) ?> les(sen)
            </div>
        <?php endif; ?>
    </div>

    <div class="container mt-4">
        <h3>Mededelingen voor instructeurs</h3>
        <?php if (empty($teacherAnnouncements)): ?>
            <p class="text-muted">Geen mededelingen.</p>
        <?php else: ?>
            <?php foreach ($teacherAnnouncements as $a): ?>
                <div class="card mb-2">
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($a['Title']) ?></h5>
                        <p class="card-text"><?= htmlspecialchars($a['Message']) ?></p>
                        <small class="text-muted"><?= htmlspecialchars($a['CreatedAt']) ?></small>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>
