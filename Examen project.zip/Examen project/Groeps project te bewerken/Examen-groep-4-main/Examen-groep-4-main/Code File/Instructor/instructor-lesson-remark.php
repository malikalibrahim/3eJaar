<?php
// Bootstrap: zoek omhoog naar project root config.php en include indien aanwezig
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../includes/Algemeen/schedule-class.php';
session_start();

if (!isset($_SESSION['teacher_id'])) {
    header('Location: login.php');
    exit;
}

$scheduleId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$schedule = new Schedule();
$lesson = $schedule->getById($scheduleId);

if (!$lesson || (int)$lesson['ScheduleTeacherId'] !== (int)$_SESSION['teacher_id']) {
    http_response_code(403);
    echo "Je mag voor deze les geen opmerking plaatsen.";
    exit;
}

$message = '';
$messageType = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $remark = htmlspecialchars($_POST['remark'] ?? '');
    if ($remark === '') {
        $message = 'Opmerking mag niet leeg zijn.';
        $messageType = 'danger';
    } else {
        try {
            $schedule->addTeacherRemark($scheduleId, $remark);
            $message = 'Opmerking succesvol toegevoegd.';
            $messageType = 'success';
        } catch (Exception $e) {
            $message = 'Fout bij het opslaan van de opmerking: ' . $e->getMessage();
            $messageType = 'danger';
        }
    }
}

$pageTitle = "Opmerking Toevoegen";
require_once __DIR__ . '/../Admin/header.php';
?>

<div class="card mx-auto" style="max-width: 600px;">
    <div class="card-header">
        <h2 class="mb-0">Opmerking toevoegen</h2>
    </div>
    <div class="card-body">
        <p class="text-muted text-center">Les op: <strong><?= htmlspecialchars($lesson['ScheduleDateTime']) ?></strong></p>
        <?php if ($message): ?>
            <div class="alert alert-<?= $messageType ?>"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="mb-3">
                <label for="remark" class="form-label">Jouw opmerking over de les</label>
                <textarea id="remark" name="remark" class="form-control" rows="4" required></textarea>
            </div>
            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-primary">Opmerking opslaan</button>
                <a href="HomepageInstructor.php" class="btn btn-secondary">Terug naar dashboard</a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../Admin/footer.php'; ?>
