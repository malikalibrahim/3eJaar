<?php
session_start();
require_once __DIR__ . '/../../Database/database.php';

$db = new Database('127.0.0.1', 'drivesmart', 'root', '');
$pdo = $db->getPdo();

$melding = '';
$meldingClass = 'info';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $naam = $_POST['naam'] ?? '';
    $datum = $_POST['datum'] ?? '';
    $reden = $_POST['reden'] ?? '';

    if (empty($naam) || empty($datum) || empty($reden)) {
        $melding = "Vul alle verplichte velden in.";
        $meldingClass = 'error';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT idTeachers FROM teachers WHERE TeachersName = :naam LIMIT 1");
            $stmt->execute([':naam' => $naam]);
            $result = $stmt->fetch();
            $instructeur_id = $result['idTeachers'] ?? null;

            if (!$instructeur_id) {
                $melding = "Instructeur niet gevonden in het systeem.";
                $meldingClass = 'error';
            } else {
                $stmt = $pdo->prepare("
                    INSERT INTO ziekmelding (instructeur_id, datum, tijd, reden) 
                    VALUES (:instructeur_id, :datum, :tijd, :reden)
                ");
                $stmt->execute([
                    ':instructeur_id' => $instructeur_id,
                    ':datum' => $datum,
                    ':tijd' => date('H:i:s'),
                    ':reden' => $reden
                ]);
                $melding = "Ziekmelding succesvol opgeslagen voor instructeur: $naam op $datum.";
                $meldingClass = 'success';
            }
        } catch (PDOException $e) {
            $melding = "Fout bij het opslaan: " . $e->getMessage();
            $meldingClass = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ziekmelding Instructeur - DriveSmart</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: linear-gradient(135deg, #1e90ff, #6E8B3D, #d5e643ff);
            min-height: 100vh;
            padding: 20px;
        }

        .top-nav {
            background: linear-gradient(135deg, #1e90ff, #00b894);
            border-radius: 10px;
            padding: 12px 20px;
            margin-bottom: 20px;
            max-width: 1200px;
            margin-left: auto;
            margin-right: auto;
        }

        .top-nav ul {
            list-style: none;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .top-nav a {
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 6px;
            font-weight: 600;
            transition: background 0.2s;
        }

        .top-nav a:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        .content-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px 0;
        }

        .container {
            background: #ffffffee;
            padding: 30px 35px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
            max-width: 450px;
            width: 100%;
        }

        .logo {
            text-align: center;
            margin-bottom: 20px;
        }

        .logo h1 {
            margin: 0;
            font-size: 26px;
            letter-spacing: 1px;
            color: #2c3e50;
        }

        .logo span {
            font-size: 13px;
            color: #7f8c8d;
        }

        h2 {
            margin-top: 20px;
            margin-bottom: 10px;
            font-size: 20px;
            text-align: center;
            color: #34495e;
        }

        form {
            margin-top: 10px;
        }

        label {
            display: block;
            margin-top: 12px;
            margin-bottom: 5px;
            font-size: 14px;
            color: #555;
        }

        input[type="text"],
        input[type="date"],
        textarea {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #dcdde1;
            border-radius: 8px;
            font-size: 14px;
            box-sizing: border-box;
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        input[type="text"]:focus,
        input[type="date"]:focus,
        textarea:focus {
            outline: none;
            border-color: #1e90ff;
            box-shadow: 0 0 0 2px rgba(30, 144, 255, 0.15);
        }

        textarea {
            min-height: 80px;
            resize: vertical;
            font-family: Arial, sans-serif;
        }

        .btn-submit {
            margin-top: 18px;
            width: 100%;
            padding: 11px;
            border: none;
            border-radius: 25px;
            font-size: 15px;
            font-weight: bold;
            color: #fff;
            background: linear-gradient(135deg, #1e90ff, #00b894);
            cursor: pointer;
            transition: transform 0.1s, box-shadow 0.1s, opacity 0.2s;
        }

        .btn-submit:hover {
            opacity: 0.95;
            box-shadow: 0 8px 18px rgba(0, 0, 0, 0.15);
            transform: translateY(-1px);
        }

        .btn-submit:active {
            transform: translateY(1px);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.18);
        }

        .footer-text {
            margin-top: 15px;
            text-align: center;
            font-size: 12px;
            color: #95a5a6;
        }

        .melding {
            margin-top: 10px;
            padding: 12px 15px;
            border-radius: 8px;
            font-size: 14px;
            line-height: 1.4;
        }

        .melding.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .melding.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .melding.info {
            background: #ffeaa7;
            color: #2d3436;
            border: 1px solid #fdcb6e;
        }

        .naam-hint {
            font-size: 11px;
            color: #7f8c8d;
            margin-top: 3px;
            font-style: italic;
        }

        @media (max-width: 768px) {
            .top-nav ul {
                flex-direction: column;
                gap: 8px;
            }

            .container {
                margin: 15px;
                padding: 25px 20px;
            }
        }
    </style>
</head>

<body>
    <nav class="top-nav">
        <ul>
            <li><a href="HomepageInstructor.php">Home</a></li>
            <li><a href="weekrooster.php">Weekrooster</a></li>
            <li><a href="kilometersinv.php">Kilometerstand invoeren</a></li>
            <li><a href="ziekmeld.php">Ziek melden</a></li>
            <li><a href="../Database/logout.php">Uitloggen</a></li>
        </ul>
    </nav>

    <div class="content-wrapper">
        <div class="container">
            <div class="logo">
                <h1>Ziekmelding</h1>
                <span>Meld je ziek als instructeur</span>
            </div>

            <h2>Ziekmelden</h2>

            <?php if (!empty($melding)): ?>
                <div class="melding <?php echo $meldingClass; ?>">
                    <?php echo htmlspecialchars($melding, ENT_QUOTES, 'UTF-8'); ?>
                </div>
            <?php endif; ?>

            <form method="post" action="">
                <label for="naam">Naam Instructeur</label>
                <input type="text" id="naam" name="naam" placeholder="Voor- en achternaam" required>
                <div class="naam-hint">
                    Gebruik je volledige naam zoals geregistreerd in het systeem
                </div>

                <label for="datum">Datum ziekmelding</label>
                <input type="date" id="datum" name="datum" required value="<?php echo date('Y-m-d'); ?>">

                <label for="reden">Reden / Toelichting</label>
                <textarea id="reden" name="reden" placeholder="Bijvoorbeeld: griep, verkoudheid, andere reden..." required></textarea>

                <button type="submit" class="btn-submit">Ziekmelding verzenden</button>
            </form>

            <div class="footer-text">
                Je ziekmelding wordt geregistreerd in de database. Neem bij spoed ook telefonisch contact op met de rijschool.
            </div>
        </div>
    </div>
</body>

</html>