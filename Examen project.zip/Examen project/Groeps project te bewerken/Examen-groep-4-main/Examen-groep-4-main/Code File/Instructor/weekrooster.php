<?php
session_start();
require_once __DIR__ . '/../../Database/database.php';


$db = new Database('127.0.0.1', 'drivesmart', 'root', '');
$pdo = $db->getPdo();


$instructorId = $_SESSION['user_id'] ?? null;
$instructorName = $_SESSION['user_name'] ?? 'Instructeur';

if (!$instructorId) {
    die('Je moet ingelogd zijn als instructeur om deze pagina te bekijken.');
}

$errors = [];
$successMessage = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   
    if (isset($_POST['delete_lesson'])) {
        $lessonId = (int) $_POST['lesson_id'];
        try {
            $stmt = $pdo->prepare("DELETE FROM schedule WHERE idSchedule = :id AND ScheduleTeacherId = :teacherId");
            $stmt->execute([':id' => $lessonId, ':teacherId' => $instructorId]);
            $successMessage = 'Les succesvol verwijderd!';
        } catch (PDOException $e) {
            $errors[] = 'Les kon niet worden verwijderd: ' . $e->getMessage();
        }
    }
    
    elseif (isset($_POST['create_lesson'])) {
        $studentId = (int) ($_POST['student_id'] ?? 0);
        $date = $_POST['date'] ?? '';
        $startTime = $_POST['start_time'] ?? '';
        $endTime = $_POST['end_time'] ?? '';
        $pickupLoc = $_POST['pickup_loc'] ?? '';
        $subject = $_POST['subject'] ?? '';
        $teacherRemark = $_POST['teacher_remark'] ?? '';
        
        if (!$studentId) {
            $errors[] = 'Kies een leerling.';
        }
        if (!$date || !$startTime || !$endTime) {
            $errors[] = 'Datum, begintijd en eindtijd zijn verplicht.';
        }

        if (empty($errors)) {
            try {
                $dateTime = new DateTime("$date $startTime");
                $endDateTime = new DateTime("$date $endTime");

                if ($endDateTime <= $dateTime) {
                    $errors[] = 'Eindtijd moet later zijn dan begintijd.';
                } else {
                    $stmt = $pdo->prepare("
                        INSERT INTO schedule (ScheduleDateTime, SchedulePickLoc, 
                                            ScheduleStudentId, ScheduleTeacherId, ScheduleSubject, 
                                            ScheduleStatus, ScheduleTeacherRemark)
                        VALUES (:datetime, :pickup, :studentId, :teacherId, :subject, 
                                'planned', :teacherRemark)
                    ");
                    $stmt->execute([
                        ':datetime' => $dateTime->format('Y-m-d H:i:s'),
                        ':pickup' => $pickupLoc,
                        ':studentId' => $studentId,
                        ':teacherId' => $instructorId,
                        ':subject' => $subject,
                        ':teacherRemark' => $teacherRemark
                    ]);
                    $successMessage = 'Les succesvol aangemaakt!';
                }
            } catch (Exception $e) {
                $errors[] = 'Fout bij aanmaken les: ' . $e->getMessage();
            }
        }
    }

    elseif (isset($_POST['report_defect'])) {
        $carId = (int) ($_POST['car_id'] ?? 0);
        $defectDescription = trim($_POST['defect_description'] ?? '');
        
        if (!$carId) {
            $errors[] = 'Kies een auto.';
        }
        if (empty($defectDescription)) {
            $errors[] = 'Beschrijf het mankement.';
        }

        if (empty($errors)) {
            try {
                $stmt = $pdo->prepare("SELECT CarsWear FROM cars WHERE idCars = :carId");
                $stmt->execute([':carId' => $carId]);
                $car = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($car) {
                    $currentWear = $car['CarsWear'];
                    $newWear = $currentWear;
                    
                    if (!empty($currentWear)) {
                        $newWear = $currentWear . ' | ' . $defectDescription;
                    } else {
                        $newWear = $defectDescription;
                    }
                    
                    $stmt = $pdo->prepare("
                        UPDATE cars 
                        SET CarsWear = :wear, CarsMaintenance = 1 
                        WHERE idCars = :carId
                    ");
                    $stmt->execute([
                        ':wear' => $newWear,
                        ':carId' => $carId
                    ]);
                    
                    $successMessage = 'Mankement succesvol gemeld! Auto is nu gemarkeerd voor onderhoud.';
                } else {
                    $errors[] = 'Auto niet gevonden.';
                }
            } catch (Exception $e) {
                $errors[] = 'Fout bij melden mankement: ' . $e->getMessage();
            }
        }
    }
}


$week = $_GET['week'] ?? date('o-\WW');
$weekYear = substr($week, 0, 4);
$weekNr = substr($week, 6, 2);

$weekStart = new DateTime();
$weekStart->setISODate((int) $weekYear, (int) $weekNr);
$weekEnd = (clone $weekStart)->modify('+7 days');


try {
    $stmt = $pdo->prepare("
        SELECT s.*, 
               st.StudentsName
        FROM schedule s
        LEFT JOIN students st ON s.ScheduleStudentId = st.idStudents
        WHERE s.ScheduleTeacherId = :teacherId
          AND s.ScheduleDateTime >= :weekStart
          AND s.ScheduleDateTime < :weekEnd
        ORDER BY s.ScheduleDateTime ASC
    ");
    $stmt->execute([
        ':teacherId' => $instructorId,
        ':weekStart' => $weekStart->format('Y-m-d 00:00:00'),
        ':weekEnd' => $weekEnd->format('Y-m-d 00:00:00')
    ]);
    $lessons = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $errors[] = 'Fout bij ophalen lessen: ' . $e->getMessage();
    $lessons = [];
}


try {
    $stmt = $pdo->query("SELECT idStudents, StudentsName FROM students ORDER BY StudentsName");
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $students = [];
}


try {
    $stmt = $pdo->query("SELECT idCars, CarsType, CarLicensep, CarsMaintenance FROM cars ORDER BY CarsType");
    $cars = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $cars = [];
}


$prevWeek = (clone $weekStart)->modify('-1 week')->format('o-\WW');
$nextWeek = (clone $weekStart)->modify('+1 week')->format('o-\WW');
$currentWeek = (new DateTime())->format('o-\WW');
?>
<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <title>DriveSmart - Weekrooster</title>
    <style>
        * {
            box-sizing: border-box;
            font-family: system-ui, -apple-system, sans-serif;
        }

        body {
            margin: 0;
            min-height: 100vh;
            background: linear-gradient(135deg, #1e90ff, #6E8B3D, #d5e643ff);
            padding: 40px 10px;
        }

        .page-wrapper {
            max-width: 1400px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 16px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
            padding: 30px;
        }

        h1 {
            margin: 0 0 5px;
            font-size: 28px;
            color: #123;
        }

        .subtitle {
            margin: 0 0 16px;
            color: #555;
            font-size: 14px;
        }

        .layout {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 24px;
            margin-bottom: 24px;
        }

        @media (max-width: 1100px) {
            .layout {
                grid-template-columns: 1fr;
            }
        }

        .card {
            background: #fff;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        }

        .card-header-title {
            font-weight: 600;
            font-size: 16px;
            margin-bottom: 8px;
        }

        .card-header-subtitle {
            font-size: 13px;
            color: #666;
            margin-bottom: 12px;
        }

        .week-nav {
            margin: 8px 0 14px;
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .btn-link {
            display: inline-block;
            border-radius: 999px;
            padding: 6px 12px;
            font-size: 13px;
            border: 1px solid #ccc;
            color: #234;
            text-decoration: none;
            background: #f8f8f8;
        }

        .btn-link:hover {
            background: #eee;
        }

        .btn-link.primary {
            background: #0057b8;
            color: #fff;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        th {
            background: #f2f4f8;
            font-weight: 600;
        }

        tr:hover td {
            background: #f9f9f9;
        }

        .empty-row td {
            text-align: center;
            color: #777;
            padding: 30px;
        }

        .btn-delete {
            background: #dc3545;
            color: white;
            border: none;
            border-radius: 6px;
            padding: 6px 12px;
            font-size: 12px;
            cursor: pointer;
        }

        form {
            display: grid;
            gap: 12px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        label {
            font-size: 13px;
            font-weight: 500;
        }

        input, select, textarea {
            padding: 8px 10px;
            border-radius: 6px;
            border: 1px solid #cfd3dc;
            font-size: 13px;
        }

        button[type="submit"] {
            margin-top: 8px;
            padding: 10px;
            border-radius: 999px;
            border: none;
            font-weight: 600;
            background: linear-gradient(135deg, #0cc334ff, #177eccff);
            color: #fff;
            cursor: pointer;
        }

        .alert {
            border-radius: 8px;
            padding: 10px;
            margin-bottom: 12px;
            font-size: 13px;
        }

        .alert-success {
            background: #e5f8eb;
            color: #155c2b;
        }

        .alert-error {
            background: #fdeaea;
            color: #8a1f1f;
        }

        .nav-links {
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
        }

        .nav-links a {
            padding: 8px 16px;
            background: #1597cfff;
            color: white;
            text-decoration: none;
            border-radius: 8px;
        }

        .maintenance-badge {
            display: inline-block;
            background: #ffc107;
            color: #000;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 11px;
            margin-left: 6px;
        }

        .defect-section {
            margin-top: 24px;
        }
    </style>
</head>

<body>
    <div class="page-wrapper">
        <div class="nav-links">
            <a href="HomepageInstructor.php">Home</a>
            <a href="weekrooster.php">Weekrooster</a>
            <a href="kilometersinv.php">Kilometerstand invoeren</a>
            <a href="ziekmeld.php">Ziek melden</a>
            <a href="../Database/logout.php">Uitloggen</a>
        </div>

        <h1>DriveSmart - Weekrooster</h1>
        <p class="subtitle">Ingelogd als: <?= htmlspecialchars($instructorName) ?> (ID: <?= $instructorId ?>)</p>

        <?php if ($successMessage): ?>
            <div class="alert alert-success"><?= htmlspecialchars($successMessage) ?></div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <strong>Fouten:</strong>
                <ul style="margin: 4px 0 0; padding-left: 20px;">
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="layout">
            <div class="card">
                <div class="card-header-title">Weekrooster</div>
                <div class="card-header-subtitle">
                    Week <?= htmlspecialchars($week) ?> (<?= $weekStart->format('d-m-Y') ?>)
                </div>

                <div class="week-nav">
                    <a class="btn-link" href="?week=<?= $prevWeek ?>">◀ Vorige</a>
                    <a class="btn-link primary" href="?week=<?= $currentWeek ?>">Deze week</a>
                    <a class="btn-link" href="?week=<?= $nextWeek ?>">Volgende ▶</a>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th>Datum/Tijd</th>
                            <th>Leerling</th>
                            <th>Ophaal</th>
                            <th>Onderwerp</th>
                            <th>Status</th>
                            <th>Actie</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($lessons)): ?>
                            <tr class="empty-row">
                                <td colspan="6">Geen lessen gepland</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($lessons as $lesson): 
                                $dt = new DateTime($lesson['ScheduleDateTime']);
                            ?>
                                <tr>
                                    <td><?= $dt->format('d-m H:i') ?></td>
                                    <td><?= htmlspecialchars($lesson['StudentsName'] ?? '—') ?></td>
                                    <td><?= htmlspecialchars($lesson['SchedulePickLoc'] ?? '—') ?></td>
                                    <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '—') ?></td>
                                    <td><?= htmlspecialchars($lesson['ScheduleStatus'] ?? 'planned') ?></td>
                                    <td>
                                        <form method="post" style="display:inline;" onsubmit="return confirm('Verwijderen?');">
                                            <input type="hidden" name="lesson_id" value="<?= $lesson['idSchedule'] ?>">
                                            <input type="hidden" name="delete_lesson" value="1">
                                            <button type="submit" class="btn-delete">×</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div>
                <div class="card">
                    <div class="card-header-title">Nieuwe les</div>

                    <form method="post">
                        <input type="hidden" name="create_lesson" value="1">

                        <div class="form-group">
                            <label>Leerling *</label>
                            <select name="student_id" required>
                                <option value="">Kies leerling</option>
                                <?php foreach ($students as $s): ?>
                                    <option value="<?= $s['idStudents'] ?>"><?= htmlspecialchars($s['StudentsName']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Datum *</label>
                            <input type="date" name="date" required value="<?= date('Y-m-d') ?>">
                        </div>

                        <div class="form-group">
                            <label>Begintijd *</label>
                            <input type="time" name="start_time" required>
                        </div>

                        <div class="form-group">
                            <label>Eindtijd *</label>
                            <input type="time" name="end_time" required>
                        </div>

                        <div class="form-group">
                            <label>Ophaallocatie</label>
                            <input type="text" name="pickup_loc" placeholder="Adres">
                        </div>

                        <div class="form-group">
                            <label>Onderwerp</label>
                            <input type="text" name="subject" placeholder="Bijv. Parkeren">
                        </div>

                        <div class="form-group">
                            <label>Opmerking instructeur</label>
                            <textarea name="teacher_remark" rows="2"></textarea>
                        </div>

                        <button type="submit">Les opslaan</button>
                    </form>
                </div>

                
                <div class="card defect-section">
                    <div class="card-header-title">Mankement melden</div>

                    <form method="post">
                        <input type="hidden" name="report_defect" value="1">

                        <div class="form-group">
                            <label>Auto *</label>
                            <select name="car_id" required>
                                <option value="">Kies auto</option>
                                <?php foreach ($cars as $car): ?>
                                    <option value="<?= $car['idCars'] ?>">
                                        <?= htmlspecialchars($car['CarsType']) ?> 
                                        (<?= htmlspecialchars($car['CarLicensep'] ?? 'Geen kenteken') ?>)
                                        <?php if ($car['CarsMaintenance'] == 1): ?>
                                            <span class="maintenance-badge">⚠ Onderhoud</span>
                                        <?php endif; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Beschrijving mankement *</label>
                            <textarea name="defect_description" rows="3" required placeholder="Beschrijf het mankement in detail..."></textarea>
                        </div>

                        <button type="submit" style="background: linear-gradient(135deg, #dc3545, #c82333);">Mankement melden</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>