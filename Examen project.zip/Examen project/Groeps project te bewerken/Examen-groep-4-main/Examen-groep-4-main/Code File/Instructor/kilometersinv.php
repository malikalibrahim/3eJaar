<?php
session_start();
require_once __DIR__ . '/../../Database/database.php';


$db = new Database('127.0.0.1', 'drivesmart', 'root', '');
$pdo = $db->getPdo();


$instructorId = $_SESSION['user_id'] ?? null;
$instructorName = $_SESSION['user_name'] ?? 'Instructeur';

if (!$instructorId) {
    die('Je moet ingelogd zijn als instructeur om deze pagina te bekijken.');
}

$errors = [];
$successMessage = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_odo'])) {
    $carId = (int) ($_POST['car_id'] ?? 0);
    $newOdo = (int) ($_POST['odo_value'] ?? 0);
    
    if (!$carId) {
        $errors[] = 'Kies een auto.';
    }
    if ($newOdo <= 0) {
        $errors[] = 'Voer een geldige kilometerstand in.';
    }
    
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("SELECT CarsODO, CarsType FROM cars WHERE idCars = :carId");
            $stmt->execute([':carId' => $carId]);
            $car = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($car) {
                $currentOdo = (int) $car['CarsODO'];
                
                if ($newOdo < $currentOdo) {
                    $errors[] = "Nieuwe kilometerstand ($newOdo km) kan niet lager zijn dan de huidige stand ($currentOdo km).";
                } else {
                    $stmt = $pdo->prepare("UPDATE cars SET CarsODO = :odo WHERE idCars = :carId");
                    $stmt->execute([
                        ':odo' => $newOdo,
                        ':carId' => $carId
                    ]);
                    
                    $kmDriven = $newOdo - $currentOdo;
                    $successMessage = "Kilometerstand bijgewerkt. {$car['CarsType']}: $currentOdo km → $newOdo km (+$kmDriven km gereden)";
                }
            } else {
                $errors[] = 'Auto niet gevonden.';
            }
        } catch (Exception $e) {
            $errors[] = 'Fout bij bijwerken kilometerstand: ' . $e->getMessage();
        }
    }
}


try {
    $stmt = $pdo->query("SELECT idCars, CarsType, CarLicensep, CarsODO, CarsMaintenance FROM cars ORDER BY CarsType");
    $cars = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $cars = [];
    $errors[] = 'Fout bij ophalen auto\'s: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <title>DriveSmart - Kilometerstand</title>
    <link rel="stylesheet" href="../Styling/kilometers.css">
</head>

<body>
    <div class="page-wrapper">
        <div class="nav-links">
            <a href="HomepageInstructor.php">← Home</a>
            <a href="weekrooster.php">Les inplannen</a>
            <a href="weekrooster.php">Mankementen melden</a>
            <a href="../Database/logout.php">Uitloggen</a>
        </div>

        <h1>Kilometerstand Bijwerken</h1>
        <p class="subtitle">Ingelogd als: <?= htmlspecialchars($instructorName) ?></p>

        <?php if ($successMessage): ?>
            <div class="alert alert-success"><?= htmlspecialchars($successMessage) ?></div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <strong>Fouten:</strong>
                <ul style="margin: 4px 0 0; padding-left: 20px;">
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

    
        <div class="card">
            <div class="card-header-title">Huidige Kilometerstanden</div>
            
            <table>
                <thead>
                    <tr>
                        <th>Auto</th>
                        <th>Kenteken</th>
                        <th>Kilometerstand</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($cars)): ?>
                        <tr>
                            <td colspan="4" style="text-align: center; color: #777;">Geen auto's gevonden</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($cars as $car): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($car['CarsType']) ?></strong></td>
                                <td><?= htmlspecialchars($car['CarLicensep'] ?? '—') ?></td>
                                <td>
                                    <span class="odo-badge">
                                        <?= number_format($car['CarsODO'] ?? 0, 0, ',', '.') ?> km
                                    </span>
                                </td>
                                <td>
                                    <?php if ($car['CarsMaintenance'] == 1): ?>
                                        <span class="maintenance-badge">⚠ Onderhoud nodig</span>
                                    <?php else: ?>
                                        <span style="color: #28a745;">✓ Beschikbaar</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>


        <div class="card">
            <div class="card-header-title">Kilometerstand Invoeren</div>

            <form method="post">
                <input type="hidden" name="update_odo" value="1">

                <div class="form-group">
                    <label for="car_id">Kies auto *</label>
                    <select name="car_id" id="car_id" required onchange="updateCurrentOdo(this)">
                        <option value="">-- Selecteer een auto --</option>
                        <?php foreach ($cars as $car): ?>
                            <option value="<?= $car['idCars'] ?>" 
                                    data-odo="<?= $car['CarsODO'] ?? 0 ?>"
                                    data-type="<?= htmlspecialchars($car['CarsType']) ?>">
                                <?= htmlspecialchars($car['CarsType']) ?> 
                                (<?= htmlspecialchars($car['CarLicensep'] ?? 'Geen kenteken') ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="odo_value">Nieuwe kilometerstand (km) *</label>
                    <input 
                        type="number" 
                        name="odo_value" 
                        id="odo_value" 
                        required 
                        min="0" 
                        step="1"
                        placeholder="Bijv. 45320"
                    >
                    <p class="helper-text" id="current-odo-text">Selecteer eerst een auto</p>
                </div>

                <button type="submit">Kilometerstand Opslaan</button>
            </form>
        </div>
    </div>

    <script>
        function updateCurrentOdo(selectElement) {
            const selectedOption = selectElement.options[selectElement.selectedIndex];
            const currentOdo = selectedOption.getAttribute('data-odo');
            const carType = selectedOption.getAttribute('data-type');
            const helperText = document.getElementById('current-odo-text');
            
            if (currentOdo && carType) {
                helperText.textContent = `Huidige stand ${carType}: ${parseInt(currentOdo).toLocaleString('nl-NL')} km`;
                helperText.style.color = '#0057b8';
                helperText.style.fontWeight = '600';
            } else {
                helperText.textContent = 'Selecteer eerst een auto';
                helperText.style.color = '#666';
                helperText.style.fontWeight = 'normal';
            }
        }
    </script>
</body>

</html>