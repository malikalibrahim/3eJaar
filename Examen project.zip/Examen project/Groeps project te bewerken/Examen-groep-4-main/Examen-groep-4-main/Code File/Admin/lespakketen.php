<?php
session_start();


if (!isset($_SESSION['custom_packages'])) {
    $_SESSION['custom_packages'] = [];
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lessons = $_POST['lessons'] ?? '';
    $price = $_POST['price'] ?? '';
    
    if (!empty($lessons) && !empty($price) && $lessons > 0 && $price > 0) {
        $_SESSION['custom_packages'][] = [
            'lessons' => $lessons,
            'price' => $price
        ];
    }
}
?>
<!doctype html>
<html lang="nl">

<head>
  <meta charset="utf-8">
  <title>Lespakketten — DriveSmart</title>
  <link rel="stylesheet" href="../Styling/lespakketten.css">
</head>

<body>
  <nav class="navbar">
    <div class="nav-inner">
      <ul class="nav-links">
          <li><a href="HomepageAdmin.php">Home</a></li>
            <li><a href="#">Mededelingen</a></li>
            <li><a href="Wagenpark.php">Wagenpark</a></li>
            <li><a href="../Database/logout.php">Uitloggen</a></li>
      </ul>
    </div>
  </nav>

  <div class="container">
    <section class="hero">
      <h1 class="main-title">DriveSmart Rijlespakketten</h1>
    </section>

   
    <h1>Stel je eigen pakket samen</h1>
    
    <div class="custom-package">
      <h2>Maak je eigen pakket</h2>
      
      <form method="POST" action="">
        <div class="input-group">
          <label for="lessons">Aantal rijlessen:</label>
          <input type="number" id="lessons" name="lessons" min="1" placeholder="bijv. 10" required>
        </div>
        
        <div class="input-group">
          <label for="price">Prijs (€):</label>
          <input type="number" id="price" name="price" min="0" placeholder="bijv. 600" required>
        </div>
        
        <button type="submit">Pakket Toevoegen</button>
      </form>
    </div>

    
    <h1 style="margin-top: 60px;">Beschikbare pakketten</h1>

    <section style="margin-top:40px" class="img" role="banner" aria-label="DriveSmart banner">
      <div class="img-overlay"></div>
      <div class="img-content">
        <div class="grid" id="packagesGrid">
          <div class="card">
            <h2>Basis pakket</h2>
            <p>
              10 rijlessen van 50 min.<br><br>
              €599
            </p>
            <div class="button">
              <button>Bestellen</button>
            </div>
          </div>

          <div class="card">
            <h2>Standaard pakket</h2>
            <p>
              Gratis proefles t.w.v. €62<br><br>
              30 rijlessen van 50 min.<br><br>
              Praktijkexamen CBR<br><br>
              €2000
            </p>
            <div class="button">
              <button>Bestellen</button>
            </div>
          </div>

          <div class="card">
            <h2>Compleet pakket</h2>
            <p>
              Gratis proefles t.w.v. €62<br><br>
              40 rijlessen van 50 min.<br><br>
              Praktijkexamen CBR<br><br>
              €2400
            </p>
            <div class="button">
              <button>Bestellen</button>
            </div>
          </div>

          <?php foreach ($_SESSION['custom_packages'] as $package): ?>
            <div class="card">
              <h2>Eigen pakket</h2>
              <p>
                <?php echo htmlspecialchars($package['lessons']); ?> rijlessen van 50 min.<br><br>
                €<?php echo htmlspecialchars($package['price']); ?>
              </p>
              <div class="button">
                <button>Bestellen</button>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </section>
  </div>
</body>
</html>