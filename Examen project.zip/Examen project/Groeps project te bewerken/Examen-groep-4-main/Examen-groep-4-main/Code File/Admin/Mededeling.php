<?php
session_start();
$Admin_Name = $_SESSION['admin_name'] ?? ($_SESSION['user_name'] ?? 'Onbekend');
$Admin_ID = $_SESSION['admin_id'] ?? null;
if (!$Admin_ID) {
    header('Location: ../Database/login.php');
    exit;
}

require_once __DIR__ . '/../Database/db.php';
require_once __DIR__ . '/../Database/Admin-class.php';

$admin = new Admin($pdo);

$message = '';
$messageType = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        try {
            if ($_POST['action'] === 'create') {
                $titel = trim($_POST['titel'] ?? '');
                $inhoud = trim($_POST['inhoud'] ?? '');
                $target_audience = $_POST['target_audience'] ?? 'alle';
                $is_urgent = isset($_POST['is_urgent']) ? 1 : 0;

                if (empty($titel) || empty($inhoud)) {
                    throw new Exception('Titel en inhoud zijn verplicht.');
                }

               
                if (empty($Admin_ID)) {
                    throw new Exception('Admin niet ingelogd. Log in voordat u een mededeling aanmaakt.');
                }

                if ($admin->createMededeling($titel, $inhoud, $Admin_ID, $target_audience, $is_urgent)) {
                    $message = 'Mededeling succesvol aangemaakt!';
                    $messageType = 'success';
              
                    $_POST = [];
                } else {
                    throw new Exception('Fout bij het aanmaken van de mededeling.');
                }
            } elseif ($_POST['action'] === 'update') {
                $id = (int)$_POST['id'];
                $titel = trim($_POST['titel'] ?? '');
                $inhoud = trim($_POST['inhoud'] ?? '');
                $target_audience = $_POST['target_audience'] ?? 'alle';
                $is_urgent = isset($_POST['is_urgent']) ? 1 : 0;

                if (empty($titel) || empty($inhoud)) {
                    throw new Exception('Titel en inhoud zijn verplicht.');
                }

                if ($admin->updateMededeling($id, $titel, $inhoud, $target_audience, $is_urgent)) {
                    $message = 'Mededeling succesvol bijgewerkt!';
                    $messageType = 'success';
                    header('Location: Mededeling.php');
                    exit;
                } else {
                    throw new Exception('Fout bij het bijwerken van de mededeling.');
                }
            } elseif ($_POST['action'] === 'delete') {
                $id = (int)$_POST['id'];
                if ($admin->deleteMededeling($id)) {
                    $message = 'Mededeling succesvol verwijderd!';
                    $messageType = 'success';
                } else {
                    throw new Exception('Fout bij het verwijderen van de mededeling.');
                }
            }
        } catch (Exception $e) {
            $message = $e->getMessage();
            $messageType = 'error';
        }
    }
}
$editId = isset($_GET['edit']) ? (int)$_GET['edit'] : null;
$editData = null;
if ($editId) {
    $editData = $admin->getMededelingById($editId);
}

$mededelingen = $admin->getMededelingen();
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mededelingen Beheren - DriveSmart</title>
    <link rel="stylesheet" href="../Styling/Mededeling.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>📢 Mededelingen Beheren</h1>
            <p class="subtitle">Ingelogd als: <strong><?php echo htmlspecialchars($Admin_Name); ?></strong></p>
        </header>

        <?php if (!empty($message)): ?>
            <div class="alert alert-<?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <div class="content-wrapper">
         
            <section class="form-section">
                <h2><?php echo $editId ? 'Mededeling Bewerken' : 'Nieuwe Mededeling'; ?></h2>
                
                <form method="POST" class="mededeling-form">
                    <input type="hidden" name="action" value="<?php echo $editId ? 'update' : 'create'; ?>">
                    <?php if ($editId): ?>
                        <input type="hidden" name="id" value="<?php echo $editId; ?>">
                    <?php endif; ?>

                    <div class="form-group">
                        <label for="titel">Titel *</label>
                        <input 
                            type="text" 
                            id="titel" 
                            name="titel" 
                            required 
                            maxlength="255"
                            value="<?php echo $editData ? htmlspecialchars($editData['titel']) : ''; ?>"
                            placeholder="Bijv. Rijschool gesloten op maandag"
                        >
                    </div>

                    <div class="form-group">
                        <label for="inhoud">Inhoud *</label>
                        <textarea 
                            id="inhoud" 
                            name="inhoud" 
                            required 
                            rows="6"
                            placeholder="Voer hier uw mededeling in..."
                        ><?php echo $editData ? htmlspecialchars($editData['inhoud']) : ''; ?></textarea>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="target_audience">Zichtbaar voor *</label>
                            <select id="target_audience" name="target_audience" required>
                                <option value="alle" <?php echo (!$editData || $editData['target_audience'] === 'alle') ? 'selected' : ''; ?>>Iedereen</option>
                                <option value="instructeurs" <?php echo ($editData && $editData['target_audience'] === 'instructeurs') ? 'selected' : ''; ?>>Alleen Instructeurs</option>
                                <option value="studenten" <?php echo ($editData && $editData['target_audience'] === 'studenten') ? 'selected' : ''; ?>>Alleen Studenten</option>
                            </select>
                        </div>

                        <div class="form-group checkbox">
                            <label>
                                <input 
                                    type="checkbox" 
                                    name="is_urgent" 
                                    value="1"
                                    <?php echo ($editData && $editData['is_urgent']) ? 'checked' : ''; ?>
                                >
                                🔴 Urgent
                            </label>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">
                            <?php echo $editId ? '✏️ Bijwerken' : '➕ Plaatsen'; ?>
                        </button>
                        <?php if ($editId): ?>
                            <a href="Mededeling.php" class="btn btn-secondary">Annuleren</a>
                        <?php endif; ?>
                    </div>
                </form>
            </section>

         
            <section class="list-section">
                <h2>Alle Mededelingen (<?php echo count($mededelingen); ?>)</h2>

                <?php if (empty($mededelingen)): ?>
                    <div class="empty-state">
                        <p>Nog geen mededelingen geplaatst.</p>
                    </div>
                <?php else: ?>
                    <div class="mededelingen-list">
                        <?php foreach ($mededelingen as $med): ?>
                            <div class="mededeling-card <?php echo $med['is_urgent'] ? 'urgent' : ''; ?>">
                                <div class="card-header">
                                    <div class="header-info">
                                        <h3><?php echo htmlspecialchars($med['titel']); ?></h3>
                                        <div class="meta">
                                            <span class="audience-badge"><?php echo ucfirst(str_replace('_', ' ', $med['target_audience'])); ?></span>
                                            <?php if ($med['is_urgent']): ?>
                                                <span class="urgent-badge">🔴 URGENT</span>
                                            <?php endif; ?>
                                            <span class="date"><?php echo date('d-m-Y H:i', strtotime($med['datum_aangemaakt'])); ?></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="card-content">
                                    <p><?php echo nl2br(htmlspecialchars(substr($med['inhoud'], 0, 200))); ?><?php echo strlen($med['inhoud']) > 200 ? '...' : ''; ?></p>
                                </div>

                                <div class="card-actions">
                                    <a href="Mededeling.php?edit=<?php echo $med['id']; ?>" class="btn btn-small btn-edit">✏️ Bewerken</a>
                                    <form method="POST" style="display:inline;" onsubmit="return confirm('Weet u zeker dat u deze mededeling wilt verwijderen?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $med['id']; ?>">
                                        <button type="submit" class="btn btn-small btn-delete">🗑️ Verwijderen</button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>
        </div>

        <footer>
            <a href="HomepageAdmin.php" class="btn btn-secondary">← Terug naar Dashboard</a>
            <a href="../Database/logout.php" class="btn btn-logout">Uitloggen</a>
        </footer>
    </div>
</body>
</html>
