<?php
// Gebruik een pad naar de centrale DB-wrapper zodat zowel PDO als de DB helper-class geladen worden
require_once __DIR__ . '/../Database/db.php';

class Admin {
    private $db;

    public function __construct() {
        $this->db = new DB();
    }

    public function getTerms() {
        return $this->db->run(
            "SELECT AdminTerms FROM admin LIMIT 1"
        )->fetchColumn();
    }

    public function updateTerms($terms) {
        // simpele implementatie: update eerste admin-record
        return $this->db->run(
            "UPDATE admin SET AdminTerms = :terms LIMIT 1",
            ["terms" => $terms]
        );
    }
}
