<?php
session_start();
require_once __DIR__ . '/../../Database/database.php';
require_once __DIR__ . '/../Classes/Schedule.php';
require_once __DIR__ . '/../Classes/Lesson.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$db = new Database('127.0.0.1', 'drivesmart', 'root', '');
$pdo = $db->getPdo();

$schedule = new Schedule($pdo);
$lesson = new Lesson($pdo);

$todaySchedule = $schedule->getToday();
$lessons = $lesson->getAll();
$adminName = $_SESSION['admin_name'] ?? 'Admin';
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>DriveSmart - Admin</title>
    <link rel="stylesheet" href="../Styling/homepageadmin.css">
</head>
<body>
    <header class="img" role="banner" aria-label="DriveSmart banner">
        <div class="img-overlay"></div>
        <div class="img-content">
            <h1>Rijschool DriveSmart - Admin</h1>
            <p class="lead">Aangepaste rijlessen voor mensen met een fysieke beperking - veilig, professioneel en persoonlijk.</p>
            <span class="badge" style="background:#ffc107;color:#000;padding:6px 10px;border-radius:12px;">Ingelogd als: <?= htmlspecialchars($adminName) ?></span>
        </div>
    </header>

    <nav>
        <ul>
            <li><a href="HomepageAdmin.php">Home</a></li>
            <li><a href="Mededeling.php">Mededelingen</a></li>
            <li><a href="Wagenpark.php">Wagenpark</a></li>
            <li><a href="lespakketen.php">Lespakketen</a></li>
            <li><a href="terms.php">Voorwaarden</a></li>
            <li><a href="../Database/logout.php">Uitloggen</a></li>
        </ul>
    </nav>
</body>
</html>
