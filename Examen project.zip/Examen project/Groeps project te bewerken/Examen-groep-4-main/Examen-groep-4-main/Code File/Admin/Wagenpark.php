<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../Database/login.php');
    exit;
}
require_once __DIR__ . '/../../Database/database.php';

$db = new Database('127.0.0.1', 'drivesmart', 'root', '');
$pdo = $db->getPdo();

// Zorg dat de kolom AssignedTeacher bestaat om PDO-fouten te voorkomen
try {
    $pdo->query("ALTER TABLE cars ADD COLUMN IF NOT EXISTS AssignedTeacher INT NULL");
} catch (PDOException $e) {
    // Ignoreren als de databaseversie IF NOT EXISTS niet ondersteunt; proberen we bij select te vermijden
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $type = trim($_POST['type'] ?? '');
        $license = trim($_POST['license'] ?? '');
        if ($type !== '') {
            $sql = "INSERT INTO cars (CarsType, CarsWear, CarsUsed, CarsODO, CarsMaintenance, Carlicensep)
                    VALUES (:type, '', 0, 0, 0, :license)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':type' => $type, ':license' => $license ?: null]);
        }
    }

    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $stmt = $pdo->prepare("DELETE FROM cars WHERE idCars = :id");
            $stmt->execute([':id' => $id]);
        }
    }

    if ($action === 'toggle_maint') {
        $id = (int)($_POST['id'] ?? 0);
        $new = (int)($_POST['value'] ?? 0);
        if ($id) {
            $stmt = $pdo->prepare("UPDATE cars SET CarsMaintenance = :m WHERE idCars = :id");
            $stmt->execute([':m' => $new, ':id' => $id]);
        }
    }

    if ($action === 'assign_teacher') {
        $car_id = (int)($_POST['car_id'] ?? 0);
        $teacher_id = (int)($_POST['teacher_id'] ?? 0);
        if ($car_id) {
            $stmt = $pdo->prepare("UPDATE cars SET AssignedTeacher = :teacher WHERE idCars = :id");
            $stmt->execute([':teacher' => $teacher_id ?: null, ':id' => $car_id]);
        }
    }

    header('Location: Wagenpark.php');
    exit;
}

// Haal alle auto's op, probeer AssignedTeacher, zo niet fallback zonder die kolom
try {
    $stmt = $pdo->query("SELECT idCars, CarsType, CarsWear, CarsUsed, CarsMaintenance, CarsODO, Carlicensep, AssignedTeacher FROM cars ORDER BY idCars");
    $cars = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $stmt = $pdo->query("SELECT idCars, CarsType, CarsWear, CarsUsed, CarsMaintenance, CarsODO, Carlicensep FROM cars ORDER BY idCars");
    $cars = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // vul lege kolom zodat template niet breekt
    foreach ($cars as &$c) {
        $c['AssignedTeacher'] = null;
    }
}

// Haal alle instructeurs op
$stmt = $pdo->query("SELECT idTeachers, TeachersName FROM teachers ORDER BY TeachersName");
$teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!doctype html>
<html lang="nl">
<head>
  <meta charset="utf-8">
  <title>Wagenpark</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="../Styling/wagenpark.css">
</head>

<body>

    <nav>
        <ul>
            <li><a href="HomepageAdmin.php">Home</a></li>
            <li><a href="Mededeling.php">Mededelingen</a></li>
            <li><a href="lespakketen.php">Les pakketten</a></li>
            <li><a href="terms.php">Voorwaarden</a></li>
            <li><a href="../Database/logout.php">Uitloggen</a></li>
        </ul>
    </nav>

  <div class="container">
    <div class="logo">
      <h1>Rijschool DriveSmart</h1>
      <span>Wagenpark beheer</span>
    </div>

    <h2>Nieuwe auto toevoegen</h2>
    <form method="post">
      <input type="hidden" name="action" value="add">
      <label>Type
        <input name="type" type="text" placeholder="Type (bv. BMW)" required>
      </label>
      <label>Kenteken (optioneel)
        <input name="license" type="text" placeholder="Bijv. AB-CD-EF">
      </label>
      <button type="submit" class="btn-toevoegen">Toevoegen</button>
    </form>

    <h2>Overzicht auto's</h2>
    <?php if (empty($cars)): ?>
      <div class="footer-text">Geen auto's gevonden.</div>
    <?php else: ?>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Type</th>
            <th>Slijtage</th>
            <th>In gebruik</th>
            <th>Onderhoud</th>
            <th>KM (ODO)</th>
            <th>Kenteken</th>
            <th>Toegewezen aan</th>
            <th>Acties</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($cars as $c): ?>
            <tr>
              <td><?= (int)$c['idCars'] ?></td>
              <td><?= htmlspecialchars($c['CarsType'] ?? '–') ?></td>
              <td><?= htmlspecialchars($c['CarsWear'] ?? '–') ?></td>
              <td><?= $c['CarsUsed'] ? 'Ja' : 'Nee' ?></td>
              <td><?= $c['CarsMaintenance'] ? 'Ja' : 'Nee' ?></td>
              <td><?= htmlspecialchars($c['CarsODO'] ?? '0') ?> km</td>
              <td><?= htmlspecialchars($c['Carlicensep'] ?? '–') ?></td>
              <td>
                <?php
                $assignedName = '–';
                if ($c['AssignedTeacher']) {
                  foreach ($teachers as $t) {
                    if ($t['idTeachers'] == $c['AssignedTeacher']) {
                      $assignedName = htmlspecialchars($t['TeachersName']);
                      break;
                    }
                  }
                }
                echo $assignedName;
                ?>
              </td>
              <td>
                <form method="post" style="display:inline-block">
                  <input type="hidden" name="action" value="toggle_maint">
                  <input type="hidden" name="id" value="<?= (int)$c['idCars'] ?>">
                  <input type="hidden" name="value" value="<?= $c['CarsMaintenance'] ? '0' : '1' ?>">
                  
                  <button class="btn-toevoegen" type="submit" style="padding:6px 8px;font-size:12px;">
                    <?= $c['CarsMaintenance'] ? 'Uit onderhoud' : 'In onderhoud' ?>
                  </button>
                </form>

                <form method="post" style="display:inline-block" onsubmit="return confirm('Verwijderen?');">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="id" value="<?= (int)$c['idCars'] ?>">
                  
                  <button class="btn-toevoegen" style="background:#e74c3c;padding:6px 8px;font-size:12px;border-radius:8px;color:#fff;border:none">
                    Verwijder
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>

    <h2 style="margin-top: 40px;">Auto toewijzen aan instructeur</h2>
    <form method="post">
      <input type="hidden" name="action" value="assign_teacher">
      
      <label>Selecteer auto
        <select name="car_id" required>
          <option value="">-- Kies een auto --</option>
          <?php foreach ($cars as $c): ?>
            <option value="<?= (int)$c['idCars'] ?>">
              <?= htmlspecialchars($c['CarsType']) ?> - <?= htmlspecialchars($c['Carlicensep'] ?? 'Geen kenteken') ?>
            </option>
          <?php endforeach; ?>
        </select>
      </label>

      <label>Selecteer instructeur
        <select name="teacher_id" required>
          <option value="0">-- Geen (verwijder toewijzing) --</option>
          <?php foreach ($teachers as $t): ?>
            <option value="<?= (int)$t['idTeachers'] ?>">
              <?= htmlspecialchars($t['TeachersName']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </label>

      <button type="submit" class="btn-toevoegen">Auto toewijzen</button>
    </form>

  </div>
</body>
</html>
