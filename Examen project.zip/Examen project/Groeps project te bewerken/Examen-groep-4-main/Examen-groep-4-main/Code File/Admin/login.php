<?php
require_once __DIR__ . '/../Database/db.php';
session_start();

if (isset($_SESSION['admin_id'])) {
    header('Location: HomepageAdmin.php');
    exit;
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($name) || empty($password)) {
        $error = 'Vul alle velden in.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM admin WHERE AdminName = :name");
        $stmt->execute(['name' => $name]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['AdminPsw'])) {
            $_SESSION['admin_id'] = $admin['idAdmin'];
            $_SESSION['admin_name'] = $admin['AdminName'];
            $_SESSION['user_id'] = $admin['idAdmin'];
            $_SESSION['user_name'] = $admin['AdminName'];
            $_SESSION['role'] = 'admin';
            header('Location: HomepageAdmin.php');
            exit;
        } else {
            $error = 'Ongeldige inloggegevens.';
    }
}}

$pageTitle = "Admin Inloggen";
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Rijschool / Admin inloggen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body class="d-flex align-items-center justify-content-center" style="min-height: 100vh;">
<div class="container" style="max-width: 450px;">
    <div class="card p-4">
        <h2 class="text-center mb-4">Admin Inloggen</h2>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="mb-3">
                <label for="name" class="form-label">Gebruikersnaam</label>
                <input type="text" id="name" name="name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Wachtwoord</label>
                <input type="password" id="password" name="password" class="form-control" required>
            </div>
            <div class="d-grid">
                <button type="submit" class="btn btn-primary">Inloggen</button>
            </div>
            <div class="text-center mt-3">
                <a href="../../index.php">Terug naar home</a>
            </div>
        </form>
    </div>
</div>
</body>
</html>
