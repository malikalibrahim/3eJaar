<?php
require_once 'db.php';
require_once 'Admin-class.php';

$admin = new Admin($pdo);
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    if ($name === '') {
        $message = 'Name required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Valid email required';
    } elseif (strlen($password) < 6) {
        $message = 'Password must be at least 6 characters';
    } elseif ($password !== $password_confirm) {
        $message = 'Passwords do not match';
    } else {
        $success = $admin->RegisterAdmin($name, $email, $password);
        
        if ($success) {
            header('Location: login.php');
            exit;
        } else {
            $message = 'Could not create admin account';
        }
    }
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Admin Registration</title>
<link rel="stylesheet" href="../Styling/registerAdmin.css">
</head>

<body>
  <div class="container">
    <div class="logo">
      <h1>DriveSmart</h1>
      <span>Admin Registration</span>
    </div>

    <h2>Register Admin</h2>
    
    <?php if ($message): ?>
      <div class="message"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    
    <form method="post">
      <label>Name <input name="name" type="text" required></label>
      <label>Email <input name="email" type="email" required></label>
      <label>Password <input name="password" type="password" required></label>
      <label>Confirm password <input name="password_confirm" type="password" required></label>
      <button type="submit" class="btn-signup">Register Admin</button>
    </form>

    <div class="footer-text">
      Already have an account? <a href="login.php">Login here</a>
    </div>
  </div>
</body>
</html>