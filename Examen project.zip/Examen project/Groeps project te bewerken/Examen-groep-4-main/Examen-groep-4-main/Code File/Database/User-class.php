
<?php
require_once 'db.php';

class Student {
    private $pdo;


    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }


    
public function LoginUsers($email) {
    $stmt = $this->pdo->prepare("SELECT * FROM students WHERE StudentsEmail = :email");
    $stmt->execute(['email' => $email]); 
    return $stmt->fetch(PDO::FETCH_ASSOC); 
}


    public function create(array $data): int {
        $sql = "INSERT INTO students
            (StudentsName, StudentsAge, StudentsAddress, StudentsPhoneNumber, StudentsEmail, StudentsPsw, StudentsStripCard)
            VALUES (:name, :age, :address, :phone, :email, :psw, :strip)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            'name' => $data['name'],
            'age' => $data['age'],
            'address' => $data['address'],
            'phone' => $data['phone'],
            'email' => $data['email'],
            'psw' => $data['password_hash'],
            'strip' => $data['stripcard'] ?? 0
        ]);
        return (int) $this->pdo->lastInsertId();
    }

     public function emailExists(string $email): bool {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM students WHERE StudentsEmail = :email");
        $stmt->execute(['email' => $email]);
        return $stmt->fetchColumn() > 0;
    }
}
?>