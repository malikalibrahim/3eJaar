
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DriveSmart - Welkom</title>
    <link rel="stylesheet" href="../Styling/visitorpage.css">
</head>

<body>
    <nav class="navbar">
        <div class="logo">DriveSmart</div>
        <ul class="nav-links">
            <li><a href="homepagevisitor.php">Home</a></li>
            <li><a href="lespakketten-visitor.php">Lespakketten</a></li>
            <li><a href="aboutus.php">Over Ons</a></li>
            <li><a href="contact.php">Contact</a></li>
        </ul>
        <div class="auth-buttons">
            <a href="../Database/login.php" class="login-btn">Inloggen</a>
            <a href="../Database/User-register.php" class="register-btn">Registreren</a>
        </div>
    </nav>

    <section class="hero">
        <h1>Welkom bij DriveSmart</h1>
        <p>Jouw betrouwbare partner voor rijlessen</p>
        <a href="lespakketten-visitor.php" class="cta-button">Bekijk Onze Pakketten</a>
    </section>

    <section class="features">
        <h2>Waarom DriveSmart?</h2>
        <div class="feature-grid">
            <div class="feature-card">
                <h3>Ervaren Instructeurs</h3>
                <p>Al onze instructeurs zijn gecertificeerd en hebben jarenlange ervaring in het lesgeven.</p>
            </div>
            <div class="feature-card">
                <h3>Moderne Auto's</h3>
                <p>Leer rijden in moderne, goed onderhouden lesauto's met de nieuwste veiligheidsvoorzieningen.</p>
            </div>
            <div class="feature-card">
                <h3>Flexibele Planning</h3>
                <p>Plan je lessen op tijden die jou het beste uitkomen, inclusief avonden en weekenden.</p>
            </div>
            <div class="feature-card">
                <h3>Hoog Slagingspercentage</h3>
                <p>Door onze effectieve lesmethode behalen onze leerlingen een bovengemiddeld slagingspercentage.</p>
            </div>
            <div class="feature-card">
                <h3>Eerlijke Prijzen</h3>
                <p>Kwalitatieve rijlessen tegen eerlijke en transparante prijzen zonder verborgen kosten.</p>
            </div>
            <div class="feature-card">
                <h3>Persoonlijke Begeleiding</h3>
                <p>Elke leerling krijgt een op maat gemaakt lesprogramma afgestemd op hun fysieke beperkingen en tempo.</p>
            </div>
        </div>
    </section>
</body>
</html>