<!doctype html>
<html lang="nl">

<head>
  <meta charset="utf-8">
  <title>Over ons — DriveSmart</title>
  <link rel="stylesheet" href="../Styling/aboutus.css">
</head>

<body>
  <nav class="navbar">
    <div class="nav-inner">
      <ul class="nav-links">
        <li><a href="aboutus.php">Over ons</a></li>
      </ul>
    </div>
  </nav>

  <div class="container">
    <section class="hero">
      <h1 class="main-title">Over DriveSmart</h1>
      <p>
        DriveSmart is een rijschool die zich specialiseert in het opleiden van leerlingen met een fysieke beperking.
        Wij bieden aangepaste rijlessen, deskundige begeleiding en voertuigen die zijn uitgerust voor toegankelijk rijden.
        Veiligheid, onafhankelijkheid en maatwerk staan bij ons centraal.
      </p>
    </section>

    <section>
      <h2>Onze aanpak</h2>
      <p>
        Onze instructeurs zijn getraind in het geven van rijles aan mensen met verschillende fysieke beperkingen.
        We starten met een intake om te bepalen welke aanpassingen en hulpmiddelen nodig zijn. Daarna volgt een persoonlijk
        lesplan met duidelijke doelen. Waar nodig schakelen we samen met ergotherapeuten of andere specialisten.
      </p>
    </section>

    <section style="margin-top:40px">
      <h2>Medewerkers en instructeurs </h2>
      <div class="grid">
          <div class="card">
            <h4> Helena - Begeleiding </h3>
            <h4> Malik - Instructeur </h3>
            <h4> Kasper - Managment</h3>
            <h4> Avinash - Instructeur </h3>
          </div>

        <div class="card">
          <h3>Chris Groot- Eigenaar</h3>
          <h4> Chris@gmail.com </h4>
        </div>
      </div>
    </section>

    <section style="margin-top:18px">
      <h2>Contact en locatie</h2>
      <p>
        Voor informatie of een intakegesprek kunt u contact opnemen via bovenstaand e‑mailadres of telefoonnummer.
        Onze locatie is rolstoeltoegankelijk en we hebben aangepaste parkeergelegenheid bij de ingang.
      </p>
      <p>
        <a class="btn-primary" style="padding:8px 12px; border-radius:6px; background:#1e90ff; color:#fff; text-decoration:none;" href="https://www.google.com/maps/dir/?api=1&destination=52.3159197,4.9438528" target="_blank" rel="noopener">Plan route</a>
      </p>

      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4878.009125883406!2d4.943852861073872!3d52.3159197!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c60b91697d8729%3A0xb5cf33c91399403c!2sMBO%20College%20Zuidoost%20%7C%20Hoofdlocatie%20%7C%20ROC%20van%20Amsterdam!5e0!3m2!1sen!2snl!4v1764760182574!5m2!1sen!2snl" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </section>
  </div>
</body>
</html>
