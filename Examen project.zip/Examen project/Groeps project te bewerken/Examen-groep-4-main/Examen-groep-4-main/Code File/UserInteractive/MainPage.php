<?php
    require_once '../Database/db.php';
    session_start();
    
    if (!isset($_SESSION['user_id'])) {
        header('Location: ../Database/login.php');
        exit;
    }
    
    $userName = $_SESSION['user_name'] ?? 'Gebruiker';
    $role = $_SESSION['role'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> DriveSmart</title>
    <link rel="stylesheet" href="../Styling/mainpage.css">
</head>
<body>
    <h1>Welcome to DriveSmart</h1>
    <h2>Welcome  <?php echo htmlspecialchars($userName, ENT_QUOTES, 'UTF-8'); ?></h2>

    <?php
    $drivesmartLink = null;
    if ($role === 'student') {
        $drivesmartLink = '../Leerling/HomepageLeerling.php';
    } elseif ($role === 'teacher') {
        $drivesmartLink = '../Instructor/HomepageInstructor.php';
    } elseif ($role === 'admin') {
        $drivesmartLink = '../Admin/HomepageAdmin.php';
    }
    ?>

    <?php if ($drivesmartLink): ?>
        <p>
            <a class="btn" href="<?php echo $drivesmartLink; ?>">Ga naar DriveSmart-dashboard</a>
        </p>
    <?php endif; ?>

    <form action="../Database/logout.php" method="POST" style="display: inline;">
        <button type="submit" class="btn">Uitloggen</button>
    </form>
</body>
</html>
