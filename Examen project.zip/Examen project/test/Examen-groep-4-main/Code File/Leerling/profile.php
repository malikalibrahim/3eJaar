<?php
require_once __DIR__ . '/student-class.php';
session_start();

if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit;
}

$studentId = $_SESSION['student_id'];
$student = new Student();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name'] ?? '');
    $age = (int)($_POST['age'] ?? 0);
    $address = htmlspecialchars($_POST['address'] ?? '');
    $phone = htmlspecialchars($_POST['phone'] ?? '');
    $email = htmlspecialchars($_POST['email'] ?? '');

    $student->updateProfile($studentId, $name, $age, $address, $phone, $email);
    $_SESSION['student_name'] = $name;
    $message = 'Profiel is bijgewerkt.';
}

// Altijd actuele gegevens ophalen
$data = $student->getById($studentId);
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Mijn profiel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <h2 class="mb-3">Mijn profiel</h2>
    <?php if ($message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <form method="post" class="card card-body">
        <div class="mb-3">
            <label class="form-label">Naam</label>
            <input type="text" name="name" class="form-control" required
                   value="<?= htmlspecialchars($data['StudentsName'] ?? '') ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Leeftijd</label>
            <input type="number" name="age" class="form-control" required
                   value="<?= htmlspecialchars($data['StudentsAge'] ?? '') ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Adres</label>
            <input type="text" name="address" class="form-control" required
                   value="<?= htmlspecialchars($data['StudentsAddress'] ?? '') ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Telefoonnummer</label>
            <input type="text" name="phone" class="form-control" required
                   value="<?= htmlspecialchars($data['StudentsPhoneNumber'] ?? '') ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">E-mailadres</label>
            <input type="email" name="email" class="form-control" required
                   value="<?= htmlspecialchars($data['StudentsEmail'] ?? '') ?>">
        </div>
        <button type="submit" class="btn btn-primary">Opslaan</button>
        <a href="dashboard.php" class="btn btn-link">Terug</a>
    </form>
</div>
</body>
</html>


