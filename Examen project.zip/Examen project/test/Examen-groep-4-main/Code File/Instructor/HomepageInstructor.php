<?php
require_once __DIR__ . '/../../Database/database.php';
require_once __DIR__ . '/../Classes/Schedule.php';
require_once __DIR__ . '/../Classes/Lesson.php';

$db = new Database('127.0.0.1', 'drivesmart', 'root', '');
$pdo = $db->getPdo();

$schedule = new Schedule($pdo);
$lesson = new Lesson($pdo);

$todaySchedule = $schedule->getToday();
$lessons = $lesson->getAll();
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DriveSmart - Instructor</title>
    <link rel="stylesheet" href="../Styling/homepageinstructor.css">
</head>
<body>
    <h1> DriveSmart - Instructeurs</h1>
    <nav>
        <ul>
            <li><a href="HomepageInstructor.php">Home</a></li>
            <li><a href="#">Weekrooster</a></li>
            <li><a href="#">Lessen</a></li>
            <li><a href="/../../Code/ziekmeld.php">Ziek melden</a></li>
        </ul>
    </nav>

    <div class="section">
        <h2>Dagrooster — Vandaag (<?php echo (new DateTime('today'))->format('Y-m-d'); ?>)</h2>

        <?php if (count($todaySchedule) === 0): ?>
            <div class="empty">Geen lessen ingepland voor vandaag.</div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Tijd</th>
                        <th>Auto</th>
                        <th>Ophaalplaats</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($todaySchedule as $row): ?>
                        <?php $dt = new DateTime($row['ScheduleDateTime']); ?>
                        <tr>
                            <td><?php echo htmlspecialchars($dt->format('H:i')); ?></td>
                            <td><?php echo htmlspecialchars($row['ScheduleCar']); ?></td>
                            <td><?php echo htmlspecialchars($row['SchedulePickLoc']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>