<?php
require_once __DIR__ . '/../includes/Algemeen/schedule-class.php';
require_once __DIR__ . '/../includes/Algemeen/announcement-class.php';
session_start();

if (!isset($_SESSION['teacher_id'])) {
    header('Location: login.php');
    exit;
}

$teacherId = $_SESSION['teacher_id'];
$schedule = new Schedule();
$announcement = new Announcement();

$today = date('Y-m-d');
$lessons = $schedule->getTeacherDaySchedule($teacherId, $today);
$announcements = $announcement->getForTarget('teacher');
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Instructeur dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Welkom, <?= htmlspecialchars($_SESSION['teacher_name']) ?></h2>
        <div>
            <a href="day-schedule.php?date=<?= $today ?>" class="btn btn-outline-secondary btn-sm">Dagrooster printen</a>
            <a href="logout.php" class="btn btn-outline-danger btn-sm">Uitloggen</a>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-md-8">
            <h4>Dagrooster vandaag (<?= htmlspecialchars($today) ?>)</h4>
            <table class="table table-striped table-sm">
                <thead>
                <tr>
                    <th>Datum/tijd</th>
                    <th>Leerling</th>
                    <th>Onderwerp</th>
                    <th>Status</th>
                    <th>Acties</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($lessons as $lesson): ?>
                    <tr>
                        <td><?= htmlspecialchars($lesson['ScheduleDateTime']) ?></td>
                        <td><?= htmlspecialchars($lesson['ScheduleStudentId']) ?></td>
                        <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '') ?></td>
                        <td><?= htmlspecialchars($lesson['ScheduleStatus']) ?></td>
                        <td>
                            <a href="instructor-lesson-remark.php?id=<?= (int)$lesson['idSchedule'] ?>" class="btn btn-sm btn-primary">Opmerking</a>
                            <a href="instructor-lesson-edit.php?id=<?= (int)$lesson['idSchedule'] ?>" class="btn btn-sm btn-warning">Aanpassen</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="col-md-4">
            <h4>Mededelingen</h4>
            <?php if (!$announcements): ?>
                <p class="text-muted">Geen mededelingen.</p>
            <?php else: ?>
                <?php foreach ($announcements as $a): ?>
                    <div class="card mb-2">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($a['Title']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($a['Message']) ?></p>
                            <small class="text-muted"><?= htmlspecialchars($a['CreatedAt']) ?></small>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>


