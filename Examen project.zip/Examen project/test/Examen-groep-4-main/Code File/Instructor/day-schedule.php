<?php
require_once __DIR__ . '/../includes/Algemeen/schedule-class.php';
require_once __DIR__ . '/../includes/Algemeen/announcement-class.php';
session_start();

if (!isset($_SESSION['teacher_id'])) {
    header('Location: login.php');
    exit;
}

$teacherId = $_SESSION['teacher_id'];
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

$schedule = new Schedule();
$lessons = $schedule->getTeacherDaySchedule($teacherId, $date);

$announcement = new Announcement();
$announcements = $announcement->getForTarget('teacher');
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Dagrooster <?= htmlspecialchars($date) ?></title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        h2 { margin-bottom: 0.5rem; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #000; padding: 4px; }
        @media print {
            body { margin: 0; }
        }
    </style>
</head>
<body onload="window.print()">
    <h2>Dagrooster <?= htmlspecialchars($date) ?></h2>
    <p>Instructeur: <?= htmlspecialchars($_SESSION['teacher_name']) ?></p>
    <table>
        <thead>
        <tr>
            <th>Datum/tijd</th>
            <th>Leerling ID</th>
            <th>Onderwerp</th>
            <th>Status</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($lessons as $lesson): ?>
            <tr>
                <td><?= htmlspecialchars($lesson['ScheduleDateTime']) ?></td>
                <td><?= htmlspecialchars($lesson['ScheduleStudentId']) ?></td>
                <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '') ?></td>
                <td><?= htmlspecialchars($lesson['ScheduleStatus']) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <?php if ($announcements): ?>
        <h3 style="margin-top: 1.5rem;">Mededelingen voor instructeurs</h3>
        <ul>
            <?php foreach ($announcements as $note): ?>
                <li>
                    <strong><?= htmlspecialchars($note['Title']) ?>:</strong>
                    <?= htmlspecialchars($note['Message']) ?>
                    <em>(<?= htmlspecialchars($note['CreatedAt']) ?>)</em>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</body>
</html>
