<?php
require_once __DIR__ . '/../../Database/database.php';
require_once __DIR__ . '/../Classes/Schedule.php';
require_once __DIR__ . '/../Classes/Lesson.php';

$db = new Database('127.0.0.1', 'drivesmart', 'root', '');
$pdo = $db->getPdo();

$schedule = new Schedule($pdo);
$lesson = new Lesson($pdo);

$todaySchedule = $schedule->getToday();
$lessons = $lesson->getAll();
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DriveSmart - Admin</title>
    <link rel="stylesheet" href="../Styling/homepageadmin.css">
</head>
<body>
    <h1>Rijschool DriveSmart</h1>
    <nav>
        <ul>
            <li><a href="HomepageAdmin.php">Home</a></li>
            <li><a href="#">Mededelingen</a></li>
            <li><a href="wagenpark.php">Wagenpark</a></li>
            <li><a href="#">Instructeurs</a></li>
            <li><a href="#">Leerlingen</a></li>
        </ul>
    </nav>
</body>
</html>