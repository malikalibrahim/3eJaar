<?php
require_once __DIR__ . '/../../Database/database.php';

$db = new Database('127.0.0.1', 'drivesmart', 'root', '');
$pdo = $db->getPdo();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $type = trim($_POST['type'] ?? '');
        $license = trim($_POST['license'] ?? '');
        if ($type !== '') {
            $sql = "INSERT INTO cars (CarsType, CarsWear, CarsUsed, CarsODO, CarsMaintenance, Carlicensep)
                    VALUES (:type, '', 0, 0, 0, :license)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':type' => $type, ':license' => $license ?: null]);
        }
    }

    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $stmt = $pdo->prepare("DELETE FROM cars WHERE idCars = :id");
            $stmt->execute([':id' => $id]);
        }
    }

    if ($action === 'toggle_maint') {
        $id = (int)($_POST['id'] ?? 0);
        $new = (int)($_POST['value'] ?? 0);
        if ($id) {
            $stmt = $pdo->prepare("UPDATE cars SET CarsMaintenance = :m WHERE idCars = :id");
            $stmt->execute([':m' => $new, ':id' => $id]);
        }
    }

    header('Location: Wagenpark.php');
    exit;
}

$stmt = $pdo->query("SELECT idCars, CarsType, CarsWear, CarsUsed, CarsMaintenance, CarsODO, Carlicensep FROM cars ORDER BY idCars");
$cars = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>


<!doctype html>
<html lang="nl">
<head>
  <meta charset="utf-8">
  <title>Wagenpark</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="../Styling/wagenpark.css">
</head>

<body>
  <div class="container">
    <div class="logo">
      <h1>Rijschool DriveSmart</h1>
      <span>Wagenpark beheer</span>
    </div>

    <h2>Nieuwe auto toevoegen</h2>
    <form method="post">
      <input type="hidden" name="action" value="add">
      <label>Type
        <input name="type" type="text" placeholder="Type (bv. BMW)" required>
      </label>
      <label>Kenteken (optioneel)
        <input name="license" type="text" placeholder="Bijv. AB-CD-EF">
      </label>
      <button type="submit" class="btn-toevoegen">Toevoegen</button>
    </form>

    <h2>Overzicht auto's</h2>
    <?php if (empty($cars)): ?>
      <div class="footer-text">Geen auto's gevonden.</div>
    <?php else: ?>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>Type</th>
            <th>Slijtage</th>
            <th>In gebruik</th>
            <th>Onderhoud</th>
            <th>KM (ODO)</th>
            <th>Kenteken</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($cars as $c): ?>
            <tr>
              <td><?= (int)$c['idCars'] ?></td>
              <td><?= htmlspecialchars($c['CarsType'] ?? '–') ?></td>
              <td><?= htmlspecialchars($c['CarsWear'] ?? '–') ?></td>
              <td><?= $c['CarsUsed'] ? 'Ja' : 'Nee' ?></td>
              <td><?= $c['CarsMaintenance'] ? 'Ja' : 'Nee' ?></td>
              <td><?= htmlspecialchars($c['CarsODO'] ?? '0') ?> km</td>
              <td><?= htmlspecialchars($c['Carlicensep'] ?? '–') ?></td>
              <td>
                <form method="post" style="display:inline-block">
                  <input type="hidden" name="action" value="toggle_maint">
                  <input type="hidden" name="id" value="<?= (int)$c['idCars'] ?>">
                  <input type="hidden" name="value" value="<?= $c['CarsMaintenance'] ? '0' : '1' ?>">
                  
                  <button class="btn-toevoegen" type="submit" style="padding:6px 8px;font-size:12px;">
                    <?= $c['CarsMaintenance'] ? 'Uit onderhoud' : 'In onderhoud' ?>
                  </button>
                </form>

                <form method="post" style="display:inline-block" onsubmit="return confirm('Verwijderen?');">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="id" value="<?= (int)$c['idCars'] ?>">
                  
                  <button class="btn-toevoegen" style="background:#e74c3c;padding:6px 8px;font-size:12px;border-radius:8px;color:#fff;border:none">
                    Verwijder
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</body>
</html>