<?php
// Database configuratie
class Database
{
    private static $connection = null;

    public static function connect()
    {
        if (self::$connection === null) {
            $host = 'localhost';
            $dbname = 'rijschool_examen';
            $username = 'root'; 
            $password = ''; 

            try {
                self::$connection = new PDO(
                    "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
                    $username,
                    $password,
                    [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                    ]
                );
            } catch (PDOException $e) {
                die("Databaseverbinding mislukt: " . $e->getMessage());
            }
        }
        return self::$connection;
    }
}

// afhandelen van de ziekmeld-logica
class ZiekmeldController
{
    // Eigenschap om meldingen
    private string $melding = '';
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::connect();
    }

    // Verwerkt het formulier als het via POST is verstuurd
    public function verwerkFormulier(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return; 
        }

        // Ophalen van de waarden uit het formulier
        $rol       = $_POST['rol']       ?? '';
        $naam      = trim($_POST['naam'] ?? '');
        $datum     = $_POST['datum']     ?? '';
        $reden     = trim($_POST['reden'] ?? '');

        // Controleren of alle verplichte velden zijn ingevuld
        if (empty($rol) || empty($naam) || empty($datum) || empty($reden)) {
            $this->melding = "Vul alle verplichte velden in om je ziek te melden.";
            return;
        }

        // Instructeur ID ophalen op basis van naam
        $instructeurId = $this->getInstructeurId($naam, $rol);

        // Als het een instructeur is en we vinden geen ID
        if ($rol === 'instructeur' && $instructeurId === null) {
            $this->melding = "Instructeur niet gevonden in het systeem.";
            return;
        }

        // Tijd toevoegen (huidige tijd)
        $tijd = date('H:i:s');

        // Ziekmelding opslaan in de database
        try {
            $stmt = $this->db->prepare("
                INSERT INTO ziekmelding (instructeur_id, datum, tijd, reden) 
                VALUES (:instructeur_id, :datum, :tijd, :reden)
            ");

            $stmt->execute([
                ':instructeur_id' => $instructeurId,
                ':datum' => $datum,
                ':tijd' => $tijd,
                ':reden' => $reden
            ]);

            $rolWeergave = ucfirst($rol);
            $this->melding = "Ziekmelding succesvol opgeslagen voor $rolWeergave: $naam op $datum.";
            
        } catch (PDOException $e) {
            $this->melding = "Fout bij het opslaan: " . $e->getMessage();
        }
    }

    // Hulp-functie om instructeur ID op te halen
    private function getInstructeurId(string $naam, string $rol): ?int
    {
        if ($rol !== 'instructeur') {
            return null;
        }

        try {
           
            $instructeurMap = [
                'Jan Jansen' => 1,
                'Piet Pietersen' => 2,
                'Klaas de Vries' => 3,
                'Marieke Bakker' => 4,
                'Sander de Boer' => 5
            ];

            return $instructeurMap[$naam] ?? null;

        } catch (PDOException $e) {
            return null;
        }
    }

    // Haal alle ziekmeldingen op
    public function getZiekmeldingen(): array
    {
        try {
            $stmt = $this->db->query("
                SELECT z.*, i.naam as instructeur_naam 
                FROM ziekmelding z 
                LEFT JOIN instructeurs i ON z.instructeur_id = i.id 
                ORDER BY z.datum DESC, z.tijd DESC
            ");
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            return [];
        }
    }

    // Geeft de melding terug zodat die in de HTML getoond kan worden
    public function getMelding(): string
    {
        return $this->melding;
    }
}

// ZiekmeldController-object aanmaken
$ziekmeldController = new ZiekmeldController();

// Formulier laten verwerken
$ziekmeldController->verwerkFormulier();

// Melding uit de controller ophalen
$melding = $ziekmeldController->getMelding();
?>
<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <title>Rijschool Ziekmelding</title>
    <style>
        /* Algemene pagina-opmaak */
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: linear-gradient(135deg, #1e90ff, #6E8B3D, #d5e643ff);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: #333;
        }

        /* Witte "kaart" in het midden */
        .container {
            background: #ffffffee;
            padding: 30px 35px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
            max-width: 450px;
            width: 100%;
        }

        .logo {
            text-align: center;
            margin-bottom: 20px;
        }

        .logo h1 {
            margin: 0;
            font-size: 26px;
            letter-spacing: 1px;
            color: #2c3e50;
        }

        .logo span {
            font-size: 13px;
            color: #7f8c8d;
        }

        h2 {
            margin-top: 20px;
            margin-bottom: 10px;
            font-size: 20px;
            text-align: center;
            color: #34495e;
        }

        form {
            margin-top: 10px;
        }

        label {
            display: block;
            margin-top: 12px;
            margin-bottom: 5px;
            font-size: 14px;
            color: #555;
        }

        input[type="text"],
        input[type="date"],
        select,
        textarea {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #dcdde1;
            border-radius: 8px;
            font-size: 14px;
            box-sizing: border-box;
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        input[type="text"]:focus,
        input[type="date"]:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: #1e90ff;
            box-shadow: 0 0 0 2px rgba(30, 144, 255, 0.15);
        }

        textarea {
            min-height: 80px;
            resize: vertical;
        }

        .rol-info {
            font-size: 12px;
            color: #7f8c8d;
            margin-top: 3px;
        }

        .btn-submit {
            margin-top: 18px;
            width: 100%;
            padding: 11px;
            border: none;
            border-radius: 25px;
            font-size: 15px;
            font-weight: bold;
            color: #fff;
            background: linear-gradient(135deg, #1e90ff, #00b894);
            cursor: pointer;
            transition: transform 0.1s, box-shadow 0.1s, opacity 0.2s;
        }

        .btn-submit:hover {
            opacity: 0.95;
            box-shadow: 0 8px 18px rgba(0, 0, 0, 0.15);
            transform: translateY(-1px);
        }

        .btn-submit:active {
            transform: translateY(1px);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.18);
        }

        .footer-text {
            margin-top: 15px;
            text-align: center;
            font-size: 12px;
            color: #95a5a6;
        }

        .melding {
            margin-top: 10px;
            padding: 12px 15px;
            border-radius: 8px;
            font-size: 14px;
            line-height: 1.4;
        }

        .melding.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .melding.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .melding.info {
            background: #ffeaa7;
            color: #2d3436;
            border: 1px solid #fdcb6e;
        }

        .naam-hint {
            font-size: 11px;
            color: #7f8c8d;
            margin-top: 3px;
            font-style: italic;
        }

        @media (max-width: 480px) {
            .container {
                margin: 15px;
                padding: 25px 20px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="logo">
            <h1>Ziekmelding Rijschool</h1>
            <span>Meld je ziekte als leerling, instructeur of admin</span>
        </div>

        <h2>Ziekmelden</h2>

        <!-- Als er een melding is (uit PHP), dan toont het hier -->
        <?php if (!empty($melding)): ?>
            <?php
            $meldingClass = 'info';
            if (strpos($melding, 'succesvol') !== false) {
                $meldingClass = 'success';
            } elseif (strpos($melding, 'Fout') !== false || strpos($melding, 'niet gevonden') !== false) {
                $meldingClass = 'error';
            }
            ?>
            <div class="melding <?php echo $meldingClass; ?>">
                <?php
                echo htmlspecialchars($melding, ENT_QUOTES, 'UTF-8');
                ?>
            </div>
        <?php endif; ?>

        <!-- Het formulier stuurt gegevens via POST terug -->
        <form method="post" action="">
            <label for="rol">Rol</label>
            <select name="rol" id="rol" required>
                <option value="">-- Kies je rol --</option>
                <option value="leerling">Leerling</option>
                <option value="instructeur">Instructeur</option>
                <option value="admin">Admin</option>
            </select>
            <div class="rol-info">
                Geef aan of je een leerling, instructeur of administrator bent.
            </div>

            <label for="naam">Naam</label>
            <input type="text" id="naam" name="naam" placeholder="Voor- en achternaam" required>
            <div class="naam-hint">
                Voor instructeurs: gebruik je volledige naam zoals geregistreerd in het systeem (bijv. Jan Jansen)
            </div>

            <label for="datum">Datum ziekmelding</label>
            <input type="date" id="datum" name="datum" required value="<?php echo date('Y-m-d'); ?>">

            <label for="reden">Reden / Toelichting</label>
            <textarea id="reden" name="reden" placeholder="Bijvoorbeeld: griep, verkoudheid, andere reden..." required></textarea>

            <button type="submit" class="btn-submit">Ziekmelding verzenden</button>
        </form>

        <div class="footer-text">
            Je ziekmelding wordt geregistreerd in de database. Neem bij spoed ook telefonisch contact op met de rijschool.
        </div>
    </div>
</body>

</html>