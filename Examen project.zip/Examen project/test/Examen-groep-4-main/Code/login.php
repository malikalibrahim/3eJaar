<?php
// Klasse die verantwoordelijk is voor het afhandelen van de login-logica
class LoginController
{
    // Eigenschap om meldingen (fout of info) in op te slaan
    private string $melding = '';

    // Verwerkt het formulier als het via POST is verstuurd
    public function verwerkFormulier(): void
    {
        // Check of het verzoek een POST-verzoek is (dus het formulier is ingediend)
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return; // Niets doen als er nog geen POST is
        }

        // Ophalen van de waarden uit het formulier (met fallback naar '' als ze niet bestaan)
        $rol = $_POST['rol'] ?? '';
        $email = $_POST['email'] ?? '';
        $wachtwoord = $_POST['wachtwoord'] ?? '';

        // Controleren of alle verplichte velden zijn ingevuld
        if (empty($rol) || empty($email) || empty($wachtwoord)) {
            $this->melding = "Vul alle velden in.";
            return;
        }

        // Hier zou later de échte logincontrole komen (database, wachtwoord-hash, enz.)
        $this->melding = "Loginpoging ontvangen voor rol: $rol (hier komt later de echte controle).";
    }

    // Geeft de melding terug zodat die in de HTML getoond kan worden
    public function getMelding(): string
    {
        return $this->melding;
    }
}

// Nieuw LoginController-object aanmaken
$loginController = new LoginController();

// Formulier laten verwerken (als er op inloggen is gedrukt)
$loginController->verwerkFormulier();

// Melding uit de controller ophalen om in de pagina te tonen
$melding = $loginController->getMelding();
?>
<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <title>Rijschool Login</title>
    <style>
        /* Algemene pagina-opmaak */
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: linear-gradient(135deg, #1e90ff, #6E8B3D, #d5e643ff);
            display: flex;                 /* Maakt het mogelijk om de container te centreren */
            justify-content: center;       /* Horizontaal centreren */
            align-items: center;           /* Verticaal centreren */
            min-height: 100vh;             /* Minimaal volledige schermhoogte */
            color: #333;
        }

        /* Witte “kaart” in het midden */
        .container {
            background: #ffffffee;         /* Witte achtergrond met lichte transparantie */
            padding: 30px 35px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15); /* Schaduw rondom */
            max-width: 400px;
            width: 100%;
        }

        /* Bovenste logo / titel */
        .logo {
            text-align: center;
            margin-bottom: 20px;
        }

        .logo h1 {
            margin: 0;
            font-size: 26px;
            letter-spacing: 1px;
            color: #2c3e50;
        }

        .logo span {
            font-size: 13px;
            color: #7f8c8d;
        }

        /* Subtitel “Inloggen” */
        h2 {
            margin-top: 20px;
            margin-bottom: 10px;
            font-size: 20px;
            text-align: center;
            color: #34495e;
        }

        form {
            margin-top: 10px;
        }

        /* Labels boven de invoervelden */
        label {
            display: block;
            margin-top: 12px;
            margin-bottom: 5px;
            font-size: 14px;
            color: #555;
        }

        /* Standaard opmaak voor email, wachtwoord en selectveld */
        input[type="email"],
        input[type="password"],
        select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #dcdde1;
            border-radius: 8px;
            font-size: 14px;
            box-sizing: border-box;        /* Zorgt dat padding binnen de width valt */
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        /* Focus-stijl als je in een veld klikt/typt */
        input[type="email"]:focus,
        input[type="password"]:focus,
        select:focus {
            outline: none;
            border-color: #1e90ff;
            box-shadow: 0 0 0 2px rgba(30, 144, 255, 0.15);
        }

        /* Kleine tekst onder de rol-keuze */
        .rol-info {
            font-size: 12px;
            color: #7f8c8d;
            margin-top: 3px;
        }

        /* Stijl van de inlogknop */
        .btn-login {
            margin-top: 18px;
            width: 100%;
            padding: 11px;
            border: none;
            border-radius: 25px;
            font-size: 15px;
            font-weight: bold;
            color: #fff;
            background: linear-gradient(135deg, #1e90ff, #00b894);
            cursor: pointer;
            transition: transform 0.1s, box-shadow 0.1s, opacity 0.2s;
        }

        /* Hover-effect op de knop */
        .btn-login:hover {
            opacity: 0.95;
            box-shadow: 0 8px 18px rgba(0, 0, 0, 0.15);
            transform: translateY(-1px);
        }

        /* Klik-effect op de knop */
        .btn-login:active {
            transform: translateY(1px);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.18);
        }

        .footer-text {
            margin-top: 15px;
            text-align: center;
            font-size: 12px;
            color: #95a5a6;
        }

        /* Opmaak van de melding (fout of info) */
        .melding {
            margin-top: 10px;
            padding: 8px 10px;
            border-radius: 8px;
            font-size: 13px;
            background: #ffeaa7;
            color: #2d3436;
        }

        /* Aanpassingen voor kleine schermen (bijv. telefoon) */
        @media (max-width: 480px) {
            .container {
                margin: 15px;
                padding: 25px 20px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="logo">
            <h1>Rijschool Login</h1>
            <span>Log in als leerling, instructeur of admin</span>
        </div>

        <h2>Inloggen</h2>

        <!-- Als er een melding is (uit PHP), dan tonen we die hier -->
        <?php if (!empty($melding)): ?>
            <div class="melding">
                <?php
                // htmlspecialchars voorkomt dat schadelijke HTML/JS wordt uitgevoerd
                echo htmlspecialchars($melding, ENT_QUOTES, 'UTF-8');
                ?>
            </div>
        <?php endif; ?>

        <!-- Het formulier stuurt gegevens via POST terug naar dezelfde pagina (action="") -->
        <form method="post" action="">
            <label for="rol">Rol</label>
            <select name="rol" id="rol" required>
                <option value="">-- Kies je rol --</option>
                <option value="leerling">Leerling</option>
                <option value="instructeur">Instructeur</option>
                <option value="admin">Admin</option>
            </select>
            <div class="rol-info">
                Kies of je als leerling, instructeur of administrator wilt inloggen.
            </div>

            <label for="email">E-mailadres</label>
            <!-- type="email" zorgt voor basiscontrole in de browser -->
            <input type="email" id="email" name="email" placeholder="voorbeeld@mail.nl" required>

            <label for="wachtwoord">Wachtwoord</label>
            <input type="password" id="wachtwoord" name="wachtwoord" placeholder="Je wachtwoord" required>

            <!-- Verstuurknop: triggert POST-request naar dezelfde pagina -->
            <button type="submit" class="btn-login">Inloggen</button>
        </form>

    </div>
</body>

</html>