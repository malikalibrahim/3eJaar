<?php
$pageTitle = "Welkom bij DriveSmart";
require_once __DIR__ . '/Code File/Admin/header.php';
?>
<main class="p-0">
    <div class="hero-section">
        <div class="hero-content">
            <h1>Jouw Weg naar Vrijheid Begint Hier</h1>
            <p class="lead">Bij Rijschool DriveSmart helpen we je met vertrouwen de weg op.</p>
        </div>
    </div>

    <div class="container py-5">
        <div class="row">
            <div class="col-md-8 mx-auto text-center">
                <h2>Klaar om te starten?</h2>
                <p class="text-muted">Log in op jouw persoonlijke dashboard om je lessen te beheren, je voortgang te bekijken en te communiceren met je instructeur.</p>
            </div>
        </div>

        <?php if ($userName): ?>
            <div class="card text-center mt-4 mx-auto" style="max-width: 500px;">
                <div class="card-body">
                    <h5 class="card-title">Je bent al ingelogd</h5>
                    <p class="card-text">Ga direct naar je dashboard om verder te gaan.</p>
                    <?php
                    $dashboardLink = '#';
                    if ($role === 'admin') $dashboardLink = 'Code File/Admin/HomepageAdmin.php';
                    if ($role === 'teacher') $dashboardLink = 'Code File/Instructor/dashboard.php';
                    if ($role === 'student') $dashboardLink = 'Code File/Leerling/dashboard.php';
                    ?>
                    <a href="<?= $dashboardLink ?>" class="btn btn-primary">Naar mijn dashboard</a>
                </div>
            </div>
        <?php else: ?>
            <div class="row mt-4">
                <div class="col-md-4 mb-3">
                    <div class="card h-100 text-center">
                        <div class="card-body">
                            <h5 class="card-title">Leerling</h5>
                            <p class="card-text">Bekijk je rooster en opmerkingen.</p>
                            <a href="Code File/Leerling/login.php" class="btn btn-primary">Inloggen als Leerling</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card h-100 text-center">
                        <div class="card-body">
                            <h5 class="card-title">Instructeur</h5>
                            <p class="card-text">Beheer je lessen en leerlingen.</p>
                            <a href="Code File/Instructor/login.php" class="btn btn-primary">Inloggen als Instructeur</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card h-100 text-center">
                        <div class="card-body">
                            <h5 class="card-title">Admin</h5>
                            <p class="card-text">Beheer de rijschool.</p>
                            <a href="Code File/Admin/login.php" class="btn btn-primary">Inloggen als Admin</a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</main>

<?php require_once __DIR__ . '/Code File/Admin/footer.php'; ?>