<?php
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/student-class.php';
session_start();

if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit;
}

$studentId = $_SESSION['student_id'];
$student = new Student();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name'] ?? '');
    $age = (int)($_POST['age'] ?? 0);
    $address = htmlspecialchars($_POST['address'] ?? '');
    $phone = htmlspecialchars($_POST['phone'] ?? '');
    $email = htmlspecialchars($_POST['email'] ?? '');

    $student->updateProfile($studentId, $name, $age, $address, $phone, $email);
    $_SESSION['student_name'] = $name;
    $message = 'Profiel is bijgewerkt.';
}

$data = $student->getById($studentId);

$pageTitle = "Mijn Profiel";
require_once __DIR__ . '/../Admin/header.php';
?>

<div class="card mx-auto" style="max-width: 700px;">
    <div class="card-header">
        <h2 class="mb-0">Mijn Profiel</h2>
    </div>
    <div class="card-body">
        <?php if ($message): ?>
            <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        <form method="post">
        <div class="mb-3">
            <label class="form-label">Naam</label>
            <input type="text" name="name" class="form-control" required
                   value="<?= htmlspecialchars($data['StudentsName'] ?? '') ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Leeftijd</label>
            <input type="number" name="age" class="form-control" required
                   value="<?= htmlspecialchars($data['StudentsAge'] ?? '') ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Adres</label>
            <input type="text" name="address" class="form-control" required
                   value="<?= htmlspecialchars($data['StudentsAddress'] ?? '') ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Telefoonnummer</label>
            <input type="text" name="phone" class="form-control" required
                   value="<?= htmlspecialchars($data['StudentsPhoneNumber'] ?? '') ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">E-mailadres</label>
            <input type="email" name="email" class="form-control" required
                   value="<?= htmlspecialchars($data['StudentsEmail'] ?? '') ?>">
        </div>
            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-primary">Profiel opslaan</button>
                <a href="dashboard.php" class="btn btn-secondary">Terug naar dashboard</a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../Admin/footer.php'; ?>
