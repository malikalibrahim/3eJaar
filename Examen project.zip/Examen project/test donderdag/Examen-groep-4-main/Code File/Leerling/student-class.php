<?php
require_once __DIR__ . '/../Database/db.php';

class Student {
    private $db;

    public function __construct() {
        $this->db = new DB();
    }

    public function login($email) {
        return $this->db->run(
            "SELECT * FROM students WHERE StudentsEmail = :email",
            ["email" => $email]
        )->fetch();
    }

    public function getById($id) {
        return $this->db->run(
            "SELECT * FROM students WHERE idStudents = :id",
            ["id" => $id]
        )->fetch();
    }

    public function updateProfile($id, $name, $age, $address, $phone, $email) {
        return $this->db->run(
            "UPDATE students 
             SET StudentsName = :name,
                 StudentsAge = :age,
                 StudentsAddress = :address,
                 StudentsPhoneNumber = :phone,
                 StudentsEmail = :email
             WHERE idStudents = :id",
            [
                "name" => $name,
                "age" => $age,
                "address" => $address,
                "phone" => $phone,
                "email" => $email,
                "id" => $id
            ]
        );
    }
}


