<?php
// Bootstrap: zoek omhoog naar project root config.php en include indien aanwezig
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/teacher-class.php';
session_start();

if (isset($_SESSION['teacher_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $teacher = new Teacher();
    $email = htmlspecialchars($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $row = $teacher->login($email);
    if ($row && password_verify($password, $row['TeachersPsw'])) {
        $_SESSION['teacher_id'] = $row['idTeachers'];
        $_SESSION['teacher_name'] = $row['TeachersName'];
        // Standaardiseer sessie-gegevens voor de centrale header
        $_SESSION['user_name'] = $row['TeachersName'];
        $_SESSION['role'] = 'teacher';
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Ongeldig e-mailadres of wachtwoord.';
    }
}

$pageTitle = "Instructeur Inloggen";
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Instructeur inloggen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../Admin/style.css">
</head>
<body class="d-flex align-items-center justify-content-center" style="min-height: 100vh;">
<div class="container" style="max-width: 450px;">
    <div class="card p-4">
        <h2 class="text-center mb-4">Instructeur Inloggen</h2>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="mb-3">
                <label for="email" class="form-label">E-mailadres</label>
                <input type="email" id="email" name="email" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Wachtwoord</label>
                <input type="password" id="password" name="password" class="form-control" required>
            </div>
            <div class="d-grid">
                <button type="submit" class="btn btn-primary">Inloggen</button>
            </div>
            <div class="text-center mt-3">
                <a href="../../index.php">Terug naar home</a>
            </div>
        </form>
    </div>
</div>
</body>
</html>
