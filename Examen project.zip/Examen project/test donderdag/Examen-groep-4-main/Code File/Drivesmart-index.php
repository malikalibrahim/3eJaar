<?php

$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>DriveSmart - Inloggen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
    <h1 class="mb-4">DriveSmart portaal</h1>
    <p class="mb-3">Kies je rol om in te loggen:</p>
    <div class="list-group">
        <a href="student/login.php" class="list-group-item list-group-item-action">Leerling</a>
        <a href="teacher/login.php" class="list-group-item list-group-item-action">Instructeur</a>
        <a href="admin/login.php" class="list-group-item list-group-item-action">Rijschool / Admin</a>
    </div>
</div>
</body>
</html>


