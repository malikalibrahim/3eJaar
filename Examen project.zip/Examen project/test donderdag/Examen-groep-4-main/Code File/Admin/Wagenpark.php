<?php
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../../Database/database.php';
require_once __DIR__ . '/../Classes/Car.php';

$db = new Database('127.0.0.1', 'drivesmart', 'root', '');
$pdo = $db->getPdo();
$car = new Car($pdo);

$cars = $car->getAll();
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Wagenpark</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
            margin-bottom: 20px;
        }
        .table {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        }
        .table thead th {
            background: linear-gradient(135deg, #ff6b6b, #ee5a24);
            color: white;
            border: none;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .table tbody tr:hover {
            background-color: #f8f9fa;
            transform: scale(1.01);
            transition: all 0.2s ease;
        }
        h1 {
            color: #333;
            font-weight: 700;
        }
    </style>
</head>
<body>
    <h1>Wagenpark</h1>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Type</th>
                <th>Slijtage</th>
                <th>In gebruik</th>
                <th>Kilometerstand</th>
                <th>Onderhoud</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($cars as $c): ?>
                <tr>
                    <td><?= $c['idCars'] ?></td>
                    <td><?= $c['CarsType'] ?></td>
                    <td><?= $c['CarsWear'] ?></td>
                    <td><?= $c['CarsUsed'] ? 'Ja' : 'Nee' ?></td>
                    <td><?= $c['CarsODO'] ?> km</td>
                    <td><?= $c['CarsMaintenance'] ? 'Ja' : 'Nee' ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>