<?php
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}
?>
<?php
$pageTitle = "Admin Dashboard";
require_once __DIR__ . '/header.php';
?>

<h1 class="mb-4">Admin Dashboard</h1>

<div class="row g-4">
    <div class="col-md-4">
        <div class="card h-100">
            <div class="card-body d-flex flex-column">
                <h5 class="card-title">Instructeurs</h5>
                <p class="card-text">Nieuwe instructeurs toevoegen aan het systeem.</p>
                <a href="teacher-add.php" class="btn btn-primary mt-auto">Instructeur aanmaken</a>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card h-100">
            <div class="card-body d-flex flex-column">
                <h5 class="card-title">Wagenpark</h5>
                <p class="card-text">Bekijk en beheer de voertuigen van de rijschool.</p>
                <a href="Wagenpark.php" class="btn btn-primary mt-auto">Wagenpark beheren</a>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card h-100">
            <div class="card-body d-flex flex-column">
                <h5 class="card-title">Algemene Voorwaarden</h5>
                <p class="card-text">Pas de algemene voorwaarden voor klanten aan.</p>
                <a href="terms.php" class="btn btn-primary mt-auto">Voorwaarden beheren</a>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>