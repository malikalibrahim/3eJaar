-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 02 dec 2025 om 11:04
-- Serverversie: 10.4.32-MariaDB
-- PHP-versie: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drivesmart`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `admin`
--

CREATE TABLE `admin` (
  `idAdmin` int(11) NOT NULL,
  `AdminName` varchar(255) NOT NULL,
  `AdminPsw` varchar(255) NOT NULL,
  `AdminTerms` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `announcements`
--

CREATE TABLE `announcements` (
  `idAnnouncements` int(11) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Message` varchar(500) NOT NULL,
  `TargetGroup` varchar(20) NOT NULL,
  `CreatedAt` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `cars`
--

CREATE TABLE `cars` (
  `idCars` int(11) NOT NULL,
  `CarsType` varchar(255) NOT NULL,
  `CarsWear` varchar(255) NOT NULL,
  `CarsUsed` tinyint(4) NOT NULL,
  `Carscol` varchar(45) DEFAULT NULL,
  `CarsODO` int(11) DEFAULT NULL,
  `CarsMaintenance` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `lessons`
--

CREATE TABLE `lessons` (
  `remark` varchar(255) DEFAULT NULL,
  `Subject` varchar(255) DEFAULT NULL,
  `Price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `schedule`
--

CREATE TABLE `schedule` (
  `idSchedule` int(11) NOT NULL,
  `ScheduleDateTime` datetime NOT NULL,
  `ScheduleCar` varchar(255) NOT NULL,
  `SchedulePickLoc` varchar(255) NOT NULL,
  `ScheduleStudentId` int(11) DEFAULT NULL,
  `ScheduleTeacherId` int(11) DEFAULT NULL,
  `ScheduleSubject` varchar(255) DEFAULT NULL,
  `ScheduleStatus` varchar(50) DEFAULT 'planned',
  `ScheduleCancelReason` varchar(255) DEFAULT NULL,
  `ScheduleStudentRemark` varchar(255) DEFAULT NULL,
  `ScheduleTeacherRemark` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `stripcard`
--

CREATE TABLE `stripcard` (
  `idStripCard` int(11) NOT NULL,
  `StripCardAmount` int(11) NOT NULL,
  `StripCardHolder` varchar(255) NOT NULL COMMENT 'FK'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `students`
--

CREATE TABLE `students` (
  `idStudents` int(11) NOT NULL,
  `StudentsName` varchar(255) NOT NULL,
  `StudentsAge` int(11) NOT NULL,
  `StudentsAddress` varchar(255) NOT NULL,
  `StudentsPhoneNumber` int(11) NOT NULL,
  `StudentsEmail` varchar(255) NOT NULL,
  `StudentsPsw` varchar(255) NOT NULL,
  `StudentsStripCard` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `teachers`
--

CREATE TABLE `teachers` (
  `idTeachers` int(11) NOT NULL,
  `TeachersName` varchar(255) NOT NULL,
  `TeachersEmail` varchar(255) NOT NULL,
  `TeachersPhoneNumber` int(11) NOT NULL,
  `TeachersPsw` varchar(255) NOT NULL,
  `Avaiblilty` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`idAnnouncements`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `announcements`
--
ALTER TABLE `announcements`
  MODIFY `idAnnouncements` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
