<?php
// Bootstrap: zoek omhoog naar project root config.php en include indien aanwezig
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Admin dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Welkom, <?= htmlspecialchars($_SESSION['admin_name']) ?></h2>
        <div>
            <a href="logout.php" class="btn btn-outline-danger btn-sm">Uitloggen</a>
        </div>
    </div>

    <div class="list-group">
        <a href="teacher-add.php" class="list-group-item list-group-item-action">
            Instructeur-account aanmaken
        </a>
        <a href="terms.php" class="list-group-item list-group-item-action">
            Algemene voorwaarden beheren
        </a>
    </div>
</div>
</body>
</html>


