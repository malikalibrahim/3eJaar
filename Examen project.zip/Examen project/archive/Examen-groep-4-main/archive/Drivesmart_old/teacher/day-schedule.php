<?php
// Bootstrap: zoek omhoog naar project root config.php en include indien aanwezig
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../includes/schedule-class.php';
session_start();

if (!isset($_SESSION['teacher_id'])) {
    header('Location: login.php');
    exit;
}

$teacherId = $_SESSION['teacher_id'];
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

$schedule = new Schedule();
$lessons = $schedule->getTeacherDaySchedule($teacherId, $date);
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Dagrooster <?= htmlspecialchars($date) ?></title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        h2 { margin-bottom: 0.5rem; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #000; padding: 4px; }
        @media print {
            body { margin: 0; }
        }
    </style>
</head>
<body onload="window.print()">
    <h2>Dagrooster <?= htmlspecialchars($date) ?></h2>
    <p>Instructeur: <?= htmlspecialchars($_SESSION['teacher_name']) ?></p>
    <table>
        <thead>
        <tr>
            <th>Datum/tijd</th>
            <th>Leerling ID</th>
            <th>Onderwerp</th>
            <th>Status</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($lessons as $lesson): ?>
            <tr>
                <td><?= htmlspecialchars($lesson['ScheduleDateTime']) ?></td>
                <td><?= htmlspecialchars($lesson['ScheduleStudentId']) ?></td>
                <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '') ?></td>
                <td><?= htmlspecialchars($lesson['ScheduleStatus']) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>


