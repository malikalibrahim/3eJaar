<?php
// Bootstrap: zoek omhoog naar project root config.php en include indien aanwezig
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../includes/schedule-class.php';
session_start();

if (!isset($_SESSION['teacher_id'])) {
    header('Location: login.php');
    exit;
}

$scheduleId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$schedule = new Schedule();
$lesson = $schedule->getById($scheduleId);

if (!$lesson || (int)$lesson['ScheduleTeacherId'] !== (int)$_SESSION['teacher_id']) {
    http_response_code(403);
    echo "Je mag deze les niet aanpassen.";
    exit;
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dt = $_POST['datetime'] ?? '';
    $car = htmlspecialchars($_POST['car'] ?? '');
    $loc = htmlspecialchars($_POST['pickloc'] ?? '');
    $subject = htmlspecialchars($_POST['subject'] ?? '');
    $status = htmlspecialchars($_POST['status'] ?? 'planned');

    if ($dt === '' || $car === '' || $loc === '') {
        $message = 'Vul alle verplichte velden in.';
    } else {
        $schedule->updateLesson($scheduleId, $dt, $car, $loc, $subject, $status);
        header('Location: dashboard.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Les aanpassen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <h2 class="mb-3">Les aanpassen</h2>
    <?php if ($message): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <form method="post" class="card card-body">
        <div class="mb-3">
            <label class="form-label">Datum en tijd</label>
            <input type="datetime-local" name="datetime" class="form-control" required
                   value="<?= htmlspecialchars(str_replace(' ', 'T', $lesson['ScheduleDateTime'])) ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Auto</label>
            <input type="text" name="car" class="form-control" required
                   value="<?= htmlspecialchars($lesson['ScheduleCar']) ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Ophaallocatie</label>
            <input type="text" name="pickloc" class="form-control" required
                   value="<?= htmlspecialchars($lesson['SchedulePickLoc']) ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Onderwerp</label>
            <input type="text" name="subject" class="form-control"
                   value="<?= htmlspecialchars($lesson['ScheduleSubject'] ?? '') ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Status</label>
            <select name="status" class="form-select">
                <?php
                $statuses = ['planned', 'done', 'cancelled'];
                foreach ($statuses as $st):
                    $sel = $lesson['ScheduleStatus'] === $st ? 'selected' : '';
                    ?>
                    <option value="<?= htmlspecialchars($st) ?>" <?= $sel ?>><?= htmlspecialchars($st) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Opslaan</button>
        <a href="dashboard.php" class="btn btn-link">Terug</a>
    </form>
</div>
</body>
</html>


