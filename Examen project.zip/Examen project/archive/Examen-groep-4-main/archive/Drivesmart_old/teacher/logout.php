<?php
// Bootstrap: zoek omhoog naar project root config.php en include indien aanwezig
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
	if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
	$__parent = dirname($__dir);
	if ($__parent === $__dir) break;
	$__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

session_start();
session_unset();
session_destroy();
header('Location: login.php');
exit;


