<?php
require_once __DIR__ . '/db.php';

class Schedule {
    private $db;

    public function __construct() {
        $this->db = new DB();
    }

    public function getStudentLessons($studentId) {
        return $this->db->run(
            "SELECT * FROM schedule WHERE ScheduleStudentId = :sid ORDER BY ScheduleDateTime DESC",
            ["sid" => $studentId]
        )->fetchAll();
    }

    public function getTeacherDaySchedule($teacherId, $date) {
        return $this->db->run(
            "SELECT * FROM schedule 
             WHERE ScheduleTeacherId = :tid 
               AND DATE(ScheduleDateTime) = :date
             ORDER BY ScheduleDateTime",
            ["tid" => $teacherId, "date" => $date]
        )->fetchAll();
    }

    public function addStudentRemark($scheduleId, $remark) {
        return $this->db->run(
            "UPDATE schedule SET ScheduleStudentRemark = :remark WHERE idSchedule = :id",
            ["remark" => $remark, "id" => $scheduleId]
        );
    }

    public function addTeacherRemark($scheduleId, $remark) {
        return $this->db->run(
            "UPDATE schedule SET ScheduleTeacherRemark = :remark WHERE idSchedule = :id",
            ["remark" => $remark, "id" => $scheduleId]
        );
    }

    public function cancelLesson($scheduleId, $reason) {
        return $this->db->run(
            "UPDATE schedule 
             SET ScheduleStatus = 'cancelled',
                 ScheduleCancelReason = :reason
             WHERE idSchedule = :id",
            ["reason" => $reason, "id" => $scheduleId]
        );
    }

    public function getById($id) {
        return $this->db->run(
            "SELECT * FROM schedule WHERE idSchedule = :id",
            ["id" => $id]
        )->fetch();
    }

    public function updateLesson($id, $dateTime, $car, $pickLoc, $subject, $status) {
        return $this->db->run(
            "UPDATE schedule
             SET ScheduleDateTime = :dt,
                 ScheduleCar = :car,
                 SchedulePickLoc = :loc,
                 ScheduleSubject = :subject,
                 ScheduleStatus = :status
             WHERE idSchedule = :id",
            [
                "dt" => $dateTime,
                "car" => $car,
                "loc" => $pickLoc,
                "subject" => $subject,
                "status" => $status,
                "id" => $id
            ]
        );
    }
}


