<?php
// Include the database configuration
require_once 'config.php';

try {
    // Get all tables
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_NUM);

    echo "Tables in database 'drivesmart':\n";
    foreach ($tables as $table) {
        echo "- " . $table[0] . "\n";
    }

    echo "\nTable structures:\n";

    foreach ($tables as $table) {
        $tableName = $table[0];
        echo "\n$tableName:\n";
        $stmt = $pdo->prepare("DESCRIBE $tableName");
        $stmt->execute();
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($columns as $column) {
            echo "  - {$column['Field']}: {$column['Type']} ({$column['Null']}, {$column['Key']}, {$column['Default']}, {$column['Extra']})\n";
        }
    }

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
