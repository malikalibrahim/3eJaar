
<?php
// Gebruik __DIR__ om altijd de db.php uit dezelfde map te includen
require_once __DIR__ . '/db.php';

class Student {
    private $pdo;


    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }


    
public function LoginUsers($email) {
    $stmt = $this->pdo->prepare("SELECT * FROM students WHERE StudentsEmail = :email");
    $stmt->execute(['email' => $email]); 
    return $stmt->fetch(PDO::FETCH_ASSOC); 
}


    public function create(array $data): int {
        $sql = "INSERT INTO students
            (StudentsName, StudentsAge, StudentsAddress, StudentsPhoneNumber, StudentsEmail, StudentsPsw, StudentsStripCard)
            VALUES (:name, :age, :address, :phone, :email, :psw, :strip)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            'name' => $data['name'],
            'age' => $data['age'],
            'address' => $data['address'],
            'phone' => $data['phone'],
            'email' => $data['email'],
            'psw' => $data['password_hash'],
            'strip' => $data['stripcard'] ?? 0
        ]);
        return (int) $this->pdo->lastInsertId();
    }

    /**
     * Check whether an email already exists in the students table.
     * Returns true if the email is found, false otherwise.
     */
    public function emailExists(string $email): bool {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM students WHERE StudentsEmail = :email");
        $stmt->execute(['email' => $email]);
        return (int) $stmt->fetchColumn() > 0;
    }
}
?>