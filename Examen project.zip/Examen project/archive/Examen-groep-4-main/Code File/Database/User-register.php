<?php
// Central config include (project root). Keeps includes consistent.
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/User-class.php';



$student = new Student($pdo);
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $age = $_POST['age'] ?? '';            
    $address = $_POST['address'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    if ($name === '') {
        $message = 'Name required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Valid email required';
    } elseif (strlen($password) < 6) {
        $message = 'Password must be at least 6 characters';
    } elseif ($password !== $password_confirm) {
        $message = 'Passwords do not match';
    } elseif ($student->emailExists($email)) {
        $message = 'Email already used';
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $id = $student->create([
            'name' => $name,
            'age' => $age,                
            'address' => $address,
            'phone' => $phone,
            'email' => $email,
            'password_hash' => $hash
        ]);
        if ($id > 0) {
            header('Location: login_student.php?registered=1');
            exit;
        } else {
            $message = 'Could not create account';
        }
    }
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Register page</title>
<link rel="stylesheet" href="../Styling/registerStudent.css">
</head>

<body>
  <div class="container">
    <div class="logo">
      <h1>DriveSmart</h1>
      <span>Student Registration</span>
    </div>

    <h2>Register</h2>
    
    <form method="post">
      <label>Name <input name="name" type="text" required></label>
      <label>Age <input name="age" type="number" required></label>
      <label>Address <input name="address" type="text" required></label>
      <label>Phone <input name="phone" type="number" required></label>
      <label>Email <input name="email" type="email" required></label>
      <label>Password <input name="password" type="password" required></label>
      <label>Confirm password <input name="password_confirm" type="password" required></label>
      <button type="submit" class="btn-signup">Register</button>
    </form>

    <div class="footer-text">
      Already have an account? <a href="login.php">Login here</a>
    </div>
  </div>
</body>
</html>