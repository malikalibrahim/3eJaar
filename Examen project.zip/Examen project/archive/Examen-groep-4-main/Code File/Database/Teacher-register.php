<?php
// Central config include (project root). Keeps includes consistent.
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/Teacher-class.php';




if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user = new Teachers($pdo); 
    $success = $user->RegisterTeacher($_POST['name'], $_POST['email'], $_POST['password']);

    if ($success) {
        header("Location: login.php");
        exit();
    } else {
        echo "Registration failed. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register</title>
</head>
<body>
    <form method="POST">
        <input type="text" name="name" placeholder="Name" required>
        <input type="text" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="submit" value="Register">
    </form>
</body>
</html>
