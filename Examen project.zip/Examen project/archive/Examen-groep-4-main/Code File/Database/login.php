<?php
require_once __DIR__ . '/../../config.php';

$melding = ""; // Variabele voor eventuele fout- of infomeldingen

// Controleren of het formulier verstuurd is via POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Gegevens uitlezen uit het formulier (met null-coalescing operator voor als het veld niet bestaat)
    $rol = $_POST['rol'] ?? '';
    $email = $_POST['email'] ?? '';
    $wachtwoord = $_POST['wachtwoord'] ?? '';

    // Simpele controle: alle velden moeten ingevuld zijn
    if (empty($rol) || empty($email) || empty($wachtwoord)) {
        $melding = "Vul alle velden in.";
    } else {
        require_once __DIR__ . '/db.php';
        if ($rol === 'leerling') {
            require_once __DIR__ . '/User-class.php';
            $userClass = new Student($pdo);
            $userData = $userClass->LoginUsers($email);
        } elseif ($rol === 'instructeur') {
            require_once __DIR__ . '/teacher-class.php';
            $instructorClass = new Teachers($pdo);
            $userData = $instructorClass->LoginTeacher($email);
        } elseif ($rol === 'admin') {
            require_once __DIR__ . '/Admin-class.php';
            $adminClass = new Admin($pdo);
            $userData = $adminClass->LoginAdmin($email);
        } else {
            $melding = "Ongeldige rol geselecteerd.";
            $userData = null;
        }

        // Controleren of er een gebruiker is gevonden en of het wachtwoord klopt
        if ($userData) {
            $passwordVerified = false;
            if ($rol === 'leerling' && password_verify($wachtwoord, $userData['StudentsPsw'])) {
                $passwordVerified = true;
            } elseif ($rol === 'instructeur' && password_verify($wachtwoord, $userData['TeachersPsw'])) {
                $passwordVerified = true;
            } elseif ($rol === 'admin' && password_verify($wachtwoord, $userData['AdminPsw'])) {
                $passwordVerified = true;
            }
            if ($passwordVerified) {
                // Inloggen gelukt
                session_start();
                $_SESSION['user_id'] = $userData['id'];
                $_SESSION['role'] = $rol;
                   if ($rol === 'leerling') {
                    $_SESSION['user_name'] = $userData['StudentsName'];  // Assuming the field is 'StudentsName'
                } elseif ($rol === 'instructeur') {
                    $_SESSION['user_name'] = $userData['TeachersName'];  // Assuming the field is 'TeachersName'
                } elseif ($rol === 'admin') {
                    $_SESSION['user_name'] = $userData['AdminName'];  // Assuming the field is 'AdminName'
                }
                header("Location: ../UserInteractive/MainPage.php");
                exit();
            } else {
                // Inloggen mislukt
                $melding = "Ongeldig e-mailadres of wachtwoord.";
            }
        } else {
            // Geen gebruiker gevonden
            $melding = "Ongeldig e-mailadres of wachtwoord.";
        }
        
    }
}
?>
<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <title>Rijschool Login</title>
    <style>
        /* Algemene stijl voor de body (volledige pagina) */
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: linear-gradient(135deg, #1e90ff, #6E8B3D, #d5e643ff);
            display: flex;
            /* Centreert de container horizontaal/verticaal */
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            /* Volledige hoogte van het scherm */
            color: #333;
        }

        /* De “kaart” in het midden van het scherm */
        .container {
            background: #ffffffee;
            /* Witte achtergrond met lichte transparantie */
            padding: 30px 35px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
            /* Schaduw onder de kaart */
            max-width: 400px;
            width: 100%;
        }

        /* Bovenste logo / titelgedeelte */
        .logo {
            text-align: center;
            margin-bottom: 20px;
        }

        .logo h1 {
            margin: 0;
            font-size: 26px;
            letter-spacing: 1px;
            color: #2c3e50;
        }

        .logo span {
            font-size: 13px;
            color: #7f8c8d;
        }

        h2 {
            margin-top: 20px;
            margin-bottom: 10px;
            font-size: 20px;
            text-align: center;
            color: #34495e;
        }

        form {
            margin-top: 10px;
        }

        /* Standaard opmaak voor labels boven de inputs */
        label {
            display: block;
            margin-top: 12px;
            margin-bottom: 5px;
            font-size: 14px;
            color: #555;
        }

        /* Stijl voor tekstvelden en dropdown */
        input[type="email"],
        input[type="password"],
        select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #dcdde1;
            border-radius: 8px;
            font-size: 14px;
            box-sizing: border-box;
            /* Padding telt mee in de total width */
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        /* Focus-stijl als gebruiker in een veld klikt */
        input[type="email"]:focus,
        input[type="password"]:focus,
        select:focus {
            outline: none;
            border-color: #1e90ff;
            box-shadow: 0 0 0 2px rgba(30, 144, 255, 0.15);
        }

        /* Extra uitleg onder de rol-keuze */
        .rol-info {
            font-size: 12px;
            color: #7f8c8d;
            margin-top: 3px;
        }

        /* Opmaak van de login-knop */
        .btn-login {
            margin-top: 18px;
            width: 100%;
            padding: 11px;
            border: none;
            border-radius: 25px;
            font-size: 15px;
            font-weight: bold;
            color: #fff;
            background: linear-gradient(135deg, #1e90ff, #00b894);
            cursor: pointer;
            transition: transform 0.1s, box-shadow 0.1s, opacity 0.2s;
        }

        /* Hover-effect op de knop */
        .btn-login:hover {
            opacity: 0.95;
            box-shadow: 0 8px 18px rgba(0, 0, 0, 0.15);
            transform: translateY(-1px);
        }

        /* Effect als de knop wordt ingedrukt */
        .btn-login:active {
            transform: translateY(1px);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.18);
        }

        .footer-text {
            margin-top: 15px;
            text-align: center;
            font-size: 12px;
            color: #95a5a6;
        }

        /* Stijl van de melding (bijv. foutmelding of info) */
        .melding {
            margin-top: 10px;
            padding: 8px 10px;
            border-radius: 8px;
            font-size: 13px;
            background: #ffeaa7;
            color: #2d3436;
        }

        /* Responsieve aanpassingen voor kleine schermen (mobiel) */
        @media (max-width: 480px) {
            .container {
                margin: 15px;
                padding: 25px 20px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="logo">
            <h1>Rijschool Login</h1>
            <span>Log in als leerling, instructeur of admin</span>
        </div>

        <h2>Inloggen</h2>

        <?php if (!empty($melding)): ?>
            <!-- Als er een melding is gezet in PHP, toon deze dan hier -->
            <div class="melding">
                <?php
                // htmlspecialchars voorkomt dat eventueel ingevoerde HTML of scripts uitgevoerd worden (beveiliging)
                echo htmlspecialchars($melding, ENT_QUOTES, 'UTF-8');
                ?>
            </div>
        <?php endif; ?>

        <!-- Het loginformulier. action="" betekent: stuur terug naar dezelfde pagina -->
        <form method="post" action="">
            <label for="rol">Rol</label>
            <select name="rol" id="rol" required>
                <option value="">-- Kies je rol --</option>
                <option value="leerling">Leerling</option>
                <option value="instructeur">Instructeur</option>
                <option value="admin">Admin</option>
            </select>
            <div class="rol-info">
                Kies of je als leerling, instructeur of administrator wilt inloggen.
            </div>

            <label for="email">E-mailadres</label>
            <!-- type="email" zorgt voor basisvalidatie in de browser -->
            <input type="email" id="email" name="email" placeholder="voorbeeld@mail.nl" required>

            <label for="wachtwoord">Wachtwoord</label>
            <input type="password" id="wachtwoord" name="wachtwoord" placeholder="Je wachtwoord" required>

            <!-- Submit-knop die het formulier verstuurt via POST -->
            <button type="submit" class="btn-login">Inloggen</button>
        </form>

    </div>
</body>

</html>