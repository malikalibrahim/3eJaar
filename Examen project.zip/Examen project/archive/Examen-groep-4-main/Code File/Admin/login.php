<?php
require_once __DIR__ . '/../Database/db.php';
session_start();

if (isset($_SESSION['admin_id'])) {
    header('Location: HomepageAdmin.php');
    exit;
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($name) || empty($password)) {
        $error = 'Vul alle velden in.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM admin WHERE AdminName = :name");
        $stmt->execute(['name' => $name]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['AdminPsw'])) {
            $_SESSION['admin_id'] = $admin['idAdmin'];
            $_SESSION['admin_name'] = $admin['AdminName'];
            header('Location: HomepageAdmin.php');
            exit;
        } else {
            $error = 'Ongeldige inloggegevens.';
    }
}}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Rijschool / Admin inloggen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            max-width: 400px;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            background: rgba(255, 255, 255, 0.95);
        }
        .card-body {
            padding: 2rem;
        }
        .btn {
            border-radius: 25px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        .form-control {
            border-radius: 10px;
            border: 1px solid #ddd;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        h2 {
            color: #333;
            font-weight: 700;
            text-align: center;
            margin-bottom: 1.5rem;
        }
        .alert {
            border-radius: 10px;
        }
    </style>
</head>
<body class="bg-light">
<div class="container py-5">
    <h2 class="mb-4">Admin inloggen</h2>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post" class="card card-body">
        <div class="mb-3">
            <label class="form-label">Gebruikersnaam</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Wachtwoord</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Inloggen</button>
        <a href="../../index.php" class="btn btn-link">Terug</a>
    </form>
</div>
</body>
</html>


