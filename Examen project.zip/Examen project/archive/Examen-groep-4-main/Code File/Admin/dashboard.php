<?php
// Bootstrap: zoek omhoog naar project root config.php en include indien aanwezig
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-0">Admin Dashboard</h2>
            <small class="text-muted">Welkom, <?= htmlspecialchars($_SESSION['admin_name'] ?? 'Admin') ?></small>
        </div>
        <a href="logout.php" class="btn btn-danger">Uitloggen</a>
    </div>

    <h4>Beheer</h4>
    <div class="row g-3">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Instructeurs</h5>
                    <p class="card-text">Beheer instructeur accounts</p>
                    <a href="teacher-add.php" class="btn btn-primary">Instructeur aanmaken</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Admins</h5>
                    <p class="card-text">Beheer admin accounts</p>
                    <a href="#" class="btn btn-secondary disabled">Admin aanmaken (TODO)</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Wagenpark</h5>
                    <p class="card-text">Beheer auto's en wagenpark</p>
                    <a href="Wagenpark.php" class="btn btn-primary">Wagenpark bekijken</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Algemene Voorwaarden</h5>
                    <p class="card-text">Beheer algemene voorwaarden</p>
                    <a href="terms.php" class="btn btn-primary">Voorwaarden beheren</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Mededelingen</h5>
                    <p class="card-text">Beheer mededelingen voor instructeurs en leerlingen</p>
                    <a href="announcements.php" class="btn btn-primary">Mededelingen beheren</a>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>