<?php
// Bootstrap: zoek omhoog naar project root config.php en include indien aanwezig
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/admin-class.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$admin = new Admin();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $terms = $_POST['terms'] ?? '';
    $admin->updateTerms($terms);
    $message = 'Voorwaarden opgeslagen.';
}

$currentTerms = $admin->getTerms();
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Algemene voorwaarden</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <h2 class="mb-3">Algemene voorwaarden beheren</h2>
    <?php if ($message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <form method="post" class="card card-body mb-4">
        <div class="mb-3">
            <label class="form-label">Inhoud voorwaarden</label>
            <textarea name="terms" class="form-control" rows="10"><?= htmlspecialchars($currentTerms ?? '') ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Opslaan</button>
        <a href="HomepageAdmin.php" class="btn btn-link">Terug</a>
    </form>

    <h3>Gepubliceerde voorwaarden (publieke weergave)</h3>
    <div class="card card-body">
        <pre style="white-space: pre-wrap;"><?= htmlspecialchars($currentTerms ?? '') ?></pre>
    </div>
</div>
</body>
</html>


