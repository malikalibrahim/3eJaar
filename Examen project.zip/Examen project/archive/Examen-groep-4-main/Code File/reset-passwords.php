<?php
// Bootstrap: zoek omhoog naar project root config.php en include indien aanwezig
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Wachtwoord Reset Script</h1>";

$newPassword = 'wachtwoord';
$hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

try {
    $db = new DB();

    // Reset wachtwoord voor student met ID 1
    $stmtStudent = $db->run("UPDATE students SET StudentsPsw = ? WHERE idStudents = 1", [$hashedPassword]);
    $rowsAffectedStudent = $stmtStudent->rowCount();
    echo "<p style='color: green;'>Wachtwoord voor student met ID 1 is gereset naar: <strong>wachtwoord</strong>. Rijen beïnvloed: " . $rowsAffectedStudent . "</p>";

    // Reset wachtwoord voor instructeur met ID 1
    $stmtTeacher = $db->run("UPDATE teachers SET TeachersPsw = ? WHERE idTeachers = 1", [$hashedPassword]);
    $rowsAffectedTeacher = $stmtTeacher->rowCount();
    echo "<p style='color: green;'>Wachtwoord voor instructeur met ID 1 is gereset naar: <strong>wachtwoord</strong>. Rijen beïnvloed: " . $rowsAffectedTeacher . "</p>";

    // If no rows were affected, it means the IDs might not exist.
    // This is a good place to add a warning if $rowsAffectedStudent or $rowsAffectedTeacher is 0.
    echo "<hr><h3>Je kunt nu inloggen met de onderstaande gegevens:</h3>";
    echo "<h4>Leerling:</h4>";
    echo "<ul><li>E-mail: <strong>hi@gmail.com</strong></li><li>Wachtwoord: <strong>wachtwoord</strong></li></ul>";
    echo "<a href='Leerling/login.php' class='btn btn-primary'>Login als Leerling</a>";
    echo "<h4>Instructeur:</h4>";
    echo "<ul><li>E-mail: <strong>1@gmail.com</strong></li><li>Wachtwoord: <strong>wachtwoord</strong></li></ul>";
    echo "<a href='Instructor/login.php' class='btn btn-primary'>Login als Instructeur</a>";

} catch (Exception $e) {
    echo "<p style='color: red;'>ERROR: " . $e->getMessage() . "</p>";
}
?>