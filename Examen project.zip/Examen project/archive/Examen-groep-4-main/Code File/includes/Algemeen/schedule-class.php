<?php
// Gebruik centrale wrapper
require_once __DIR__ . '/../../Database/db.php';

class Schedule {
    private $db;

    public function __construct() {
        $this->db = new DB();
    }

    /**
     * Haal alle lessen voor een leerling op (geen datumrestrictie), nieuwste eerst.
     * Kolommen sluiten aan op de weergave in de leerling-homepage.
     */
    public function getStudentLessons(int $studentId) {
        $sql = "
            SELECT 
                idSchedule,
                ScheduleDateTime,
                ScheduleCar,
                SchedulePickLoc,
                ScheduleSubject,
                ScheduleStatus,
                ScheduleStudentRemark,
                ScheduleTeacherRemark
            FROM schedule
            WHERE ScheduleStudentId = :sid
            ORDER BY ScheduleDateTime DESC
        ";
        return $this->db->run($sql, ["sid" => $studentId])->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Optioneel: alleen aankomende lessen (vanaf nu), oudste eerst.
     */
    public function getUpcomingStudentLessons(int $studentId) {
        $sql = "
            SELECT 
                idSchedule,
                ScheduleDateTime,
                ScheduleCar,
                SchedulePickLoc,
                ScheduleSubject,
                ScheduleStatus,
                ScheduleStudentRemark,
                ScheduleTeacherRemark
            FROM schedule
            WHERE ScheduleStudentId = :sid
              AND ScheduleDateTime >= NOW()
            ORDER BY ScheduleDateTime ASC
        ";
        return $this->db->run($sql, ["sid" => $studentId])->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getTeacherDaySchedule(int $teacherId, string $date) {
        $sql = "
            SELECT 
                schedule.*,
                students.StudentsName
            FROM schedule
            LEFT JOIN students ON schedule.ScheduleStudentId = students.idStudents
            WHERE schedule.ScheduleTeacherId = :tid
              AND DATE(schedule.ScheduleDateTime) = :date
            ORDER BY schedule.ScheduleDateTime ASC";

        return $this->db->run($sql, ["tid" => $teacherId, "date" => $date])->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getTeacherLessons(int $teacherId) {
        $sql = "
            SELECT 
                schedule.*,
                students.StudentsName
            FROM schedule
            LEFT JOIN students ON schedule.ScheduleStudentId = students.idStudents
            WHERE schedule.ScheduleTeacherId = :tid
            ORDER BY schedule.ScheduleDateTime DESC";
        
        return $this->db->run($sql, ["tid" => $teacherId])->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addStudentRemark(int $scheduleId, string $remark) {
        $stmt = $this->db->run(
            "UPDATE schedule
             SET ScheduleStudentRemark = :remark
             WHERE idSchedule = :id",
            ["remark" => $remark, "id" => $scheduleId]
        );
        if ($stmt->rowCount() === 0) {
            throw new Exception("Failed to update student remark. Schedule ID may not exist or no changes made.");
        }
        return $stmt;
    }

    public function addTeacherRemark(int $scheduleId, string $remark) {
        $stmt = $this->db->run(
            "UPDATE schedule
             SET ScheduleTeacherRemark = :remark
             WHERE idSchedule = :id",
            ["remark" => $remark, "id" => $scheduleId]
        );
        if ($stmt->rowCount() === 0) {
            throw new Exception("Failed to update teacher remark. Schedule ID may not exist or no changes made.");
        }
        return $stmt;
    }

    public function cancelLesson(int $scheduleId, string $reason) {
        return $this->db->run(
            "UPDATE schedule 
             SET ScheduleStatus = 'cancelled',
                 ScheduleCancelReason = :reason
             WHERE idSchedule = :id",
            ["reason" => $reason, "id" => $scheduleId]
        );
    }

    public function getById(int $id) {
        return $this->db->run(
            "SELECT * FROM schedule WHERE idSchedule = :id",
            ["id" => $id]
        )->fetch(PDO::FETCH_ASSOC);
    }

    public function updateLesson(int $id, string $dateTime, string $car, string $pickLoc, string $subject, string $status) {
        return $this->db->run(
            "UPDATE schedule
             SET ScheduleDateTime = :dt,
                 ScheduleCar = :car,
                 SchedulePickLoc = :loc,
                 ScheduleSubject = :subject,
                 ScheduleStatus = :status
             WHERE idSchedule = :id",
            [
                "dt" => $dateTime,
                "car" => $car,
                "loc" => $pickLoc,
                "subject" => $subject,
                "status" => $status,
                "id" => $id
            ]
        );
    }
}