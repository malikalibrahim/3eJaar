<?php
// Gebruik centrale wrapper
require_once __DIR__ . '/../../Database/db.php';

class Announcement {
    private $db;

    public function __construct() {
        $this->db = new DB();
    }

    public function getForTarget($targetGroup) {
        return $this->db->run(
            "SELECT * FROM announcements WHERE TargetGroup = :tg ORDER BY CreatedAt DESC",
            ["tg" => $targetGroup]
        )->fetchAll();
    }
}


