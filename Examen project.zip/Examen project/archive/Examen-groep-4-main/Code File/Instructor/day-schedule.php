<?php
// Bootstrap: zoek omhoog naar project root config.php en include indien aanwezig
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../includes/Algemeen/schedule-class.php';
require_once __DIR__ . '/../includes/Algemeen/announcement-class.php';
session_start();

if (!isset($_SESSION['teacher_id'])) {
    header('Location: login.php');
    exit;
}

$teacherId = $_SESSION['teacher_id'];
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

$schedule = new Schedule();
$lessons = $schedule->getTeacherDaySchedule($teacherId, $date);

$announcement = new Announcement();
$announcements = $announcement->getForTarget('teacher');
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Dagrooster - <?= htmlspecialchars($date) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            background-color: white;
            border-radius: 15px;
            padding: 2rem;
            margin-top: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        @media print {
            body {
                background-color: white;
                margin: 0.5cm;
            }
            .no-print { display: none; }
            .container {
                box-shadow: none;
                border: none;
                padding: 0;
                margin: 0;
            }
            .table {
                font-size: 12px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="card card-body mb-4 no-print">
        <h5 class="card-title">Rooster Opties</h5>
        <div class="row align-items-end">
            <div class="col-md-6">
                <form method="get" action="day-schedule.php" class="d-flex align-items-center">
                    <div class="flex-grow-1 me-2">
                        <label for="date" class="form-label">Kies een datum</label>
                        <input type="date" id="date" name="date" class="form-control" value="<?= htmlspecialchars($date) ?>">
                    </div>
                    <button type="submit" class="btn btn-primary align-self-end">Toon</button>
                </form>
            </div>
            <div class="col-md-6 text-md-end mt-3 mt-md-0">
                <button onclick="window.print()" class="btn btn-success">Print dit rooster</button>
                <a href="dashboard.php" class="btn btn-secondary">Terug naar dashboard</a>
            </div>
        </div>
    </div>

    <h2 class="mb-3">Dagrooster voor <?= htmlspecialchars((new DateTime($date))->format('d-m-Y')) ?></h2>
    <p>Instructeur: <?= htmlspecialchars($_SESSION['teacher_name']) ?></p>
    <table class="table table-bordered table-striped">
        <thead>
        <tr>
            <th>Tijd</th>
            <th>Leerling</th>
            <th>Onderwerp</th>
            <th>Status</th>
            <th>Ophaallocatie</th>
        </tr>
        </thead>
        <tbody>
        <?php if (empty($lessons)): ?>
            <tr><td colspan="5" class="text-center text-muted">Geen lessen gepland voor deze dag.</td></tr>
        <?php else: ?>
            <?php foreach ($lessons as $lesson): ?>
                <?php
                    $dateTime = new DateTime($lesson['ScheduleDateTime']);
                ?>
                <tr>
                    <td><?= $dateTime->format('H:i') ?></td>
                    <td><?= htmlspecialchars($lesson['StudentsName'] ?? 'Onbekend') ?></td>
                    <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '') ?></td>
                    <td><?= htmlspecialchars($lesson['ScheduleStatus']) ?></td>
                    <td><?= htmlspecialchars($lesson['SchedulePickLoc'] ?? '') ?></td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>

    <?php if ($announcements): ?>
        <div class="card mt-4 no-print">
            <div class="card-header">
                Mededelingen voor instructeurs
            </div>
            <ul class="list-group list-group-flush">
            <?php foreach ($announcements as $note): ?>
                <li class="list-group-item">
                    <strong><?= htmlspecialchars($note['Title']) ?>:</strong>
                    <?= htmlspecialchars($note['Message']) ?>
                    <br><small class="text-muted">Gepost op: <?= htmlspecialchars((new DateTime($note['CreatedAt']))->format('d-m-Y H:i')) ?></small>
                </li>
            <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
