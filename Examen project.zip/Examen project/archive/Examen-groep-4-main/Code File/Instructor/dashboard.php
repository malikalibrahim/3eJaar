<?php
// Bootstrap: zoek omhoog naar project root config.php en include indien aanwezig
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../includes/Algemeen/schedule-class.php';
require_once __DIR__ . '/../includes/Algemeen/announcement-class.php';
session_start();

if (!isset($_SESSION['teacher_id'])) {
    header('Location: login.php');
    exit;
}

$teacherId = $_SESSION['teacher_id'];
$schedule = new Schedule();
$announcement = new Announcement();

$today = date('Y-m-d');
$lessons = $schedule->getTeacherLessons($teacherId);
$announcements = $announcement->getForTarget('teacher');
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Instructeur dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #2196F3 0%, #21CBF3 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
            margin-bottom: 20px;
        }
        .table {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        }
        .table thead th {
            background: linear-gradient(135deg, #2196F3, #21CBF3);
            color: white;
            border: none;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .table tbody tr:hover {
            background-color: #f8f9fa;
            transform: scale(1.01);
            transition: all 0.2s ease;
        }
        .btn {
            border-radius: 25px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        }
        h2, h4 {
            color: #333;
            font-weight: 700;
        }
        .badge {
            font-size: 0.75em;
        }
        .text-muted {
            color: #6c757d !important;
        }
    </style>
</head>
<body>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Welkom, <?= htmlspecialchars($_SESSION['teacher_name']) ?></h2>
        <div>
            <a href="day-schedule.php?date=<?= $today ?>" class="btn btn-outline-secondary btn-sm">Dagrooster printen</a>
            <a href="logout.php" class="btn btn-outline-danger btn-sm">Uitloggen</a>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-md-8">
            <h4>Mijn lessen</h4>
            <table class="table table-striped table-sm">
                <thead>
                <tr>
                    <th>Datum/tijd</th>
                    <th>Leerling</th>
                    <th>Onderwerp</th>
                    <th>Status</th>
                    <th>Annuleringsreden</th>
                    <th>Leerling opmerking</th>
                    <th>Mijn opmerking</th>
                    <th>Acties</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($lessons as $lesson): ?>
                    <tr>
                        <td><?= htmlspecialchars($lesson['ScheduleDateTime']) ?></td>
                        <td><?= htmlspecialchars($lesson['StudentsName'] ?? 'Onbekend') ?></td>
                        <td><?= htmlspecialchars($lesson['ScheduleSubject'] ?? '') ?></td>
                        <td><?= htmlspecialchars($lesson['ScheduleStatus']) ?></td>
                        <td>
                            <?php if (!empty($lesson['ScheduleCancelReason'])): ?>
                                <small class="text-muted"><?= htmlspecialchars(substr($lesson['ScheduleCancelReason'], 0, 50)) ?>...</small>
                            <?php else: ?>
                                <small class="text-muted">Geen reden</small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!empty($lesson['ScheduleStudentRemark'])): ?>
                                <small class="text-muted"><?= htmlspecialchars(substr($lesson['ScheduleStudentRemark'], 0, 50)) ?>...</small>
                            <?php else: ?>
                                <small class="text-muted">Geen opmerking</small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!empty($lesson['ScheduleTeacherRemark'])): ?>
                                <small class="text-muted"><?= htmlspecialchars(substr($lesson['ScheduleTeacherRemark'], 0, 50)) ?>...</small>
                            <?php else: ?>
                                <small class="text-muted">Geen opmerking</small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="instructor-lesson-remark.php?id=<?= (int)$lesson['idSchedule'] ?>" class="btn btn-sm btn-primary">Opmerking</a>
                            <a href="instructor-lesson-edit.php?id=<?= (int)$lesson['idSchedule'] ?>" class="btn btn-sm btn-warning">Aanpassen</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="col-md-4">
            <h4>Mededelingen</h4>
            <?php if (!$announcements): ?>
                <p class="text-muted">Geen mededelingen.</p>
            <?php else: ?>
                <?php foreach ($announcements as $a): ?>
                    <div class="card mb-2">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($a['Title']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($a['Message']) ?></p>
                            <small class="text-muted"><?= htmlspecialchars($a['CreatedAt']) ?></small>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>
