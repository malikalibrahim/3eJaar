<?php
// Bootstrap: zoek omhoog naar project root config.php en include indien aanwezig
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../includes/Algemeen/schedule-class.php';
session_start();

if (!isset($_SESSION['teacher_id'])) {
    header('Location: login.php');
    exit;
}

$scheduleId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$schedule = new Schedule();
$lesson = $schedule->getById($scheduleId);

if (!$lesson || (int)$lesson['ScheduleTeacherId'] !== (int)$_SESSION['teacher_id']) {
    http_response_code(403);
    echo "Je mag voor deze les geen opmerking plaatsen.";
    exit;
}

$message = '';
$messageType = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $remark = htmlspecialchars($_POST['remark'] ?? '');
    if ($remark === '') {
        $message = 'Opmerking mag niet leeg zijn.';
        $messageType = 'danger';
    } else {
        try {
            $schedule->addTeacherRemark($scheduleId, $remark);
            $message = 'Opmerking succesvol toegevoegd.';
            $messageType = 'success';
        } catch (Exception $e) {
            $message = 'Fout bij het opslaan van de opmerking: ' . $e->getMessage();
            $messageType = 'danger';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Opmerking toevoegen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #2196F3 0%, #21CBF3 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            max-width: 500px;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            background: rgba(255, 255, 255, 0.95);
        }
        .card-body {
            padding: 2rem;
        }
        .btn {
            border-radius: 25px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        .form-control {
            border-radius: 10px;
            border: 1px solid #ddd;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: #2196F3;
            box-shadow: 0 0 0 0.2rem rgba(33, 150, 243, 0.25);
        }
        h2 {
            color: #333;
            font-weight: 700;
            text-align: center;
            margin-bottom: 1.5rem;
        }
        .alert {
            border-radius: 10px;
        }
        p {
            text-align: center;
            color: #666;
        }
    </style>
</head>
<body>
<div class="container py-4">
    <h2 class="mb-3">Opmerking toevoegen</h2>
    <p>Les op: <strong><?= htmlspecialchars($lesson['ScheduleDateTime']) ?></strong></p>
    <?php if ($message): ?>
        <div class="alert alert-<?= $messageType ?>"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <form method="post" class="card card-body">
        <div class="mb-3">
            <label class="form-label">Opmerking</label>
            <textarea name="remark" class="form-control" rows="4" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Opslaan</button>
        <a href="dashboard.php" class="btn btn-link">Terug</a>
    </form>
</div>
</body>
</html>


