<?php
// Test script om te checken of lessen worden opgehaald
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/Database/db.php';
require_once __DIR__ . '/includes/Algemeen/schedule-class.php';

echo "<h1>Test Schedule Data</h1>";

$schedule = new Schedule();

// Test: Haal alle data op uit schedule tabel
echo "<h2>Alle lessen in database:</h2>";
try {
    $db = new DB();
    $allLessons = $db->run("SELECT * FROM schedule ORDER BY ScheduleDateTime DESC")->fetchAll();
    
    echo "<p>Aantal lessen gevonden: " . count($allLessons) . "</p>";
    
    if (count($allLessons) > 0) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr>
                <th>ID</th>
                <th>DateTime</th>
                <th>Student ID</th>
                <th>Teacher ID</th>
                <th>Subject</th>
                <th>Status</th>
                <th>Car</th>
                <th>PickLoc</th>
              </tr>";
        
        foreach ($allLessons as $lesson) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($lesson['idSchedule'] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($lesson['ScheduleDateTime'] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($lesson['ScheduleStudentId'] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($lesson['ScheduleTeacherId'] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($lesson['ScheduleSubject'] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($lesson['ScheduleStatus'] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($lesson['ScheduleCar'] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($lesson['SchedulePickLoc'] ?? 'N/A') . "</td>";
            echo "</tr>";
        }
        
        echo "</table>";
    } else {
        echo "<p style='color: red;'>GEEN lessen gevonden in de database!</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>ERROR: " . $e->getMessage() . "</p>";
}

// Test: Haal lessen op voor specifieke student
echo "<h2>Test getStudentLessons (Student ID = 1):</h2>";
try {
    $studentLessons = $schedule->getStudentLessons(1);
    echo "<p>Aantal lessen voor student 1: " . count($studentLessons) . "</p>";
    if (count($studentLessons) > 0) {
        echo "<pre>";
        print_r($studentLessons);
        echo "</pre>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>ERROR: " . $e->getMessage() . "</p>";
}

// Test: Haal lessen op voor specifieke teacher
echo "<h2>Test getTeacherLessons (Teacher ID = 1):</h2>";
try {
    $teacherLessons = $schedule->getTeacherLessons(1);
    echo "<p>Aantal lessen voor teacher 1: " . count($teacherLessons) . "</p>";
    if (count($teacherLessons) > 0) {
        echo "<pre>";
        print_r($teacherLessons);
        echo "</pre>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>ERROR: " . $e->getMessage() . "</p>";
}

?>