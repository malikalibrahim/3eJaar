<?php
// Bootstrap: zoek omhoog naar project root config.php en include indien aanwezig
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

require_once __DIR__ . '/../includes/Algemeen/schedule-class.php';
session_start();

if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit;
}

$scheduleId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$schedule = new Schedule();
$lesson = $schedule->getById($scheduleId);

if (!$lesson || (int)$lesson['ScheduleStudentId'] !== (int)$_SESSION['student_id']) {
    http_response_code(403);
    echo "Je mag deze les niet annuleren.";
    exit;
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reason = htmlspecialchars($_POST['reason'] ?? '');
    if ($reason === '') {
        $message = 'Geef een reden op.';
    } else {
        $schedule->cancelLesson($scheduleId, $reason);
        header('Location: dashboard.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Les annuleren</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <h2 class="mb-3">Les annuleren</h2>
    <p>Les op: <strong><?= htmlspecialchars($lesson['ScheduleDateTime']) ?></strong></p>
    <?php if ($message): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <form method="post" class="card card-body">
        <div class="mb-3">
            <label class="form-label">Reden van annuleren</label>
            <textarea name="reason" class="form-control" rows="4" required></textarea>
        </div>
        <button type="submit" class="btn btn-warning">Les annuleren</button>
        <a href="dashboard.php" class="btn btn-link">Terug</a>
    </form>
</div>
</body>
</html>


