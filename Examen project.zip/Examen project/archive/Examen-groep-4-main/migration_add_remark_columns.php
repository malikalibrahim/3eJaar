<?php
require_once 'Code File/Database/db.php';

try {
    // Check if columns exist
    $stmt = $pdo->query("DESCRIBE schedule");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);

    $alterQueries = [];

    if (!in_array('ScheduleStudentRemark', $columns)) {
        $alterQueries[] = "ALTER TABLE schedule ADD COLUMN ScheduleStudentRemark VARCHAR(255) DEFAULT NULL";
    }

    if (!in_array('ScheduleTeacherRemark', $columns)) {
        $alterQueries[] = "ALTER TABLE schedule ADD COLUMN ScheduleTeacherRemark VARCHAR(255) DEFAULT NULL";
    }

    if (!in_array('ScheduleStudentId', $columns)) {
        $alterQueries[] = "ALTER TABLE schedule ADD COLUMN ScheduleStudentId INT(11) DEFAULT NULL";
    }

    if (!in_array('ScheduleTeacherId', $columns)) {
        $alterQueries[] = "ALTER TABLE schedule ADD COLUMN ScheduleTeacherId INT(11) DEFAULT NULL";
    }

    if (!in_array('ScheduleSubject', $columns)) {
        $alterQueries[] = "ALTER TABLE schedule ADD COLUMN ScheduleSubject VARCHAR(255) DEFAULT NULL";
    }

    if (!in_array('ScheduleStatus', $columns)) {
        $alterQueries[] = "ALTER TABLE schedule ADD COLUMN ScheduleStatus VARCHAR(50) DEFAULT 'planned'";
    }

    if (!in_array('ScheduleCancelReason', $columns)) {
        $alterQueries[] = "ALTER TABLE schedule ADD COLUMN ScheduleCancelReason VARCHAR(255) DEFAULT NULL";
    }

    foreach ($alterQueries as $query) {
        $pdo->exec($query);
        echo "Executed: $query\n";
    }

    if (empty($alterQueries)) {
        echo "All columns already exist.\n";
    } else {
        echo "Migration completed successfully.\n";
    }

} catch (PDOException $e) {
    echo "Migration failed: " . $e->getMessage() . "\n";
}
?>
