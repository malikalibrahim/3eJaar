<?php
// Include the database configuration
require_once 'config.php';

try {
    // Check students
    $stmt = $pdo->query("SELECT * FROM students");
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "Students:\n";
    foreach ($students as $student) {
        echo "- ID: {$student['idStudents']}, Name: {$student['StudentsName']}, Email: {$student['StudentsEmail']}\n";
    }

    // Check teachers
    $stmt = $pdo->query("SELECT * FROM teachers");
    $teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "\nTeachers:\n";
    foreach ($teachers as $teacher) {
        echo "- ID: {$teacher['idTeachers']}, Name: {$teacher['TeachersName']}, Email: {$teacher['TeachersEmail']}\n";
    }

    // Check admin
    $stmt = $pdo->query("SELECT * FROM admin");
    $admins = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "\nAdmins:\n";
    foreach ($admins as $admin) {
        echo "- ID: {$admin['idAdmin']}, Name: {$admin['AdminName']}\n";
    }

    // Check lessons
    $stmt = $pdo->query("SELECT * FROM lessons");
    $lessons = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "\nLessons:\n";
    foreach ($lessons as $lesson) {
        echo "- Remark: {$lesson['remark']}, Subject: {$lesson['Subject']}, Price: {$lesson['Price']}\n";
    }

    // Check announcements
    $stmt = $pdo->query("SELECT * FROM announcements");
    $announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "\nAnnouncements:\n";
    foreach ($announcements as $announcement) {
        echo "- Message: {$announcement['message']}, Target: {$announcement['TargetGroup']}\n";
    }

    // Check schedule
    $stmt = $pdo->query("SELECT * FROM schedule");
    $schedules = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "\nSchedule:\n";
    foreach ($schedules as $schedule) {
        echo "- DateTime: {$schedule['ScheduleDateTime']}, Car: {$schedule['ScheduleCar']}, StudentID: {$schedule['ScheduleStudentId']}, TeacherID: {$schedule['ScheduleTeacherId']}, Subject: {$schedule['ScheduleSubject']}, Status: {$schedule['ScheduleStatus']}\n";
    }

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
