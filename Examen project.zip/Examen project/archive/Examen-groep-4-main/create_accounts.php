<?php
// Include the database configuration
require_once 'config.php';

// Function to hash password for student (uses PASSWORD_DEFAULT)
function hashStudentPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

// Function to hash password for teacher and admin (uses PASSWORD_BCRYPT)
function hashTeacherAdminPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

try {
    // Student account
    $studentEmail = 'student_test_1764807589@example.com';
    $studentPassword = 'StudentPass123';
    $studentName = 'Test Student';
    $studentAge = 20;
    $studentAddress = 'Test Address';
    $studentPhone = 123456789;
    $studentStripCard = 0;

    $studentSql = "INSERT INTO students (StudentsName, StudentsAge, StudentsAddress, StudentsPhoneNumber, StudentsEmail, StudentsPsw, StudentsStripCard) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($studentSql);
    $stmt->execute([$studentName, $studentAge, $studentAddress, $studentPhone, $studentEmail, hashStudentPassword($studentPassword), $studentStripCard]);
    $studentId = $pdo->lastInsertId();
    echo "Student account created successfully.\n";

    // Teacher account
    $teacherEmail = 'teacher_test_1764807744@example.com';
    $teacherPassword = 'TeacherPass123';
    $teacherName = 'Test Teacher';
    $teacherPhone = 123456789;
    $teacherAvailability = 1;

    $teacherSql = "INSERT INTO teachers (TeachersName, TeachersEmail, TeachersPhoneNumber, TeachersPsw, Avaiblilty) VALUES (?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($teacherSql);
    $stmt->execute([$teacherName, $teacherEmail, $teacherPhone, hashTeacherAdminPassword($teacherPassword), $teacherAvailability]);
    $teacherId = $pdo->lastInsertId();
    echo "Teacher account created successfully.\n";

    // Admin account
    $adminName = 'TestAdmin_1764807744';
    $adminPassword = 'AdminPass123';

    $adminSql = "INSERT INTO admin (AdminName, AdminPsw) VALUES (?, ?)";
    $stmt = $pdo->prepare($adminSql);
    $stmt->execute([$adminName, hashTeacherAdminPassword($adminPassword)]);
    $adminId = $pdo->lastInsertId();
    echo "Admin account created successfully.\n";

    // Add sample lessons with remarks
    $lessonsData = [
        ['remark' => 'First lesson completed successfully', 'Subject' => 'Driving Basics', 'Price' => 50],
        ['remark' => 'Student needs more practice on turns', 'Subject' => 'City Driving', 'Price' => 60],
        ['remark' => 'Excellent progress on highway driving', 'Subject' => 'Highway Skills', 'Price' => 70]
    ];

    foreach ($lessonsData as $lesson) {
        $lessonSql = "INSERT INTO lessons (remark, Subject, Price) VALUES (?, ?, ?)";
        $stmt = $pdo->prepare($lessonSql);
        $stmt->execute([$lesson['remark'], $lesson['Subject'], $lesson['Price']]);
    }
    echo "Sample lessons with remarks added successfully.\n";

    // Check if announcements table exists, if not, create it
    $checkTableSql = "SHOW TABLES LIKE 'announcements'";
    $stmt = $pdo->prepare($checkTableSql);
    $stmt->execute();
    if ($stmt->rowCount() == 0) {
        $createTableSql = "CREATE TABLE announcements (
            id INT AUTO_INCREMENT PRIMARY KEY,
            message TEXT NOT NULL,
            TargetGroup VARCHAR(255) NOT NULL,
            CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        $pdo->exec($createTableSql);
        echo "Announcements table created.\n";
    }

    // Add sample announcements
    $announcementsData = [
        ['title' => 'Welcome', 'message' => 'Welcome to DriveSmart! Check your schedule for upcoming lessons.', 'targetGroup' => 'student'],
        ['title' => 'Safety Guidelines', 'message' => 'New safety guidelines available. Please review before next lesson.', 'targetGroup' => 'teacher'],
        ['title' => 'Maintenance', 'message' => 'System maintenance scheduled for tonight. No access from 10 PM to 12 AM.', 'targetGroup' => 'all']
    ];

    foreach ($announcementsData as $announcement) {
        $announcementSql = "INSERT INTO announcements (Title, Message, TargetGroup) VALUES (?, ?, ?)";
        $stmt = $pdo->prepare($announcementSql);
        $stmt->execute([$announcement['title'], $announcement['message'], $announcement['targetGroup']]);
    }
    echo "Sample announcements added successfully.\n";

    // Add sample schedule
    $scheduleData = [
        ['dateTime' => '2025-12-05 10:00:00', 'car' => 'BMW', 'pickLoc' => 'School Parking', 'studentId' => $studentId, 'teacherId' => $teacherId, 'subject' => 'Driving Basics', 'status' => 'planned'],
        ['dateTime' => '2025-12-06 14:00:00', 'car' => 'Volkswagen', 'pickLoc' => 'Home', 'studentId' => $studentId, 'teacherId' => $teacherId, 'subject' => 'City Driving', 'status' => 'planned'],
        ['dateTime' => '2025-12-07 09:00:00', 'car' => 'BMW', 'pickLoc' => 'School Parking', 'studentId' => $studentId, 'teacherId' => $teacherId, 'subject' => 'Highway Skills', 'status' => 'planned']
    ];

    foreach ($scheduleData as $schedule) {
        $scheduleSql = "INSERT INTO schedule (ScheduleDateTime, ScheduleCar, SchedulePickLoc, ScheduleStudentId, ScheduleTeacherId, ScheduleSubject, ScheduleStatus) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($scheduleSql);
        $stmt->execute([$schedule['dateTime'], $schedule['car'], $schedule['pickLoc'], $schedule['studentId'], $schedule['teacherId'], $schedule['subject'], $schedule['status']]);
    }

    // Add schedule for existing student (ID 1) and teacher (ID 1)
    $existingScheduleData = [
        ['dateTime' => '2025-12-08 10:00:00', 'car' => 'BMW', 'pickLoc' => 'School Parking', 'studentId' => 1, 'teacherId' => 1, 'subject' => 'Driving Basics', 'status' => 'planned'],
        ['dateTime' => '2025-12-09 14:00:00', 'car' => 'Volkswagen', 'pickLoc' => 'Home', 'studentId' => 1, 'teacherId' => 1, 'subject' => 'City Driving', 'status' => 'planned'],
        ['dateTime' => '2025-12-10 09:00:00', 'car' => 'BMW', 'pickLoc' => 'School Parking', 'studentId' => 1, 'teacherId' => 1, 'subject' => 'Highway Skills', 'status' => 'planned']
    ];

    foreach ($existingScheduleData as $schedule) {
        $scheduleSql = "INSERT INTO schedule (ScheduleDateTime, ScheduleCar, SchedulePickLoc, ScheduleStudentId, ScheduleTeacherId, ScheduleSubject, ScheduleStatus) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($scheduleSql);
        $stmt->execute([$schedule['dateTime'], $schedule['car'], $schedule['pickLoc'], $schedule['studentId'], $schedule['teacherId'], $schedule['subject'], $schedule['status']]);
    }
    echo "Sample schedule added successfully.\n";

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
