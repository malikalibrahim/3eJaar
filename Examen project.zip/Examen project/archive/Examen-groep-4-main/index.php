
<?php
// Bootstrap: zoek omhoog naar project root config.php en include indien aanwezig
$__config_path = null;
$__dir = __DIR__;
for ($__i = 0; $__i < 6; $__i++) {
    if (file_exists($__dir . '/config.php')) { $__config_path = $__dir . '/config.php'; break; }
    $__parent = dirname($__dir);
    if ($__parent === $__dir) break;
    $__dir = $__parent;
}
if ($__config_path) { require_once $__config_path; }

session_start();
$userName = $_SESSION['user_name'] ?? null;
$role = $_SESSION['role'] ?? null;
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DriveSmart - Startpagina</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            max-width: 600px;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            padding: 2rem;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            background: rgba(255, 255, 255, 0.95);
        }
        .card-body {
            padding: 1.5rem;
        }
        .btn {
            border-radius: 25px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        .list-group-item {
            border-radius: 10px;
            margin-bottom: 0.5rem;
            transition: all 0.3s ease;
        }
        .list-group-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
            font-weight: 700;
            text-align: center;
            margin-bottom: 2rem;
        }
        h3 {
            color: #333;
            font-weight: 600;
        }
        .text-muted {
            color: #6c757d !important;
        }
        ul li {
            margin-bottom: 0.5rem;
        }
    </style>
</head>
<body>
<div class="container py-5">
    <h1 class="mb-4">DriveSmart</h1>

    <?php if ($userName): ?>
        <div class="card card-body mb-4">
            <h3>Welkom, <?= htmlspecialchars($userName, ENT_QUOTES, 'UTF-8') ?></h3>
            <p>Je bent ingelogd als: <strong><?= htmlspecialchars($role) ?></strong></p>
            <?php if ($role === 'admin'): ?>
                <a class="btn btn-primary" href="Code File/Admin/HomepageAdmin.php">Naar Admin dashboard</a>
            <?php elseif ($role === 'instructeur' || $role === 'teacher'): ?>
                <a class="btn btn-primary" href="Code File/Instructor/dashboard.php">Naar Instructeur dashboard</a>
            <?php elseif ($role === 'leerling' || $role === 'student'): ?>
                <a class="btn btn-primary" href="Code File/Leerling/dashboard.php">Naar Leerling dashboard</a>
            <?php endif; ?>

            <form action="Code File/Database/logout.php" method="POST" style="display:inline; margin-left:10px;">
                <button type="submit" class="btn btn-secondary">Uitloggen</button>
            </form>
        </div>
    <?php else: ?>
        <div class="list-group mb-4">
            <a class="list-group-item list-group-item-action" href="Code File/Admin/login.php">🔐 Admin inloggen</a>
            <a class="list-group-item list-group-item-action" href="Code File/Instructor/login.php">👨‍🏫 Instructeur inloggen</a>
            <a class="list-group-item list-group-item-action" href="Code File/Leerling/login.php">👨‍🎓 Leerling inloggen</a>
        </div>

        <p><strong>Test Credentials:</strong></p>
        <ul class="list-unstyled">
            <li>👨‍🎓 Student: student_test_1764807589@example.com / StudentPass123</li>
            <li>👨‍🏫 Teacher: teacher_test_1764807744@example.com / TeacherPass123</li>
            <li>🔐 Admin: TestAdmin_1764807744 / AdminPass123</li>
        </ul>
    <?php endif; ?>

    <hr>
    <p class="text-muted">Als iets niet werkt, controleer dan je webserver root en zorg dat includes-relatieve paden correct zijn.</p>
</div>
</body>
</html>