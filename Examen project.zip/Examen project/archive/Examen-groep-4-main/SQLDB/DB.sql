-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema Drivesmart
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema Drivesmart
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `Drivesmart` DEFAULT CHARACTER SET utf8 ;
USE `Drivesmart` ;

-- -----------------------------------------------------
-- Table `Drivesmart`.`StripCard`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Drivesmart`.`StripCard` (
  `idStripCard` INT NOT NULL AUTO_INCREMENT,
  `StripCardAmount` INT NOT NULL,
  `StripCardHolder` VARCHAR(255) NOT NULL COMMENT 'FK',
  PRIMARY KEY (`idStripCard`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Drivesmart`.`Students`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Drivesmart`.`Students` (
  `idStudents` INT NOT NULL AUTO_INCREMENT,
  `StudentsName` VARCHAR(255) NOT NULL,
  `StudentsAge` INT NOT NULL,
  `StudentsAddress` VARCHAR(255) NOT NULL,
  `StudentsPhoneNumber` INT NOT NULL,
  `StudentsEmail` VARCHAR(255) NOT NULL,
  `StudentsPsw` VARCHAR(255) NOT NULL,
  `StudentsStripCard` INT NOT NULL,
  PRIMARY KEY (`idStudents`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Drivesmart`.`Schedule`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Drivesmart`.`Schedule` (
  `idSchedule` INT NOT NULL AUTO_INCREMENT,
  `ScheduleDateTime` DATETIME NOT NULL,
  `ScheduleCar` VARCHAR(255) NOT NULL,
  `SchedulePickLoc` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`idSchedule`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Drivesmart`.`Teachers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Drivesmart`.`Teachers` (
  `idTeachers` INT NOT NULL AUTO_INCREMENT,
  `TeachersName` VARCHAR(255) NOT NULL,
  `TeachersEmail` VARCHAR(255) NOT NULL,
  `TeachersPhoneNumber` INT NOT NULL,
  `TeachersPsw` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`idTeachers`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Drivesmart`.`Admin`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Drivesmart`.`Admin` (
  `idAdmin` INT NOT NULL AUTO_INCREMENT,
  `AdminName` VARCHAR(255) NOT NULL,
  `AdminPsw` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`idAdmin`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Drivesmart`.`Cars`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Drivesmart`.`Cars` (
  `idCars` INT NOT NULL AUTO_INCREMENT,
  `CarsType` VARCHAR(255) NOT NULL,
  `CarsWear` VARCHAR(255) NOT NULL,
  `CarsUsed` TINYINT NOT NULL,
  `Carscol` VARCHAR(45) NULL,
  PRIMARY KEY (`idCars`))
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
