<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/db.php";

layout_header("Mijn profiel");

$auth = new Auth();
$user = $auth->user();
$db   = new DB();

$row = $db->run("SELECT * FROM gebruiker WHERE id = :id", ['id' => $user['id']])->fetch();
$msg = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $voornaam   = trim($_POST['voornaam'] ?? '');
    $achternaam = trim($_POST['achternaam'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $telefoon   = trim($_POST['telefoon'] ?? '');
    $adres      = trim($_POST['adres'] ?? '');
    $postcode   = trim($_POST['postcode'] ?? '');
    $plaats     = trim($_POST['plaats'] ?? '');

    if ($voornaam && $achternaam && $email) {
        $db->run(
            "UPDATE gebruiker 
             SET voornaam = :vn, achternaam = :an, email = :email, telefoon = :tel, adres = :adr, postcode = :pc, plaats = :pl
             WHERE id = :id",
            [
                'vn'  => $voornaam,
                'an'  => $achternaam,
                'email' => $email,
                'tel' => $telefoon,
                'adr' => $adres,
                'pc'  => $postcode,
                'pl'  => $plaats,
                'id'  => $user['id'],
            ]
        );
        $msg = "Profiel bijgewerkt.";
        $row = $db->run("SELECT * FROM gebruiker WHERE id = :id", ['id' => $user['id']])->fetch();
    } else {
        $msg = "Voornaam, achternaam en e‑mail zijn verplicht.";
    }
}
?>

<div class="row justify-content-center">
    <div class="col-lg-6">
        <div class="card shadow-sm">
            <div class="card-body">
                <h1 class="h5 mb-3">Mijn profiel</h1>
                <p class="small text-muted">Pas hier je persoonlijke gegevens aan.</p>

                <?php if ($msg): ?>
                    <div class="alert alert-info py-2 small"><?php echo htmlspecialchars($msg); ?></div>
                <?php endif; ?>

                <?php if ($row): ?>
                    <form method="POST" class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label small">Voornaam</label>
                            <input type="text" name="voornaam" class="form-control" value="<?php echo htmlspecialchars($row['voornaam']); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small">Achternaam</label>
                            <input type="text" name="achternaam" class="form-control" value="<?php echo htmlspecialchars($row['achternaam']); ?>" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label small">E‑mail</label>
                            <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($row['email']); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small">Telefoon</label>
                            <input type="text" name="telefoon" class="form-control" value="<?php echo htmlspecialchars($row['telefoon']); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small">Postcode</label>
                            <input type="text" name="postcode" class="form-control" value="<?php echo htmlspecialchars($row['postcode']); ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label small">Adres</label>
                            <input type="text" name="adres" class="form-control" value="<?php echo htmlspecialchars($row['adres']); ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label small">Plaats</label>
                            <input type="text" name="plaats" class="form-control" value="<?php echo htmlspecialchars($row['plaats']); ?>">
                        </div>
                        <div class="col-12 text-end">
                            <button class="btn btn-primary btn-sm">Opslaan</button>
                        </div>
                    </form>
                <?php else: ?>
                    <p class="small text-muted mb-0">Gebruiker niet gevonden.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php layout_footer(); ?>


