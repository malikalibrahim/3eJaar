<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/db.php";

layout_header("Leerlingen overzicht");

$db = new DB();
$leerlingen = $db->run(
    "SELECT * FROM gebruiker WHERE rol = 'leerling' AND actief = 1 ORDER BY achternaam, voornaam"
)->fetchAll();
?>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h5 mb-0">Leerlingen</h1>
            <a href="leerling-add.php" class="btn btn-primary btn-sm">Nieuwe leerling</a>
        </div>
        <table class="table table-sm align-middle">
            <thead>
            <tr>
                <th>Naam</th>
                <th>E‑mail</th>
                <th>Telefoon</th>
                <th>Plaats</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($leerlingen as $l): ?>
                <tr>
                    <td><?php echo htmlspecialchars($l['voornaam'] . ' ' . $l['achternaam']); ?></td>
                    <td><?php echo htmlspecialchars($l['email']); ?></td>
                    <td><?php echo htmlspecialchars($l['telefoon']); ?></td>
                    <td><?php echo htmlspecialchars($l['plaats']); ?></td>
                    <td class="text-end">
                        <a href="leerling-edit.php?id=<?php echo (int)$l['id']; ?>" class="btn btn-outline-secondary btn-sm">Bewerken</a>
                        <a href="leerling-delete.php?id=<?php echo (int)$l['id']; ?>" class="btn btn-outline-danger btn-sm">Verwijderen</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($leerlingen)): ?>
                <tr><td colspan="5" class="small text-muted">Nog geen leerlingen.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php layout_footer(); ?>


