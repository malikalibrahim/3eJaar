<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Les.php";

layout_header("Les annuleren");

$auth    = new Auth();
$user    = $auth->user();
$lesRepo = new Les();

$id   = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$les  = $id > 0 ? $lesRepo->findById($id) : null;
$msg  = null;
$err  = null;

if (!$les || $les['leerling_id'] != $user['id']) {
    $err = "Les niet gevonden of niet van jou.";
} elseif ($les['status'] !== 'gepland') {
    $err = "Alleen geplande lessen kunnen worden geannuleerd.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$err) {
    $reden = trim($_POST['reden'] ?? '');
    if ($reden === '') {
        $err = "Geef een reden op.";
    } else {
        try {
            $lesRepo->annuleerDoorLeerling($id, $reden);
            $msg = "Les is geannuleerd.";
        } catch (Throwable $e) {
            $err = "Kon les niet annuleren: " . $e->getMessage();
        }
    }
}
?>

<div class="card shadow-sm">
    <div class="card-body">
        <h1 class="h5 mb-3">Les annuleren</h1>

        <?php if ($err): ?>
            <div class="alert alert-danger py-2 small"><?php echo htmlspecialchars($err); ?></div>
        <?php endif; ?>
        <?php if ($msg): ?>
            <div class="alert alert-success py-2 small"><?php echo htmlspecialchars($msg); ?></div>
            <a href="rooster.php" class="btn btn-primary btn-sm mt-2">Terug naar mijn rooster</a>
        <?php elseif (!$err && $les): ?>
            <p class="small text-muted">
                Je staat op het punt de les van <strong><?php echo htmlspecialchars($les['datum']); ?></strong>
                om <strong><?php echo htmlspecialchars($les['starttijd']); ?></strong> te annuleren.
            </p>
            <form method="POST" class="row g-3">
                <div class="col-12">
                    <label class="form-label small">Reden van annulering</label>
                    <textarea name="reden" rows="3" class="form-control" required></textarea>
                </div>
                <div class="col-12 d-flex justify-content-between">
                    <a href="rooster.php" class="btn btn-outline-secondary btn-sm">Annuleren terugtrekken</a>
                    <button class="btn btn-danger btn-sm">Les annuleren</button>
                </div>
            </form>
        <?php endif; ?>
    </div>
</div>

<?php layout_footer(); ?>


