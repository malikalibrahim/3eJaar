<?php
require_once __DIR__ . "/../user/layout.php";

layout_header("Dashboard leerling");
?>

<div class="row">
    <div class="col-lg-8">
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h2 class="h5 mb-3">Welkom, leerling</h2>
                <p class="small text-muted">
                    Hier zie je straks je eerstvolgende lessen, opmerkingen van je instructeur en eventuele
                    mededelingen voor leerlingen.
                </p>
            </div>
        </div>
    </div>
</div>

<?php layout_footer(); ?>


