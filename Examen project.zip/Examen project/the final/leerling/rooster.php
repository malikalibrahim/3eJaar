<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Les.php";

layout_header("Mijn lesrooster");

$auth    = new Auth();
$user    = $auth->user();
$lesRepo = new Les();

$lessen = $lesRepo->roosterVoorLeerling((int)$user['id']);
?>

<div class="card shadow-sm">
    <div class="card-body">
        <h1 class="h5 mb-3">Mijn lessen</h1>
        <table class="table table-sm align-middle">
            <thead>
            <tr>
                <th>Datum</th>
                <th>Tijd</th>
                <th>Ophaallocatie</th>
                <th>Onderwerp</th>
                <th>Status</th>
                <th>Opmerking instructeur</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($lessen as $l): ?>
                <tr>
                    <td><?php echo htmlspecialchars($l['datum']); ?></td>
                    <td><?php echo htmlspecialchars($l['starttijd'] . ' - ' . $l['eindtijd']); ?></td>
                    <td><?php echo htmlspecialchars($l['ophaallocatie']); ?></td>
                    <td><?php echo htmlspecialchars($l['onderwerp']); ?></td>
                    <td><?php echo htmlspecialchars($l['status']); ?></td>
                    <td><?php echo htmlspecialchars($l['opmerking_instructeur']); ?></td>
                    <td class="text-end">
                        <?php if ($l['status'] === 'gepland'): ?>
                            <a href="les-annuleer.php?id=<?php echo (int)$l['id']; ?>" class="btn btn-outline-danger btn-sm">Annuleren</a>
                        <?php endif; ?>
                        <a href="les-opmerking.php?id=<?php echo (int)$l['id']; ?>" class="btn btn-outline-secondary btn-sm">Mijn opmerking</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($lessen)): ?>
                <tr><td colspan="7" class="small text-muted">Je hebt nog geen lessen gepland.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php layout_footer(); ?>


