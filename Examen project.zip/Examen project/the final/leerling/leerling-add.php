<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Gebruiker.php";

layout_header("Leerling toevoegen");

$gebruikerRepo = new Gebruiker();
$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $voornaam   = trim($_POST['voornaam'] ?? '');
    $achternaam = trim($_POST['achternaam'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $wachtwoord = $_POST['wachtwoord'] ?? '';
    $telefoon   = trim($_POST['telefoon'] ?? '');
    $adres      = trim($_POST['adres'] ?? '');
    $postcode   = trim($_POST['postcode'] ?? '');
    $plaats     = trim($_POST['plaats'] ?? '');

    if (!$voornaam || !$achternaam || !$email || !$wachtwoord) {
        $error = "Voornaam, achternaam, e‑mail en wachtwoord zijn verplicht.";
    } else {
        try {
            $gebruikerRepo->registreerLeerling($voornaam, $achternaam, $email, $wachtwoord, $telefoon, $adres, $postcode, $plaats);
            $success = "Leerling is aangemaakt.";
        } catch (Throwable $e) {
            $error = "Kon leerling niet aanmaken: " . $e->getMessage();
        }
    }
}
?>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h5 mb-0">Nieuwe leerling</h1>
            <a href="leerling-view.php" class="btn btn-outline-secondary btn-sm">Terug naar overzicht</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger py-2 small"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success py-2 small"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <form method="POST" class="row g-3">
            <div class="col-md-6">
                <label class="form-label small">Voornaam</label>
                <input type="text" name="voornaam" class="form-control" required>
            </div>
            <div class="col-md-6">
                <label class="form-label small">Achternaam</label>
                <input type="text" name="achternaam" class="form-control" required>
            </div>
            <div class="col-md-6">
                <label class="form-label small">E‑mail</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="col-md-6">
                <label class="form-label small">Wachtwoord</label>
                <input type="password" name="wachtwoord" class="form-control" required>
            </div>
            <div class="col-md-6">
                <label class="form-label small">Telefoon</label>
                <input type="text" name="telefoon" class="form-control">
            </div>
            <div class="col-md-6">
                <label class="form-label small">Postcode</label>
                <input type="text" name="postcode" class="form-control">
            </div>
            <div class="col-12">
                <label class="form-label small">Adres</label>
                <input type="text" name="adres" class="form-control">
            </div>
            <div class="col-12">
                <label class="form-label small">Plaats</label>
                <input type="text" name="plaats" class="form-control">
            </div>
            <div class="col-12 text-end">
                <button class="btn btn-primary btn-sm">Opslaan</button>
            </div>
        </form>
    </div>
</div>

<?php layout_footer(); ?>


