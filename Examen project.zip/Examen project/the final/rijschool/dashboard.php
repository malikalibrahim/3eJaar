<?php
require_once __DIR__ . "/../user/layout.php";

layout_header("Dashboard rijschoolhouder");
?>

<div class="row">
    <div class="col-lg-8">
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h2 class="h5 mb-3">Overzicht rijschool</h2>
                <p class="small text-muted">
                    Vanaf dit dashboard beheer je straks wagenpark, mededelingen, instructeurs en lespakketten.
                </p>
            </div>
        </div>
    </div>
</div>

<?php layout_footer(); ?>


