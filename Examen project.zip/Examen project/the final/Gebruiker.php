<?php

require_once __DIR__ . "/db.php";

class Gebruiker
{
    private DB $db;

    public function __construct()
    {
        $this->db = new DB();
    }

    public function registreerLeerling(
        string $voornaam,
        string $achternaam,
        string $email,
        string $wachtwoord,
        string $telefoon,
        string $adres,
        string $postcode,
        string $plaats
    ): void {
        $hash = password_hash($wachtwoord, PASSWORD_DEFAULT);

        $sql = "INSERT INTO gebruiker
                (rol, voornaam, achternaam, email, wachtwoord, telefoon, adres, postcode, plaats, actief)
                VALUES ('leerling', :vn, :an, :email, :wacht, :tel, :adr, :pc, :plaats, 1)";

        $this->db->run($sql, [
            'vn'    => $voornaam,
            'an'    => $achternaam,
            'email' => $email,
            'wacht' => $hash,
            'tel'   => $telefoon,
            'adr'   => $adres,
            'pc'    => $postcode,
            'plaats'=> $plaats,
        ]);
    }

    public function maakInstructeurAan(
        string $voornaam,
        string $achternaam,
        string $email,
        string $wachtwoord,
        string $telefoon
    ): void {
        $hash = password_hash($wachtwoord, PASSWORD_DEFAULT);

        $sql = "INSERT INTO gebruiker
                (rol, voornaam, achternaam, email, wachtwoord, telefoon, actief)
                VALUES ('instructeur', :vn, :an, :email, :wacht, :tel, 1)";

        $this->db->run($sql, [
            'vn'    => $voornaam,
            'an'    => $achternaam,
            'email' => $email,
            'wacht' => $hash,
            'tel'   => $telefoon,
        ]);
    }
}


