<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Les.php";
require_once __DIR__ . "/../includes/db.php";

layout_header("Lessen overzicht");

$lesRepo = new Les();
$db      = new DB();

$lessen = $db->run(
    "SELECT l.*, 
            gl.voornaam AS leerling_voornaam, gl.achternaam AS leerling_achternaam,
            gi.voornaam AS instructeur_voornaam, gi.achternaam AS instructeur_achternaam
     FROM les l
     LEFT JOIN gebruiker gl ON gl.id = l.leerling_id
     LEFT JOIN gebruiker gi ON gi.id = l.instructeur_id
     ORDER BY l.datum DESC, l.starttijd DESC"
)->fetchAll();
?>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h5 mb-0">Alle lessen</h1>
            <a href="les-add.php" class="btn btn-primary btn-sm">Nieuwe les</a>
        </div>

        <table class="table table-sm align-middle">
            <thead>
            <tr>
                <th>Datum</th>
                <th>Tijd</th>
                <th>Leerling</th>
                <th>Instructeur</th>
                <th>Ophaallocatie</th>
                <th>Onderwerp</th>
                <th>Status</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($lessen as $l): ?>
                <tr>
                    <td><?php echo htmlspecialchars($l['datum']); ?></td>
                    <td><?php echo htmlspecialchars($l['starttijd'] . ' - ' . $l['eindtijd']); ?></td>
                    <td><?php echo htmlspecialchars(trim(($l['leerling_voornaam'] ?? '') . ' ' . ($l['leerling_achternaam'] ?? ''))); ?></td>
                    <td><?php echo htmlspecialchars(trim(($l['instructeur_voornaam'] ?? '') . ' ' . ($l['instructeur_achternaam'] ?? ''))); ?></td>
                    <td><?php echo htmlspecialchars($l['ophaallocatie']); ?></td>
                    <td><?php echo htmlspecialchars($l['onderwerp']); ?></td>
                    <td><?php echo htmlspecialchars($l['status']); ?></td>
                    <td class="text-end">
                        <a href="les-edit.php?id=<?php echo (int)$l['id']; ?>" class="btn btn-outline-secondary btn-sm">Bewerken</a>
                        <a href="les-delete.php?id=<?php echo (int)$l['id']; ?>" class="btn btn-outline-danger btn-sm">Verwijderen</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($lessen)): ?>
                <tr><td colspan="8" class="small text-muted">Nog geen lessen gepland.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php layout_footer(); ?>


