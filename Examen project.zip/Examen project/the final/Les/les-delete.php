<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Les.php";

layout_header("Les verwijderen");

$lesRepo = new Les();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    $lesRepo->delete($id);
}

header("Location: les-view.php");
exit;


