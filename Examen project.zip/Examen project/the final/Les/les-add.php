<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Les.php";
require_once __DIR__ . "/../includes/db.php";

layout_header("Les toevoegen");

$lesRepo = new Les();
$db      = new DB();
$error   = null;
$success = null;

$leerlingen = $db->run("SELECT id, voornaam, achternaam FROM gebruiker WHERE rol = 'leerling' AND actief = 1 ORDER BY achternaam, voornaam")->fetchAll();
$instructeurs = $db->run("SELECT id, voornaam, achternaam FROM gebruiker WHERE rol = 'instructeur' AND actief = 1 ORDER BY achternaam, voornaam")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $leerlingId    = (int)($_POST['leerling_id'] ?? 0);
    $instructeurId = (int)($_POST['instructeur_id'] ?? 0);
    $datum         = $_POST['datum'] ?? '';
    $start         = $_POST['starttijd'] ?? '';
    $eind          = $_POST['eindtijd'] ?? '';
    $loc           = trim($_POST['ophaallocatie'] ?? '');
    $onderwerp     = trim($_POST['onderwerp'] ?? '');

    if (!$leerlingId || !$instructeurId || !$datum || !$start || !$eind || !$loc) {
        $error = "Vul alle verplichte velden in.";
    } else {
        try {
            $lesRepo->planLesDoorInstructeur($leerlingId, $instructeurId, $datum, $start, $eind, $loc, $onderwerp);
            $success = "Les gepland.";
        } catch (Throwable $e) {
            $error = "Kon les niet plannen: " . $e->getMessage();
        }
    }
}
?>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h5 mb-0">Nieuwe les</h1>
            <a href="les-view.php" class="btn btn-outline-secondary btn-sm">Terug naar overzicht</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger py-2 small"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success py-2 small"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <form method="POST" class="row g-3">
            <div class="col-md-6">
                <label class="form-label small">Leerling</label>
                <select name="leerling_id" class="form-select" required>
                    <option value="">Kies een leerling</option>
                    <?php foreach ($leerlingen as $l): ?>
                        <option value="<?php echo (int)$l['id']; ?>">
                            <?php echo htmlspecialchars($l['achternaam'] . ', ' . $l['voornaam']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label small">Instructeur</label>
                <select name="instructeur_id" class="form-select" required>
                    <option value="">Kies een instructeur</option>
                    <?php foreach ($instructeurs as $i): ?>
                        <option value="<?php echo (int)$i['id']; ?>">
                            <?php echo htmlspecialchars($i['achternaam'] . ', ' . $i['voornaam']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label small">Datum</label>
                <input type="date" name="datum" class="form-control" required>
            </div>
            <div class="col-md-4">
                <label class="form-label small">Starttijd</label>
                <input type="time" name="starttijd" class="form-control" required>
            </div>
            <div class="col-md-4">
                <label class="form-label small">Eindtijd</label>
                <input type="time" name="eindtijd" class="form-control" required>
            </div>
            <div class="col-12">
                <label class="form-label small">Ophaallocatie</label>
                <input type="text" name="ophaallocatie" class="form-control" required>
            </div>
            <div class="col-12">
                <label class="form-label small">Te behandelen onderdeel</label>
                <input type="text" name="onderwerp" class="form-control">
            </div>
            <div class="col-12 text-end">
                <button class="btn btn-primary btn-sm">Opslaan</button>
            </div>
        </form>
    </div>
</div>

<?php layout_footer(); ?>


