<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Auto.php";

layout_header("Auto onderhoud");

$autoRepo = new AutoRepo();
$id     = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$status = isset($_GET['status']) ? (int)$_GET['status'] : 0;

if ($id > 0) {
    $autoRepo->markeerOnderhoud($id, $status === 1);
}

header("Location: auto-view.php");
exit;


