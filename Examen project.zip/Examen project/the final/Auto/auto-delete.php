<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Auto.php";

layout_header("Auto verwijderen");

$autoRepo = new AutoRepo();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    $autoRepo->verwijder($id);
}

header("Location: auto-view.php");
exit;


