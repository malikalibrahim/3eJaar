<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Auto.php";

layout_header("Wagenpark");

$autoRepo = new AutoRepo();
$autos    = $autoRepo->alleAutos();
?>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h5 mb-0">Wagenpark</h1>
            <a href="auto-add.php" class="btn btn-primary btn-sm">Nieuwe auto</a>
        </div>
        <table class="table table-sm align-middle">
            <thead>
            <tr>
                <th>Kenteken</th>
                <th>Merk / type</th>
                <th>Bouwjaar</th>
                <th>Onderhoud</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($autos as $a): ?>
                <tr>
                    <td><?php echo htmlspecialchars($a['kenteken']); ?></td>
                    <td><?php echo htmlspecialchars($a['merk'] . ' ' . $a['type']); ?></td>
                    <td><?php echo htmlspecialchars($a['bouwjaar']); ?></td>
                    <td>
                        <?php if ($a['in_onderhoud']): ?>
                            <span class="badge text-bg-warning">In onderhoud</span>
                        <?php else: ?>
                            <span class="badge text-bg-success">Beschikbaar</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-end">
                        <a href="auto-maintenance.php?id=<?php echo (int)$a['id']; ?>&status=<?php echo $a['in_onderhoud'] ? 0 : 1; ?>" class="btn btn-outline-secondary btn-sm">
                            <?php echo $a['in_onderhoud'] ? 'Uit onderhoud' : 'In onderhoud'; ?>
                        </a>
                        <a href="auto-delete.php?id=<?php echo (int)$a['id']; ?>" class="btn btn-outline-danger btn-sm">Verwijderen</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($autos)): ?>
                <tr><td colspan="5" class="small text-muted">Nog geen auto’s toegevoegd.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php layout_footer(); ?>


