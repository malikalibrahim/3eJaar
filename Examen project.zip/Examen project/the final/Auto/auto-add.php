<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Auto.php";

layout_header("Auto toevoegen");

$autoRepo = new AutoRepo();
$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kenteken = trim($_POST['kenteken'] ?? '');
    $merk     = trim($_POST['merk'] ?? '');
    $type     = trim($_POST['type'] ?? '');
    $bouwjaar = trim($_POST['bouwjaar'] ?? '');

    if (!$kenteken || !$merk || !$type) {
        $error = "Kenteken, merk en type zijn verplicht.";
    } else {
        try {
            $autoRepo->nieuweAuto($kenteken, $merk, $type, $bouwjaar);
            $success = "Auto toegevoegd.";
        } catch (Throwable $e) {
            $error = "Kon auto niet toevoegen: " . $e->getMessage();
        }
    }
}
?>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h5 mb-0">Nieuwe auto</h1>
            <a href="auto-view.php" class="btn btn-outline-secondary btn-sm">Terug naar wagenpark</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger py-2 small"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success py-2 small"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <form method="POST" class="row g-3">
            <div class="col-md-4">
                <label class="form-label small">Kenteken</label>
                <input type="text" name="kenteken" class="form-control" required>
            </div>
            <div class="col-md-4">
                <label class="form-label small">Merk</label>
                <input type="text" name="merk" class="form-control" required>
            </div>
            <div class="col-md-4">
                <label class="form-label small">Type</label>
                <input type="text" name="type" class="form-control" required>
            </div>
            <div class="col-md-4">
                <label class="form-label small">Bouwjaar</label>
                <input type="text" name="bouwjaar" class="form-control">
            </div>
            <div class="col-12 text-end">
                <button class="btn btn-primary btn-sm">Opslaan</button>
            </div>
        </form>
    </div>
</div>

<?php layout_footer(); ?>


