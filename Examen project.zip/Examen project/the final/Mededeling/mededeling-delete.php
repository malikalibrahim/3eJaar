<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/db.php";

layout_header("Mededeling verwijderen");

$db = new DB();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    $db->run("DELETE FROM mededeling WHERE id = :id", ['id' => $id]);
}

header("Location: mededeling-view.php");
exit;


