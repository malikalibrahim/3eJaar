<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Mededeling.php";

layout_header("Mededeling toevoegen");

$medRepo = new Mededeling();
$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $doelgroep = $_POST['doelgroep'] ?? '';
    $titel     = trim($_POST['titel'] ?? '');
    $tekst     = trim($_POST['tekst'] ?? '');

    if (!$doelgroep || !$titel || !$tekst) {
        $error = "Alle velden zijn verplicht.";
    } else {
        try {
            $medRepo->maak($doelgroep, $titel, $tekst);
            $success = "Mededeling geplaatst.";
        } catch (Throwable $e) {
            $error = "Kon mededeling niet opslaan: " . $e->getMessage();
        }
    }
}
?>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h5 mb-0">Nieuwe mededeling</h1>
            <a href="mededeling-view.php" class="btn btn-outline-secondary btn-sm">Terug naar overzicht</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger py-2 small"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success py-2 small"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <form method="POST" class="row g-3">
            <div class="col-md-4">
                <label class="form-label small">Doelgroep</label>
                <select name="doelgroep" class="form-select" required>
                    <option value="">Kies een doelgroep</option>
                    <option value="leerling">Leerlingen</option>
                    <option value="instructeur">Instructeurs</option>
                    <option value="allen">Alle gebruikers</option>
                </select>
            </div>
            <div class="col-12">
                <label class="form-label small">Titel</label>
                <input type="text" name="titel" class="form-control" required>
            </div>
            <div class="col-12">
                <label class="form-label small">Tekst</label>
                <textarea name="tekst" rows="4" class="form-control" required></textarea>
            </div>
            <div class="col-12 text-end">
                <button class="btn btn-primary btn-sm">Publiceren</button>
            </div>
        </form>
    </div>
</div>

<?php layout_footer(); ?>


