<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Mededeling.php";

layout_header("Mededelingen");

$medRepo = new Mededeling();
$mededelingen = $medRepo->alles();
?>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h5 mb-0">Mededelingen</h1>
            <a href="mededeling-add.php" class="btn btn-primary btn-sm">Nieuwe mededeling</a>
        </div>
        <table class="table table-sm align-middle">
            <thead>
            <tr>
                <th>Datum</th>
                <th>Doelgroep</th>
                <th>Titel</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($mededelingen as $m): ?>
                <tr>
                    <td><?php echo htmlspecialchars($m['datum']); ?></td>
                    <td><?php echo htmlspecialchars($m['doelgroep']); ?></td>
                    <td><?php echo htmlspecialchars($m['titel']); ?></td>
                    <td class="text-end">
                        <a href="mededeling-delete.php?id=<?php echo (int)$m['id']; ?>" class="btn btn-outline-danger btn-sm">Verwijderen</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($mededelingen)): ?>
                <tr><td colspan="4" class="small text-muted">Nog geen mededelingen.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php layout_footer(); ?>


