<?php
require_once __DIR__ . "/../includes/Auth.php";

$auth = new Auth();
$user = $auth->user();

if (!$auth->check()) {
    header("Location: ../index.php");
    exit;
}

function layout_header(string $title): void {
    global $user;
    ?>
    <!DOCTYPE html>
    <html lang="nl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo htmlspecialchars($title); ?> - Rijschool</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container-fluid">
            <a class="navbar-brand fw-semibold" href="../index.php">Rijschool</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <?php if ($user['rol'] === 'leerling'): ?>
                        <li class="nav-item"><a class="nav-link" href="../leerling/dashboard.php">Dashboard</a></li>
                        <li class="nav-item"><a class="nav-link" href="../leerling/rooster.php">Lesrooster</a></li>
                        <li class="nav-item"><a class="nav-link" href="../leerling/profiel.php">Mijn profiel</a></li>
                    <?php elseif ($user['rol'] === 'instructeur'): ?>
                        <li class="nav-item"><a class="nav-link" href="../instructeur/dashboard.php">Dashboard</a></li>
                        <li class="nav-item"><a class="nav-link" href="../instructeur/dagrooster.php">Dagrooster</a></li>
                        <li class="nav-item"><a class="nav-link" href="../instructeur/weekrooster.php">Weekrooster</a></li>
                        <li class="nav-item"><a class="nav-link" href="../instructeur/wagenpark.php">Wagenpark</a></li>
                    <?php elseif ($user['rol'] === 'rijschoolhouder'): ?>
                        <li class="nav-item"><a class="nav-link" href="../rijschool/dashboard.php">Dashboard</a></li>
                        <li class="nav-item"><a class="nav-link" href="../rijschool/wagenpark.php">Wagenpark</a></li>
                        <li class="nav-item"><a class="nav-link" href="../rijschool/mededelingen.php">Mededelingen</a></li>
                        <li class="nav-item"><a class="nav-link" href="../rijschool/instructeurs.php">Instructeurs</a></li>
                        <li class="nav-item"><a class="nav-link" href="../rijschool/pakketten.php">Lespakketten</a></li>
                    <?php endif; ?>
                </ul>
                <span class="navbar-text me-3 small">
                    Ingelogd als <?php echo htmlspecialchars($user['naam']); ?> (<?php echo htmlspecialchars($user['rol']); ?>)
                </span>
                <a href="logout.php" class="btn btn-outline-light btn-sm">Uitloggen</a>
            </div>
        </div>
    </nav>
    <main class="container mb-5">
    <?php
}

function layout_footer(): void {
    ?>
    </main>
    </body>
    </html>
    <?php
}


