<?php

require_once __DIR__ . "/db.php";

class AutoRepo
{
    private DB $db;

    public function __construct()
    {
        $this->db = new DB();
    }

    public function alleAutos(): array
    {
        return $this->db->run("SELECT * FROM auto WHERE actief = 1")->fetchAll();
    }

    public function nieuweAuto(
        string $kenteken,
        string $merk,
        string $type,
        string $bouwjaar
    ): void {
        $sql = "INSERT INTO auto (kenteken, merk, type, bouwjaar, in_onderhoud, actief)
                VALUES (:k, :m, :t, :b, 0, 1)";
        $this->db->run($sql, [
            'k' => $kenteken,
            'm' => $merk,
            't' => $type,
            'b' => $bouwjaar,
        ]);
    }

    public function markeerOnderhoud(int $id, bool $onderhoud): void
    {
        $this->db->run(
            "UPDATE auto SET in_onderhoud = :o WHERE id = :id",
            ['o' => $onderhoud ? 1 : 0, 'id' => $id]
        );
    }

    public function verwijder(int $id): void
    {
        $this->db->run(
            "UPDATE auto SET actief = 0 WHERE id = :id",
            ['id' => $id]
        );
    }

    public function koppelAanInstructeur(
        int $autoId,
        int $instructeurId,
        string $startdatum,
        ?string $einddatum
    ): void {
        $sql = "INSERT INTO auto_toewijzing (auto_id, instructeur_id, startdatum, einddatum)
                VALUES (:aid, :iid, :start, :eind)";
        $this->db->run($sql, [
            'aid'   => $autoId,
            'iid'   => $instructeurId,
            'start' => $startdatum,
            'eind'  => $einddatum,
        ]);
    }

    public function autoVoorInstructeurVandaag(int $instructeurId, string $datum): ?array
    {
        $sql = "SELECT a.*
                FROM auto_toewijzing t
                JOIN auto a ON a.id = t.auto_id
                WHERE t.instructeur_id = :iid
                  AND :dat BETWEEN t.startdatum AND IFNULL(t.einddatum, :dat)";
        $row = $this->db->run($sql, ['iid' => $instructeurId, 'dat' => $datum])->fetch();
        return $row ?: null;
    }

    public function meldMankement(int $autoId, int $instructeurId, string $datum, string $beschrijving): void
    {
        $sql = "INSERT INTO auto_mankement (auto_id, instructeur_id, datum, beschrijving, status)
                VALUES (:aid, :iid, :dat, :bes, 'open')";
        $this->db->run($sql, [
            'aid' => $autoId,
            'iid' => $instructeurId,
            'dat' => $datum,
            'bes' => $beschrijving,
        ]);
    }

    public function registreerKilometerstand(int $autoId, int $instructeurId, string $datum, int $km): void
    {
        $sql = "INSERT INTO auto_kilometerstand (auto_id, instructeur_id, datum, km_einde_dag)
                VALUES (:aid, :iid, :dat, :km)";
        $this->db->run($sql, [
            'aid' => $autoId,
            'iid' => $instructeurId,
            'dat' => $datum,
            'km'  => $km,
        ]);
    }
}


