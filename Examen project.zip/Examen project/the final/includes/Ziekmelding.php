<?php

require_once __DIR__ . "/db.php";

class Ziekmelding
{
    private DB $db;

    public function __construct()
    {
        $this->db = new DB();
    }

    public function meldZiek(int $instructeurId, string $datum, string $tijd, string $reden): void
    {
        $sql = "INSERT INTO ziekmelding (instructeur_id, datum, tijd, reden)
                VALUES (:iid, :dat, :tijd, :reden)";
        $this->db->run($sql, [
            'iid'   => $instructeurId,
            'dat'   => $datum,
            'tijd'  => $tijd,
            'reden' => $reden,
        ]);
    }
}


