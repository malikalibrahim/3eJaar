<?php

require_once __DIR__ . "/db.php";

class Mededeling
{
    private DB $db;

    public function __construct()
    {
        $this->db = new DB();
    }

    public function maak(string $doelgroep, string $titel, string $tekst): void
    {
        $sql = "INSERT INTO mededeling (doelgroep, titel, tekst, datum)
                VALUES (:dg, :titel, :tekst, NOW())";
        $this->db->run($sql, [
            'dg'    => $doelgroep,
            'titel' => $titel,
            'tekst' => $tekst,
        ]);
    }

    public function voorDoelgroep(string $doelgroep): array
    {
        $sql = "SELECT * FROM mededeling
                WHERE doelgroep = :dg OR doelgroep = 'allen'
                ORDER BY id DESC";
        return $this->db->run($sql, ['dg' => $doelgroep])->fetchAll();
    }

    public function alles(): array
    {
        return $this->db->run("SELECT * FROM mededeling ORDER BY id DESC")->fetchAll();
    }
}


