<?php

require_once __DIR__ . "/db.php";

class Pakket
{
    private DB $db;

    public function __construct()
    {
        $this->db = new DB();
    }

    public function alle(): array
    {
        return $this->db->run("SELECT * FROM pakket WHERE actief = 1")->fetchAll();
    }

    public function maak(string $naam, string $omschrijving, string $prijs, int $aantalLessen): void
    {
        $sql = "INSERT INTO pakket (naam, omschrijving, prijs, aantal_lessen, actief)
                VALUES (:n, :o, :p, :a, 1)";
        $this->db->run($sql, [
            'n' => $naam,
            'o' => $omschrijving,
            'p' => $prijs,
            'a' => $aantalLessen,
        ]);
    }
}


