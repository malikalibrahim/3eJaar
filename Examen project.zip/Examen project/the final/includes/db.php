<?php

class DB {
    protected PDO $pdo;

    public function __construct(
        string $db = "rijschool_examen",
        string $user = "root",
        string $pwd = "",
        string $host = "localhost"
    ) {
        try {
            $dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";
            $this->pdo = new PDO($dsn, $user, $pwd, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $e) {
            die("Connection failed: " . $e->getMessage());
        }
    }

    public function run(string $sql, ?array $args = null): PDOStatement {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($args ?? []);
        return $stmt;
    }
}


