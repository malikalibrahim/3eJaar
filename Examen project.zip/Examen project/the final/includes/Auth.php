<?php

require_once __DIR__ . "/db.php";

class Auth
{
    private DB $db;

    public function __construct()
    {
        $this->db = new DB();
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    public function login(string $email, string $password, string $rol): bool
    {
        $sql = "SELECT * FROM gebruiker WHERE email = :email AND rol = :rol AND actief = 1";
        $row = $this->db->run($sql, ['email' => $email, 'rol' => $rol])->fetch();

        if (!$row || !password_verify($password, $row['wachtwoord'])) {
            return false;
        }

        $_SESSION['login_status'] = true;
        $_SESSION['gebruiker_id'] = $row['id'];
        $_SESSION['rol']          = $row['rol'];
        $_SESSION['naam']         = trim(($row['voornaam'] ?? '') . ' ' . ($row['achternaam'] ?? ''));

        return true;
    }

    public function logout(): void
    {
        $_SESSION = [];
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
    }

    public function check(?string $rol = null): bool
    {
        if (empty($_SESSION['login_status'])) {
            return false;
        }
        if ($rol === null) {
            return true;
        }
        return isset($_SESSION['rol']) && $_SESSION['rol'] === $rol;
    }

    public function user(): ?array
    {
        if (!$this->check()) {
            return null;
        }
        return [
            'id'   => $_SESSION['gebruiker_id'] ?? null,
            'rol'  => $_SESSION['rol'] ?? null,
            'naam' => $_SESSION['naam'] ?? null,
        ];
    }
}


