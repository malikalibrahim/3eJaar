# 🚀 SETUP INSTRUCTIES - Rijschool Management Systeem

## ✅ Stap 1: Database Setup

Zorg ervoor dat je MySQL database `rijschool_examen` bestaat met de juiste tabellen.

**Database Credentials (standaard XAMPP):**
- Host: `localhost`
- User: `root`
- Password: (leeg)
- Database: `rijschool_examen`

---

## ✅ Stap 2: Test Accounts Aanmaken

### Optie A: Via PHP Setup Script (AANBEVOLEN)
1. Open je browser
2. Ga naar: `http://localhost/Examen%20project/the%20final/rijschool_examen/setup.php`
3. Accounts worden automatisch aangemaakt
4. Verwijder `setup.php` daarna voor veiligheid!

### Optie B: Via SQL Script
1. Open phpMyAdmin
2. Selecteer database `rijschool_examen`
3. Ga naar "SQL" tab
4. Copy-paste inhoud van `setup.sql`
5. Klik "Go"

---

## 🔐 Test Accounts

Alle accounts hebben wachtwoord: **test1234**

| Rol | Email | Wachtwoord | Gebruik |
|-----|-------|-----------|---------|
| 👨‍🎓 Leerling | leerling@test.nl | test1234 | Test lesrooster, profiel, lesannuleringen |
| 👨‍🏫 Instructeur | instructeur@test.nl | test1234 | Test dagrooster, weekrooster, ziekmeldingen |
| 🏢 Rijschoolhouder | admin@test.nl | test1234 | Test wagenpark, mededelingen, lespakketten |

---

## 🧪 Eerste Test: Inloggen

1. Ga naar: `http://localhost/Examen%20project/the%20final/rijschool_examen/`
2. Vul in: `leerling@test.nl` / `test1234`
3. Klik "Inloggen"
4. Je wordt doorgestuurd naar het leerling dashboard

---

## 🔄 Logout Test

1. In de navigatiebalk (rechtsboven) zie je: "Ingelogd als Jan de Leerling (leerling)"
2. Klik op "Uitloggen" knop
3. Je wordt teruggestuurd naar de inlogpagina

---

## 🗂️ Mappenstructuur

```
rijschool_examen/
├── setup.php              ← PHP Setup Script (run dit EERST!)
├── setup.sql              ← SQL Alternatie (als setup.php niet werkt)
├── index.php              ← Inlogpagina
├── includes/              ← Backend classes
├── user/                  ← Layout templates
├── leerling/              ← Leerling pages
├── instructeur/           ← Instructeur pages
├── rijschool/             ← Rijschoolhouder pages
├── Les/                   ← Lesmanagement
├── Auto/                  ← Wagenpark
├── Mededeling/            ← Mededelingen
├── Pakket/                ← Lespakketten
├── Ziek/                  ← Ziekmeldingen
├── USER_STORIES.md        ← User stories documentatie
├── MAPSTRUCTUUR.md        ← Mappenstructuur gids
└── BUGFIXES.md            ← Bugfixes log
```

---

## 🛠️ Troubleshooting

### Setup.php werkt niet
**Symptoom:** "Connection failed"
- Zorg dat MySQL server draait
- Controleer database `rijschool_examen` bestaat
- Check gebruiker/wachtwoord in `includes/db.php`

### Inloggen werkt niet
**Symptoom:** "Onjuiste e-mailadres of wachtwoord"
- Controleer dat accounts via setup.php/sql zijn aangemaakt
- Check email spelling (case-sensitive)
- Zorg dat MySQL service draait

### Logout werkt niet
**Symptoom:** Zit nog steeds ingelogd na klik
- Dit is nu opgelost in versie Dec 2025
- Controleer je `user/logout.php` path is correct

### Session errors
**Symptoom:** "Session already started" warnings
- Dit betekent `session_start()` wordt meerdere keren aangeroepen
- Check `includes/Auth.php` (al gefixt in huidige versie)

---

## 🔐 Security Notes (BELANGRIJK!)

### Voor Development:
✅ Setup.php mag bestaan (handig voor testen)

### Voor Production:
❌ **VERWIJDER setup.php DIRECT!**
- Dit bestand maakt accounts aan zonder controle
- Kan gebruikt worden om ongeautoriseerde accounts te creëren

---

## 📋 Volgende Stappen

Na setup en first login test:

1. **Test Leerling Flows:**
   - Dashboard bekijken
   - Lesrooster inzien
   - Profiel bewerken
   - Les annuleren (als lessen bestaan)

2. **Test Instructeur Flows:**
   - Dagrooster bekijken
   - Weekrooster bekijken
   - Wagenpark zien
   - Ziek melden

3. **Test Rijschoolhouder Flows:**
   - Dashboard bekijken
   - Wagenpark beheren
   - Mededelingen plaatsen
   - Lespakketten beheren
   - Instructeurs beheren

---

## 📞 Support

Contactpunten voor issues:
- Database errors: Check MySQL
- Login errors: Controleer accounts in database
- Page errors: Check console log en browser developer tools
- PHP errors: Check Apache error log in XAMPP

---

*Setup Guide - December 2025*
*Rijschool Management Systeem v1.0*
