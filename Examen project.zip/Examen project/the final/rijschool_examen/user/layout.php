<?php
require_once __DIR__ . "/../includes/Auth.php";

$auth = new Auth();
$user = $auth->user();

if (!$auth->check()) {
    header("Location: ../index.php");
    exit;
}

// Definieer BASE_URL voor consistente links naar de app root
define('BASE_URL', dirname(dirname($_SERVER['SCRIPT_NAME'])));

function layout_header(string $title): void {
    global $user;
    ?>
    <!DOCTYPE html>
    <html lang="nl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo htmlspecialchars($title); ?> - Rijschool</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container-fluid">
            <a class="navbar-brand fw-semibold" href="<?php echo BASE_URL; ?>/index.php">Rijschool</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <?php if ($user['rol'] === 'leerling'): ?>
                        <li class="nav-item"><a class="nav-link" href="<?php echo BASE_URL; ?>/leerling/dashboard.php">Dashboard</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo BASE_URL; ?>/Les/les-plannen.php">Les plannen</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo BASE_URL; ?>/leerling/rooster.php">Lesrooster</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo BASE_URL; ?>/leerling/profiel.php">Mijn profiel</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo BASE_URL; ?>/Mededeling/mededeling-view.php">Mededelingen</a></li>
                    <?php elseif ($user['rol'] === 'instructeur'): ?>
                        <li class="nav-item"><a class="nav-link" href="<?php echo BASE_URL; ?>/instructeur/dashboard.php">Dashboard</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo BASE_URL; ?>/instructeur/dagrooster.php">Dagrooster</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo BASE_URL; ?>/instructeur/weekrooster.php">Weekrooster</a></li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="instructeurMore" role="button" data-bs-toggle="dropdown" aria-expanded="false">Meer</a>
                            <ul class="dropdown-menu" aria-labelledby="instructeurMore">
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/instructeur/wagenpark.php">Wagenpark</a></li>
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/Les/les-add.php">Les toevoegen</a></li>
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/instructeur/les-opmerking.php">Les opmerkingen</a></li>
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/instructeur/ziek-melden.php">Ziek melden</a></li>
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/instructeur/kilometres-register.php">Kilometer registratie</a></li>
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/Auto/mankement-add.php">Mankement melden</a></li>
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/Mededeling/mededeling-view.php">Mededelingen</a></li>
                            </ul>
                        </li>
                    <?php elseif ($user['rol'] === 'rijschoolhouder'): ?>
                        <li class="nav-item"><a class="nav-link" href="<?php echo BASE_URL; ?>/rijschool/dashboard.php">Dashboard</a></li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="ownerMore" role="button" data-bs-toggle="dropdown" aria-expanded="false">Beheer</a>
                            <ul class="dropdown-menu" aria-labelledby="ownerMore">
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/Auto/auto-view.php">Wagenpark</a></li>
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/Auto/auto-assign-instructor.php">Auto toewijzen</a></li>
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/instructeur/instructeur-view.php">Instructeurs</a></li>
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/Pakket/pakket-view.php">Lespakketten</a></li>
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/Mededeling/mededeling-view.php">Mededelingen</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav ms-3">
                    <li class="nav-item"><a class="nav-link" href="<?php echo BASE_URL; ?>/locatie.php">Locatie</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo BASE_URL; ?>/voorwaarden.php">Voorwaarden</a></li>
                </ul>
                <span class="navbar-text me-3 small">
                    Ingelogd als <?php echo htmlspecialchars($user['naam']); ?> (<?php echo htmlspecialchars($user['rol']); ?>)
                </span>
                <a href="<?php echo BASE_URL; ?>/user/logout.php" class="btn btn-outline-light btn-sm">Uitloggen</a>
            </div>
        </div>
    </nav>
    <main class="container mb-5">
    <?php
}

function layout_footer(): void {
    ?>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    <?php
}


