<?php
// Redirect to canonical Les location (preserve id if present)
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$loc = '../Les/les-annuleer.php' . ($id ? '?id=' . $id : '');
header('Location: ' . $loc);
exit;
?>


