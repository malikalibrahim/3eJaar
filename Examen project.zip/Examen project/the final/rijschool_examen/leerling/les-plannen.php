<?php
// Redirect to the canonical Les/ location
header('Location: ../Les/les-plannen.php');
exit;
?>
