<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Mededeling.php";

layout_header("Dashboard leerling");
$medRepo = new Mededeling();
$meded = $medRepo->voorDoelgroep('leerling');
?>

<div class="row">
    <div class="col-lg-8">
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h2 class="h5 mb-3">Welkom, leerling</h2>
                <p class="small text-muted">
                    Hier zie je straks je eerstvolgende lessen, opmerkingen van je instructeur en eventuele
                    mededelingen voor leerlingen.
                </p>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h3 class="h6 mb-0">Mededelingen voor leerlingen</h3>
                    <a href="../Mededeling/mededeling-view.php" class="small">Alle mededelingen</a>
                </div>

                <?php if (!empty($meded)): ?>
                    <?php foreach (array_slice($meded, 0, 5) as $m): ?>
                        <div class="border rounded p-2 mb-2">
                            <div class="small text-muted mb-1"><?php echo htmlspecialchars($m['datum']); ?></div>
                            <div class="fw-semibold"><?php echo htmlspecialchars($m['titel']); ?></div>
                            <div class="small text-muted"><?php echo htmlspecialchars(substr($m['tekst'], 0, 120)); ?><?php echo strlen($m['tekst'])>120? '...':''; ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="small text-muted">Geen mededelingen voor leerlingen.</div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>

<?php layout_footer(); ?>


