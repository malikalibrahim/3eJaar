<?php
// Redirect to canonical Les location (preserve id if present)
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$loc = '../Les/les-opmerking.php' . ($id ? '?id=' . $id : '');
header('Location: ' . $loc);
exit;
?>


