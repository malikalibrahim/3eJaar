<?php
require_once __DIR__ . "/../includes/Auth.php";
require_once __DIR__ . "/../includes/Gebruiker.php";

$auth = new Auth();

// Als je al ingelogd bent, ga naar dashboard
if ($auth->check()) {
    $user = $auth->user();
    switch ($user['rol']) {
        case 'leerling':
            header("Location: dashboard.php");
            exit;
        case 'instructeur':
            header("Location: ../instructeur/dashboard.php");
            exit;
        case 'rijschoolhouder':
            header("Location: ../rijschool/dashboard.php");
            exit;
    }
}

$gebruikerRepo = new Gebruiker();
$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $voornaam   = trim($_POST['voornaam'] ?? '');
    $achternaam = trim($_POST['achternaam'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $wachtwoord = $_POST['wachtwoord'] ?? '';
    $wachtwoord_repeat = $_POST['wachtwoord_repeat'] ?? '';
    $telefoon   = trim($_POST['telefoon'] ?? '');
    $adres      = trim($_POST['adres'] ?? '');
    $postcode   = trim($_POST['postcode'] ?? '');
    $plaats     = trim($_POST['plaats'] ?? '');

    if (!$voornaam || !$achternaam || !$email || !$wachtwoord) {
        $error = "Voornaam, achternaam, e-mailadres en wachtwoord zijn verplicht.";
    } elseif ($wachtwoord !== $wachtwoord_repeat) {
        $error = "Wachtwoorden komen niet overeen.";
    } elseif (strlen($wachtwoord) < 6) {
        $error = "Wachtwoord moet minstens 6 tekens zijn.";
    } else {
        try {
            $gebruikerRepo->registreerLeerling($voornaam, $achternaam, $email, $wachtwoord, $telefoon, $adres, $postcode, $plaats);
            $success = "Registratie gelukt! Je kunt nu inloggen.";
        } catch (Throwable $e) {
            $error = "Kon account niet aanmaken: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registreren - Rijschool</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #0f172a, #1d4ed8);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        }
        .card {
            border-radius: 1.5rem;
            box-shadow: 0 25px 50px -12px rgba(15,23,42,0.6);
            overflow: hidden;
        }
        .brand-side {
            background: radial-gradient(circle at top left, #38bdf8, #0f172a);
            color: #e5e7eb;
        }
        .brand-logo {
            font-weight: 800;
            letter-spacing: .08em;
            text-transform: uppercase;
        }
        .form-control, .form-select {
            border-radius: .75rem;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-9">
            <div class="card border-0">
                <div class="row g-0">
                    <div class="col-md-5 brand-side p-4 d-flex flex-column justify-content-between">
                        <div>
                            <div class="brand-logo mb-3">RIJSCHOOL</div>
                            <h2 class="h4 fw-semibold mb-2">Professionele rijopleiding</h2>
                            <p class="text-sm text-gray-300 mb-4">
                                Word leerling bij onze rijschool en volg professionele rijopleiding.
                            </p>
                            <ul class="small text-gray-300 ps-3">
                                <li>Flexibel lesrooster</li>
                                <li>Ervarende instructeurs</li>
                                <li>Persoonlijke begeleiding</li>
                            </ul>
                        </div>
                        <div class="mt-3">
                            <p class="small mb-1">Al een account?</p>
                            <a href="../index.php" class="btn btn-outline-light btn-sm">
                                Naar inlogpagina
                            </a>
                        </div>
                    </div>
                    <div class="col-md-7 p-4 p-md-5">
                        <div class="mb-4">
                            <h1 class="h4 mb-1">Registreren als leerling</h1>
                            <p class="text-muted small mb-0">Vul je gegevens in om een account aan te maken.</p>
                        </div>

                        <?php if ($error): ?>
                            <div class="alert alert-danger py-2 small">
                                <?php echo htmlspecialchars($error); ?>
                            </div>
                        <?php endif; ?>
                        <?php if ($success): ?>
                            <div class="alert alert-success py-2 small">
                                <?php echo htmlspecialchars($success); ?>
                                <br><a href="../index.php" class="btn btn-sm btn-primary mt-2">Ga naar inlogpagina</a>
                            </div>
                        <?php else: ?>
                            <form method="POST" class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label small">Voornaam</label>
                                    <input type="text" name="voornaam" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small">Achternaam</label>
                                    <input type="text" name="achternaam" class="form-control" required>
                                </div>
                                <div class="col-12">
                                    <label class="form-label small">E-mailadres</label>
                                    <input type="email" name="email" class="form-control" placeholder="jouw@email.nl" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small">Wachtwoord</label>
                                    <input type="password" name="wachtwoord" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small">Herhaal wachtwoord</label>
                                    <input type="password" name="wachtwoord_repeat" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small">Telefoonnummer</label>
                                    <input type="text" name="telefoon" class="form-control">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small">Postcode</label>
                                    <input type="text" name="postcode" class="form-control">
                                </div>
                                <div class="col-12">
                                    <label class="form-label small">Adres</label>
                                    <input type="text" name="adres" class="form-control">
                                </div>
                                <div class="col-12">
                                    <label class="form-label small">Plaats</label>
                                    <input type="text" name="plaats" class="form-control">
                                </div>
                                <div class="col-12 text-end">
                                    <button class="btn btn-primary" type="submit">Account aanmaken</button>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
