<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Auto.php";
require_once __DIR__ . "/../includes/CSRF.php";

// Only instructeurs and rijschoolhouder may access this page
if (!in_array($user['rol'], ['instructeur', 'rijschoolhouder'])) {
    header('HTTP/1.1 403 Forbidden');
    echo "Toegang geweigerd.";
    exit;
}

$autoRepo = new AutoRepo();
$message = null;
$err = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!\CSRF::validate($token)) {
        $err = 'Ongeldige sessie (CSRF-token mismatch). Probeer het opnieuw.';
    } else {
        $autoId = isset($_POST['auto_id']) ? (int)$_POST['auto_id'] : 0;
        $datum = !empty($_POST['datum']) ? $_POST['datum'] : date('Y-m-d');
        $km = isset($_POST['km']) ? (int)$_POST['km'] : null;

        if ($autoId <= 0 || $km === null || $km < 0) {
            $err = 'Selecteer een auto en geef een geldige kilometerstand op.';
        } else {
            try {
                $instructeurId = (int)$user['id'];
                $autoRepo->registreerKilometerstand($autoId, $instructeurId, $datum, $km);
                $message = 'Kilometerstand succesvol geregistreerd.';
            } catch (Exception $e) {
                $err = 'Fout bij opslaan: ' . $e->getMessage();
            }
        }
    }
}

$today = date('Y-m-d');
$assigned = null;
if ($user['rol'] === 'instructeur') {
    $assigned = $autoRepo->autoVoorInstructeurVandaag((int)$user['id'], $today);
    $autos = $assigned ? [$assigned] : [];
} else {
    // rijschoolhouder may pick any active auto
    $autos = $autoRepo->alleAutos();
}

layout_header('Kilometer registratie');
?>

<div class="row">
    <div class="col-lg-8">
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h1 class="h5">Kilometerstand invoeren</h1>

                <?php if ($message): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
                <?php endif; ?>
                <?php if ($err): ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars($err); ?></div>
                <?php endif; ?>

                <form method="post">
                    <?php echo \CSRF::inputField(); ?>
                    <div class="mb-3">
                        <label class="form-label">Auto</label>
                        <select name="auto_id" class="form-select">
                            <option value="">-- selecteer --</option>
                            <?php foreach ($autos as $a): ?>
                                <option value="<?php echo (int)$a['id']; ?>"><?php echo htmlspecialchars($a['kenteken'] . ' — ' . $a['merk'] . ' ' . $a['type']); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (empty($autos)): ?>
                            <div class="small text-muted mt-1">Geen toegewezen auto's gevonden voor vandaag.</div>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Datum</label>
                        <input type="date" name="datum" class="form-control" value="<?php echo htmlspecialchars($today); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Kilometerstand (einde dag)</label>
                        <input type="number" name="km" class="form-control" min="0" required>
                    </div>

                    <button class="btn btn-primary">Opslaan</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h6 class="mb-2">Instructie</h6>
                <p class="small text-muted">Voer aan het einde van uw werktijd de kilometerstand in voor de geselecteerde auto.</p>
                <?php if ($assigned): ?>
                    <div class="small mt-2">Toegewezen auto vandaag: <strong><?php echo htmlspecialchars($assigned['kenteken']); ?></strong></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php layout_footer(); ?>
