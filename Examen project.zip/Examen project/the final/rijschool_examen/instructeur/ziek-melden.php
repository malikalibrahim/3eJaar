<?php
// Redirect naar ziekmeldingspagina in Ziek folder
require_once __DIR__ . "/../includes/Auth.php";

$auth = new Auth();
$user = $auth->user();

if ($user['rol'] !== 'instructeur') {
    header("Location: ../index.php");
    exit;
}

// Redirect naar ziekmeldingspagina
header("Location: ../Ziek/ziek-add.php");
exit;
?>
