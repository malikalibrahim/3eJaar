<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Les.php";
require_once __DIR__ . "/../includes/Auth.php";
require_once __DIR__ . "/../includes/CSRF.php";

$auth = new Auth();
if (!$auth->check()) {
    header('Location: ../index.php');
    exit;
}

$user = $auth->user();
$lesRepo = new Les();

layout_header("Ophaallocatie bewerken");

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$les = $id > 0 ? $lesRepo->findById($id) : null;

if (!$les) {
    echo "<div class='alert alert-warning'>Les niet gevonden.</div>";
    layout_footer();
    exit;
}

// Alleen de leerling die eigenaar is mag de ophaallocatie aanpassen
if ($les['leerling_id'] != $user['id']) {
    echo "<div class='alert alert-danger'>Je hebt geen rechten om deze les te bewerken.</div>";
    layout_footer();
    exit;
}

if ($les['status'] !== 'gepland') {
    echo "<div class='alert alert-info'>Alleen geplande lessen kunnen worden aangepast.</div>";
    layout_footer();
    exit;
}

$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!\CSRF::validate($token)) {
        $error = "Ongeldige sessie (CSRF-token mismatch). Probeer het opnieuw.";
    } else {
        $loc = trim($_POST['ophaallocatie'] ?? '');
        if ($loc === '') {
            $error = "Ophaallocatie mag niet leeg zijn.";
        } else {
            try {
                // updateLes verwacht volledige set velden; haal huidige waarden en wijzig alleen locatie
                $lesRepo->updateLes(
                    $id,
                    $les['datum'],
                    $les['starttijd'],
                    $les['eindtijd'],
                    $loc,
                    $les['onderwerp'] ?? ''
                );
                $success = "Ophaallocatie bijgewerkt.";
                $les = $lesRepo->findById($id);
            } catch (Throwable $e) {
                $error = "Kon ophaallocatie niet bijwerken: " . $e->getMessage();
            }
        }
    }
}

?>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h5 mb-0">Ophaallocatie bewerken</h1>
            <a href="../leerling/rooster.php" class="btn btn-outline-secondary btn-sm">Terug</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger py-2 small"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success py-2 small"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <form method="POST" class="row g-3">
            <?php echo \CSRF::inputField(); ?>
            <div class="col-12">
                <label class="form-label small">Huidige datum / tijd</label>
                <div class="form-control-plaintext small"><?php echo htmlspecialchars($les['datum'] . ' — ' . $les['starttijd'] . ' tot ' . $les['eindtijd']); ?></div>
            </div>

            <div class="col-12">
                <label class="form-label small">Ophaallocatie</label>
                <input type="text" name="ophaallocatie" class="form-control" value="<?php echo htmlspecialchars($les['ophaallocatie']); ?>" required>
            </div>

            <div class="col-12 text-end">
                <button class="btn btn-primary btn-sm">Opslaan</button>
            </div>
        </form>
    </div>
</div>

<?php layout_footer(); ?>
