<?php
// Hoofdpagina + inlog voor alle rollen uit tabel `gebruiker`
require_once __DIR__ . "/includes/Auth.php";

$auth = new Auth();

if ($auth->check()) {
    $user = $auth->user();
    switch ($user['rol']) {
        case 'leerling':
            header("Location: leerling/dashboard.php");
            exit;
        case 'instructeur':
            header("Location: instructeur/dashboard.php");
            exit;
        case 'rijschoolhouder':
            header("Location: rijschool/dashboard.php");
            exit;
    }
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = trim($_POST['wachtwoord'] ?? '');

    if ($email === '' || $password === '') {
        $error = "Vul alle velden in.";
    } else {
        if ($auth->login($email, $password)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Onjuiste e-mailadres of wachtwoord.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rijschool – Inloggen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #0f172a, #1d4ed8);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        }
        .card {
            border-radius: 1.5rem;
            box-shadow: 0 25px 50px -12px rgba(15,23,42,0.6);
            overflow: hidden;
        }
        .brand-side {
            background: radial-gradient(circle at top left, #38bdf8, #0f172a);
            color: #e5e7eb;
        }
        .brand-logo {
            font-weight: 800;
            letter-spacing: .08em;
            text-transform: uppercase;
        }
        .form-control, .form-select {
            border-radius: .75rem;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-9">
            <div class="card border-0">
                <div class="row g-0">
                    <div class="col-md-5 brand-side p-4 d-flex flex-column justify-content-between">
                        <div>
                            <div class="brand-logo mb-3">RIJSCHOOL</div>
                            <h2 class="h4 fw-semibold mb-2">Professionele rijopleiding</h2>
                            <p class="text-sm text-gray-300 mb-4">
                                Leerlingen, instructeurs en rijschoolhouder werken samen in één planningstool.
                            </p>
                            <ul class="small text-gray-300 ps-3">
                                <li>Lesroosters en lespakketten beheren</li>
                                <li>Mededelingen per doelgroep</li>
                                <li>Overzicht van het volledige wagenpark</li>
                            </ul>
                        </div>
                        <div class="mt-3">
                            <p class="small mb-1">Locatie rijschool</p>
                            <p class="small mb-2">Vul hier jouw adres in</p>
                            <a class="btn btn-outline-light btn-sm" target="_blank"
                               href="https://www.google.com/maps/dir/?api=1&destination=Rijschool">
                                Routebeschrijving openen
                            </a>
                        </div>
                    </div>
                    <div class="col-md-7 p-4 p-md-5">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <div>
                                <h1 class="h4 mb-1">Inloggen</h1>
                                <p class="text-muted small mb-0">Log in met je e-mailadres en wachtwoord.</p>
                            </div>
                            <a href="leerling/register.php" class="btn btn-outline-primary btn-sm">
                                Registreren als leerling
                            </a>
                        </div>

                        <?php if ($error): ?>
                            <div class="alert alert-danger py-2 small">
                                <?php echo $error; ?>
                            </div>
                        <?php endif; ?>

                        <form method="POST" class="mt-3">
                            <div class="mb-3">
                                <label for="email" class="form-label small fw-semibold">E‑mailadres</label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="jouw@email.nl" required autofocus>
                            </div>
                            <div class="mb-3">
                                <label for="wachtwoord" class="form-label small fw-semibold">Wachtwoord</label>
                                <input type="password" class="form-control" id="wachtwoord" name="wachtwoord" placeholder="Jouw wachtwoord" required>
                            </div>
                            <button class="btn btn-primary w-100 mt-2" type="submit">
                                Inloggen
                            </button>
                        </form>

                        <hr class="my-4">

                        <div class="small text-muted">
                            <strong>Bedrijfsinformatie</strong><br>
                            Deze informatie komt uit de tabel <code>rijschool</code> (eigenaar, medewerkers, doelstellingen).
                            Later vullen we hier dynamische gegevens in.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>


