<?php

require_once __DIR__ . "/db.php";

class Les
{
    private DB $db;

    public function __construct()
    {
        $this->db = new DB();
    }

    public function planLesDoorLeerling(
        int $leerlingId,
        int $instructeurId,
        string $datum,
        string $starttijd,
        string $eindtijd,
        string $ophaallocatie,
        string $onderwerp
    ): void {
        // Basic sanity check: start < end
        if (strtotime($datum . ' ' . $starttijd) >= strtotime($datum . ' ' . $eindtijd)) {
            throw new Exception('Starttijd moet vóór eindtijd liggen.');
        }

        // Check for overlapping lessons for same instructor or same leerling
        if ($this->hasOverlap($instructeurId, $leerlingId, $datum, $starttijd, $eindtijd)) {
            throw new Exception('Tijdslot is niet beschikbaar voor deze instructeur of leerling. Kies een ander tijdstip.');
        }

        $sql = "INSERT INTO les
                (leerling_id, instructeur_id, datum, starttijd, eindtijd, ophaallocatie, onderwerp, status)
                VALUES (:lid, :iid, :dat, :start, :eind, :loc, :ond, 'gepland')";

        $this->db->run($sql, [
            'lid'   => $leerlingId,
            'iid'   => $instructeurId,
            'dat'   => $datum,
            'start' => $starttijd,
            'eind'  => $eindtijd,
            'loc'   => $ophaallocatie,
            'ond'   => $onderwerp,
        ]);
    }

    public function planLesDoorInstructeur(
        int $leerlingId,
        int $instructeurId,
        string $datum,
        string $starttijd,
        string $eindtijd,
        string $ophaallocatie,
        string $onderwerp
    ): void {
        // Reuse student planning logic (includes overlap check)
        $this->planLesDoorLeerling(
            $leerlingId,
            $instructeurId,
            $datum,
            $starttijd,
            $eindtijd,
            $ophaallocatie,
            $onderwerp
        );
    }

    public function updateLes(
        int $id,
        string $datum,
        string $starttijd,
        string $eindtijd,
        string $ophaallocatie,
        string $onderwerp
    ): void {
        // Basic sanity check: start < end
        if (strtotime($datum . ' ' . $starttijd) >= strtotime($datum . ' ' . $eindtijd)) {
            throw new Exception('Starttijd moet vóór eindtijd liggen.');
        }

        // Find existing lesson to get leerling and instructeur
        $existing = $this->findById($id);
        if (!$existing) {
            throw new Exception('Les niet gevonden.');
        }

        // Check for overlapping lessons for same instructor or same leerling (exclude current lesson)
        if ($this->hasOverlap((int)$existing['instructeur_id'], (int)$existing['leerling_id'], $datum, $starttijd, $eindtijd, $id)) {
            throw new Exception('Tijdslot overlapt met een andere geplande les. Kies een ander tijdstip.');
        }

        $sql = "UPDATE les
                SET datum = :dat,
                    starttijd = :start,
                    eindtijd = :eind,
                    ophaallocatie = :loc,
                    onderwerp = :ond
                WHERE id = :id";

        $this->db->run($sql, [
            'dat'   => $datum,
            'start' => $starttijd,
            'eind'  => $eindtijd,
            'loc'   => $ophaallocatie,
            'ond'   => $onderwerp,
            'id'    => $id,
        ]);
    }

    public function annuleerDoorLeerling(int $id, string $reden): void
    {
        $sql = "UPDATE les
                SET status = 'geannuleerd',
                    annuleer_reden = :reden
                WHERE id = :id";

        $this->db->run($sql, ['reden' => $reden, 'id' => $id]);
    }

    public function opslaanOpmerkingInstructeur(int $id, string $opmerking): void
    {
        $this->db->run(
            "UPDATE les SET opmerking_instructeur = :opm WHERE id = :id",
            ['opm' => $opmerking, 'id' => $id]
        );
    }

    public function opslaanOpmerkingLeerling(int $id, string $opmerking): void
    {
        $this->db->run(
            "UPDATE les SET opmerking_leerling = :opm WHERE id = :id",
            ['opm' => $opmerking, 'id' => $id]
        );
    }

    public function roosterVoorLeerling(int $leerlingId): array
    {
        $sql = "SELECT * FROM les
                WHERE leerling_id = :id
                ORDER BY datum, starttijd";
        return $this->db->run($sql, ['id' => $leerlingId])->fetchAll();
    }

    public function dagroosterInstructeur(int $instructeurId, string $datum): array
    {
        $sql = "SELECT l.*, g.voornaam, g.achternaam
                FROM les l
                LEFT JOIN gebruiker g ON g.id = l.leerling_id
                WHERE l.instructeur_id = :iid
                  AND l.datum = :dat
                ORDER BY l.starttijd";
        return $this->db->run($sql, ['iid' => $instructeurId, 'dat' => $datum])->fetchAll();
    }

    public function weekroosterInstructeur(int $instructeurId, string $startDatum, string $eindDatum): array
    {
        $sql = "SELECT l.*, g.voornaam, g.achternaam
                FROM les l
                LEFT JOIN gebruiker g ON g.id = l.leerling_id
                WHERE l.instructeur_id = :iid
                  AND l.datum BETWEEN :start AND :eind
                ORDER BY l.datum, l.starttijd";
        return $this->db->run($sql, [
            'iid'   => $instructeurId,
            'start' => $startDatum,
            'eind'  => $eindDatum,
        ])->fetchAll();
    }

    public function alleLessen(): array
    {
        return $this->db->run(
            "SELECT * FROM les ORDER BY datum DESC, starttijd DESC"
        )->fetchAll();
    }

    public function findById(int $id): ?array
    {
        $row = $this->db->run(
            "SELECT * FROM les WHERE id = :id",
            ['id' => $id]
        )->fetch();
        return $row ?: null;
    }

    public function delete(int $id): void
    {
        $this->db->run("DELETE FROM les WHERE id = :id", ['id' => $id]);
    }

    private function hasOverlap(int $instructeurId, int $leerlingId, string $datum, string $starttijd, string $eindtijd, int $excludeId = null): bool
    {
        $sql = "SELECT COUNT(*) AS cnt FROM les
                WHERE datum = :dat
                  AND status = 'gepland'
                  AND ((starttijd < :end AND eindtijd > :start))
                  AND (instructeur_id = :iid OR leerling_id = :lid)";

        $params = [
            'dat'   => $datum,
            'start' => $starttijd,
            'end'   => $eindtijd,
            'iid'   => $instructeurId,
            'lid'   => $leerlingId,
        ];

        if ($excludeId) {
            $sql .= " AND id != :ex";
            $params['ex'] = $excludeId;
        }

        $row = $this->db->run($sql, $params)->fetch();
        return ($row && isset($row['cnt']) && (int)$row['cnt'] > 0);
    }
}


