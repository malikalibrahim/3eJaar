<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Pakket.php";
require_once __DIR__ . "/../includes/db.php";

layout_header("Lespaket bewerken");

$db = new DB();
$pakketten = new Pakket();
$error = null;
$success = null;
$pakket = null;

$id = (int) ($_GET['id'] ?? 0);

if ($id > 0) {
    $pakket = $db->run("SELECT * FROM pakket WHERE id = :id", ['id' => $id])->fetch();
}

if (!$pakket) {
    $error = "Lespaket niet gevonden.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $naam = trim($_POST['naam'] ?? '');
    $omschrijving = trim($_POST['omschrijving'] ?? '');
    $prijs = trim($_POST['prijs'] ?? '');
    $aantalLessen = (int) ($_POST['aantalLessen'] ?? 0);

    if (!$naam || !$omschrijving || !$prijs || !$aantalLessen) {
        $error = "Alle velden zijn verplicht.";
    } else {
        try {
            $sql = "UPDATE pakket SET naam = :n, omschrijving = :o, prijs = :p, aantal_lessen = :a WHERE id = :id";
            $db->run($sql, [
                'n' => $naam,
                'o' => $omschrijving,
                'p' => $prijs,
                'a' => $aantalLessen,
                'id' => $id,
            ]);
            $success = "Lespaket is bijgewerkt.";
            $pakket = $db->run("SELECT * FROM pakket WHERE id = :id", ['id' => $id])->fetch();
        } catch (Throwable $e) {
            $error = "Kon lespaket niet bijwerken: " . $e->getMessage();
        }
    }
}
?>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h5 mb-0">Lespaket bewerken</h1>
            <a href="pakket-view.php" class="btn btn-outline-secondary btn-sm">Terug naar overzicht</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger py-2 small"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success py-2 small"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <?php if ($pakket): ?>
            <form method="POST" class="row g-3">
                <div class="col-md-6">
                    <label class="form-label small">Naam</label>
                    <input type="text" name="naam" class="form-control" value="<?php echo htmlspecialchars($pakket['naam']); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label small">Prijs (€)</label>
                    <input type="number" name="prijs" class="form-control" step="0.01" value="<?php echo $pakket['prijs']; ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label small">Aantal lessen</label>
                    <input type="number" name="aantalLessen" class="form-control" min="1" value="<?php echo $pakket['aantal_lessen']; ?>" required>
                </div>
                <div class="col-12">
                    <label class="form-label small">Omschrijving</label>
                    <textarea name="omschrijving" class="form-control" rows="4" required><?php echo htmlspecialchars($pakket['omschrijving']); ?></textarea>
                </div>
                <div class="col-12 text-end">
                    <button class="btn btn-primary btn-sm">Bijwerken</button>
                </div>
            </form>
        <?php endif; ?>
    </div>
</div>

<?php layout_footer(); ?>
