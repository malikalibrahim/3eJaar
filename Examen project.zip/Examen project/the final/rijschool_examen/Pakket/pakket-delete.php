<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/db.php";

$db = new DB();
$error = null;
$success = null;

$id = (int) ($_GET['id'] ?? 0);

if ($id > 0) {
    try {
        $db->run("UPDATE pakket SET actief = 0 WHERE id = :id", ['id' => $id]);
        header("Location: pakket-view.php?success=Lespaket+verwijderd");
        exit;
    } catch (Throwable $e) {
        $error = "Kon lespaket niet verwijderen: " . $e->getMessage();
    }
}

header("Location: pakket-view.php?error=Lespaket+niet+gevonden");
exit;
?>
