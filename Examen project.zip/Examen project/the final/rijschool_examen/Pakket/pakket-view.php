<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Pakket.php";

layout_header("Lespakketten");

$pakketten = new Pakket();
$alle_pakketten = $pakketten->alle();

?>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h5 mb-0">Lespakketten</h1>
            <a href="pakket-add.php" class="btn btn-primary btn-sm">Nieuw pakket</a>
        </div>

        <?php if (empty($alle_pakketten)): ?>
            <div class="alert alert-info small">Geen pakketten beschikbaar.</div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-sm table-hover">
                    <thead>
                        <tr>
                            <th>Naam</th>
                            <th>Omschrijving</th>
                            <th>Prijs</th>
                            <th>Aantal lessen</th>
                            <th>Acties</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($alle_pakketten as $pakket): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($pakket['naam']); ?></td>
                                <td><?php echo htmlspecialchars(substr($pakket['omschrijving'], 0, 50)) . '...'; ?></td>
                                <td>€ <?php echo number_format($pakket['prijs'], 2, ',', '.'); ?></td>
                                <td><?php echo $pakket['aantal_lessen']; ?></td>
                                <td>
                                    <a href="pakket-edit.php?id=<?php echo $pakket['id']; ?>" class="btn btn-outline-secondary btn-xs">Wijzigen</a>
                                    <a href="pakket-delete.php?id=<?php echo $pakket['id']; ?>" class="btn btn-outline-danger btn-xs" onclick="return confirm('Zeker?')">Verwijderen</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php layout_footer(); ?>
