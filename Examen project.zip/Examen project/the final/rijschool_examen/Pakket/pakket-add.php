<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Pakket.php";

layout_header("Nieuw lespaket");

$pakketten = new Pakket();
$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $naam = trim($_POST['naam'] ?? '');
    $omschrijving = trim($_POST['omschrijving'] ?? '');
    $prijs = trim($_POST['prijs'] ?? '');
    $aantalLessen = (int) ($_POST['aantalLessen'] ?? 0);

    if (!$naam || !$omschrijving || !$prijs || !$aantalLessen) {
        $error = "Alle velden zijn verplicht.";
    } else {
        try {
            $pakketten->maak($naam, $omschrijving, $prijs, $aantalLessen);
            $success = "Lespaket is aangemaakt.";
            header("Location: pakket-view.php");
            exit;
        } catch (Throwable $e) {
            $error = "Kon lespaket niet aanmaken: " . $e->getMessage();
        }
    }
}
?>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h5 mb-0">Nieuw lespaket</h1>
            <a href="pakket-view.php" class="btn btn-outline-secondary btn-sm">Terug naar overzicht</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger py-2 small"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success py-2 small"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <form method="POST" class="row g-3">
            <div class="col-md-6">
                <label class="form-label small">Naam</label>
                <input type="text" name="naam" class="form-control" required>
            </div>
            <div class="col-md-6">
                <label class="form-label small">Prijs (€)</label>
                <input type="number" name="prijs" class="form-control" step="0.01" required>
            </div>
            <div class="col-md-6">
                <label class="form-label small">Aantal lessen</label>
                <input type="number" name="aantalLessen" class="form-control" min="1" required>
            </div>
            <div class="col-12">
                <label class="form-label small">Omschrijving</label>
                <textarea name="omschrijving" class="form-control" rows="4" required></textarea>
            </div>
            <div class="col-12 text-end">
                <button class="btn btn-primary btn-sm">Opslaan</button>
            </div>
        </form>
    </div>
</div>

<?php layout_footer(); ?>
