<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Ziekmelding.php";

layout_header("Ziekmelden");

$auth      = new Auth();
$user      = $auth->user();
$ziekRepo  = new Ziekmelding();
$error     = null;
$success   = null;

if ($user['rol'] !== 'instructeur') {
    echo "<p class='text-muted'>Alleen instructeurs kunnen zich ziek melden.</p>";
    layout_footer();
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $datum = $_POST['datum'] ?? '';
    $tijd  = $_POST['tijd'] ?? '';
    $reden = trim($_POST['reden'] ?? '');

    if (!$datum || !$tijd || !$reden) {
        $error = "Alle velden zijn verplicht.";
    } else {
        try {
            $ziekRepo->meldZiek((int)$user['id'], $datum, $tijd, $reden);
            $success = "Ziekmelding verstuurd.";
        } catch (Throwable $e) {
            $error = "Kon ziekmelding niet opslaan: " . $e->getMessage();
        }
    }
}
?>

<div class="card shadow-sm">
    <div class="card-body">
        <h1 class="h5 mb-3">Ziekmelding</h1>
        <p class="small text-muted">Meld je ziek zodat de rijschoolhouder rekening kan houden met je rooster.</p>

        <?php if ($error): ?>
            <div class="alert alert-danger py-2 small"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success py-2 small"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <form method="POST" class="row g-3">
            <div class="col-md-4">
                <label class="form-label small">Datum</label>
                <input type="date" name="datum" class="form-control" required>
            </div>
            <div class="col-md-4">
                <label class="form-label small">Tijd</label>
                <input type="time" name="tijd" class="form-control" required>
            </div>
            <div class="col-12">
                <label class="form-label small">Reden</label>
                <textarea name="reden" rows="3" class="form-control" required></textarea>
            </div>
            <div class="col-12 text-end">
                <button class="btn btn-primary btn-sm">Ziek melden</button>
            </div>
        </form>
    </div>
</div>

<?php layout_footer(); ?>


