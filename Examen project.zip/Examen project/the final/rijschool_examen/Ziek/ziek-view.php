<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/db.php";

layout_header("Ziekmeldingen");

$auth = new Auth();
$user = $auth->user();

if ($user['rol'] !== 'rijschoolhouder') {
    echo "<p class='text-muted'>Alleen de rijschoolhouder kan alle ziekmeldingen bekijken.</p>";
    layout_footer();
    exit;
}

$db = new DB();
$rows = $db->run(
    "SELECT z.*, g.voornaam, g.achternaam
     FROM ziekmelding z
     LEFT JOIN gebruiker g ON g.id = z.instructeur_id
     ORDER BY z.datum DESC, z.tijd DESC"
)->fetchAll();
?>

<div class="card shadow-sm">
    <div class="card-body">
        <h1 class="h5 mb-3">Ziekmeldingen instructeurs</h1>
        <table class="table table-sm align-middle">
            <thead>
            <tr>
                <th>Datum</th>
                <th>Tijd</th>
                <th>Instructeur</th>
                <th>Reden</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td><?php echo htmlspecialchars($r['datum']); ?></td>
                    <td><?php echo htmlspecialchars($r['tijd']); ?></td>
                    <td><?php echo htmlspecialchars(trim(($r['voornaam'] ?? '') . ' ' . ($r['achternaam'] ?? ''))); ?></td>
                    <td><?php echo htmlspecialchars($r['reden']); ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($rows)): ?>
                <tr><td colspan="4" class="small text-muted">Geen ziekmeldingen gevonden.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php layout_footer(); ?>


