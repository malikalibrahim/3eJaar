# Rijschool Management System - Mappenstructuur & Features

## 🎯 Verbeterde Mappenstructuur

```
rijschool_examen/
├── 📄 index.php                          # Inlogpagina (hoofd entry point)
├── 📄 Gebruiker.php                      # Gebruikersbeheer (root)
├── 📄 USER_STORIES.md                    # User stories documentatie
├── 📄 MAPSTRUCTUUR.md                    # Dit bestand
│
├── 📁 includes/                          # Backend classes & utilities
│   ├── Auth.php                          # Authenticatie systeem
│   ├── Auto.php                          # Auto/wagenpark klasse
│   ├── db.php                            # Database connectie
│   ├── Les.php                           # Les management
│   ├── Mededeling.php                    # Mededelingen
│   ├── Pakket.php                        # Lespakketten
│   ├── Ziekmelding.php                   # Ziekmeldingen
│   └── Gebruiker.php                     # Gebruiker klasse
│
├── 📁 user/                              # Shared UI komponenten
│   ├── layout.php                        # Header/Footer template
│   └── logout.php                        # Uitloggen handler
│
├── 📁 leerling/                          # 👨‍🎓 LEERLING FUNCTIES
│   ├── dashboard.php                     # Leerling dashboard
│   ├── leerling-add.php                  # Leerling registratie (admin)
│   ├── leerling-delete.php               # Leerling verwijderen (admin)
│   ├── leerling-view.php                 # Leerlingoverzicht (admin)
│   ├── rooster.php                       # 📅 LESROOSTER (leerling zicht)
│   └── profiel.php                       # Profiel inzien/wijzigen
│
├── 📁 instructeur/                       # 👨‍🏫 INSTRUCTEUR FUNCTIES
│   ├── dashboard.php                     # Instructeur dashboard
│   ├── instructeur-add.php               # Instructeur account aanmaken (admin)
│   ├── instructeur-delete.php            # Instructeur verwijderen (admin)
│   ├── instructeur-view.php              # Instructeuroverzicht (admin)
│   ├── dagrooster.php                    # 📅 DAGROOSTER (instructeur zicht)
│   ├── dagrooster-print.php              # 🖨️ Dagrooster printen
│   ├── weekrooster.php                   # 📅 WEEKROOSTER (instructeur zicht)
│   ├── les-opmerking.php                 # Les opmerkingen toevoegen
│   ├── wagenpark.php                     # 🚗 Auto's voor vandaag zien
│   └── ziek-melden.php                   # 🏥 Naar ziekmeldingspagina
│
├── 📁 Les/                               # 📝 LES MANAGEMENT
│   ├── les-add.php                       # Nieuwe les aanmaken
│   ├── les-delete.php                    # Les verwijderen
│   ├── les-edit.php                      # Les bewerken
│   ├── les-view.php                      # Lesoverzicht
│   ├── les-plannen.php                   # Leerling: Les plannen
│   ├── les-annuleer.php                  # Leerling: Les annuleren
│   └── les-opmerking.php                 # Leerling: Les opmerkingen toevoegen
│
├── 📁 Auto/                              # 🚗 WAGENPARK MANAGEMENT
│   ├── auto-add.php                      # Auto toevoegen
│   ├── auto-delete.php                   # Auto verwijderen
│   ├── auto-maintenance.php              # Auto onderhoud status
│   ├── mankement-add.php                 # Mankement melden (instructeur)
│   ├── auto-assign-instructor.php        # Auto toewijzen aan instructeur (rijschoolhouder)
│   └── auto-view.php                     # Wagenparkoverzicht
│
├── 📁 Mededeling/                        # 📢 MEDEDELINGEN
│   ├── mededeling-add.php                # Nieuwe mededeling
│   ├── mededeling-delete.php             # Mededeling verwijderen
│   └── mededeling-view.php               # Mededelingenoverzicht
│
├── 📁 Pakket/                            # 💳 LESPAKKETTEN (NIEUW)
│   ├── pakket-view.php                   # Pakketoverzicht
│   ├── pakket-add.php                    # Nieuw pakket aanmaken
│   ├── pakket-edit.php                   # Pakket bewerken
│   └── pakket-delete.php                 # Pakket verwijderen
│
├── 📁 Ziek/                              # 🏥 ZIEKMELDINGEN
│   ├── ziek-add.php                      # Ziekmeldingsformulier
│   └── ziek-view.php                     # Ziekmeldingenoverzicht
│
└── 📁 rijschool/                         # 🏢 RIJSCHOOLHOUDER FUNCTIES
    └── dashboard.php                     # Rijschoolhouder dashboard

```

---

## ✅ User Stories - Implementatiestatus

### 1. Inloggen & Registratie
- ✅ Als instructeur moet ik kunnen inloggen (`index.php`, `includes/Auth.php`)
- ✅ Als leerling moet ik kunnen inloggen (`index.php`, `includes/Auth.php`)
- ✅ Als rijschoolhouder moet ik kunnen inloggen (`index.php`, `includes/Auth.php`)
- ✅ Als leerling moet ik me kunnen registreren op de website (`leerling/leerling-add.php`)
- ✅ Als rijschool wil ik een account kunnen aanmaken voor een instructeur (`instructeur/instructeur-add.php`)

### 2. Pagina's & Algemeen Beheer
- 📋 Als rijschool wil ik bedrijfsinformatie kunnen zien op de website (tabel `rijschool` - in `index.php`)
- ✅ Als rijschool wil ik dat alle pagina's op dezelfde wijze zijn vormgegeven (`user/layout.php`)
- 📋 Als rijschoolhouder wil ik dat de website ook op mobiele telefoons werkt (Bootstrap responsive)
- 📋 Als rijschool wil ik de algemene voorwaarden publiceren (apart page nodig)

### 3. Inlogstatus Zichtbaar
- ✅ Als leerling wil ik kunnen zien dat ik ingelogd ben (`user/layout.php` - header toont gebruiker)
- ✅ Als instructeur wil ik kunnen zien dat ik ingelogd ben (`user/layout.php` - header toont gebruiker)
- ✅ Als rijschoolhouder wil ik kunnen zien dat ik ingelogd ben (`user/layout.php` - header toont gebruiker)

### 4. Leerling - Lessen & Rooster
- ✅ Als leerling wil ik mijn lesrooster kunnen zien (`leerling/rooster.php`)
- 📋 Als leerling wil ik een ophaallocatie voor een specifieke les kunnen opgeven
- 📋 Als leerling wil ik een les in kunnen plannen
- ✅ Als leerling wil ik via een formulier een les kunnen annuleren (`Les/les-annuleer.php`)
- ✅ Als leerling wil ik achteraf opmerkingen kunnen toevoegen aan een les (`Les/les-opmerking.php`)

### 5. Leerling - Profiel & Info
- ✅ Als leerling wil ik mijn profiel kunnen inzien en aanpassen (`leerling/profiel.php`)
- 📋 Als leerling wil ik mededelingen voor leerlingen zien (medialen overzicht nodig)

### 6. Leerling - Locatie & Contact
- 📋 Als leerling wil ik de locatie van de rijschool kunnen zien (apart page nodig)
- 📋 Klanten moeten een routebeschrijving kunnen maken naar de locatie (`index.php` - route knop aanwezig)

### 7. Instructeur - Rooster & Planning
- ✅ Als instructeur wil ik een dagrooster kunnen zien (`instructeur/dagrooster.php`)
- ✅ Als instructeur wil ik een weekrooster kunnen zien (`instructeur/weekrooster.php`)
- ✅ Als instructeur wil ik een nieuwe les kunnen aanmaken bij een leerling (`Les/les-add.php`)

### 8. Instructeur - Lessen & Opmerkingen
- ✅ Als instructeur wil ik een les kunnen aanpassen (`Les/les-edit.php`)
- ✅ Als instructeur wil ik achteraf opmerkingen kunnen toevoegen aan een les (`instructeur/les-opmerking.php`)

### 9. Instructeur - Auto's & Onderhoud
- ✅ Als instructeur wil ik kunnen zien met welke auto ik de lessen van die dag verzorg (`instructeur/wagenpark.php`)
- 📋 Als instructeur wil ik mankementen aan een auto kunnen melden
- 📋 Als instructeur wil ik de kilometerstand aan het einde van de lesdag kunnen invoeren

### 10. Instructeur - Ziekte & Print
- ✅ Als instructeur wil ik me via een formulier ziek kunnen melden (`instructeur/ziek-melden.php` → `Ziek/ziek-add.php`)
- ✅ Als instructeur wil ik het dagrooster kunnen printen (`instructeur/dagrooster-print.php`)

### 11. Instructeur - Mededelingen
- 📋 Als instructeur wil ik mededelingen voor instructeurs zien (medialen overzicht nodig)

### 12. Rijschoolhouder - Mededelingen
- ✅ Als rijschoolhouder wil ik mededelingen kunnen doen aan instructeurs en klanten (`Mededeling/mededeling-add.php`)

### 13. Rijschoolhouder - Wagenpark Beheer
- ✅ Als rijschoolhouder wil ik een overzicht van het wagenpark kunnen bekijken (`Auto/auto-view.php`)
- 📋 Als rijschoolhouder wil ik een instructeur een auto kunnen toewijzen
- ✅ Als rijschoolhouder wil ik nieuwe auto's kunnen toevoegen aan het wagenpark (`Auto/auto-add.php`)
- ✅ Als rijschoolhouder wil ik kunnen aangeven welke auto in onderhoud is (`Auto/auto-maintenance.php`)
- ✅ Als rijschoolhouder wil ik een auto kunnen verwijderen uit het wagenpark (`Auto/auto-delete.php`)

### 14. Rijschoolhouder - Lespakketten (NIEUW)
- ✅ Als rijschoolhouder wil ik meerdere lessen kunnen samenstellen voor een vast bedrag
  - `Pakket/pakket-view.php` - Overzicht
  - `Pakket/pakket-add.php` - Nieuw pakket
  - `Pakket/pakket-edit.php` - Bewerken
  - `Pakket/pakket-delete.php` - Verwijderen

---

## 🔧 Gemaakte Wijzigingen

### ✨ Nieuwe Mappen
- ✅ `Pakket/` - Lespakketten management (4 files)

### ✨ Nieuwe Files
- ✅ `instructeur/ziek-melden.php` - Redirect naar ziekmeldingen
- ✅ `Pakket/pakket-view.php` - Pakketoverzicht
- ✅ `Pakket/pakket-add.php` - Nieuw pakket aanmaken
- ✅ `Pakket/pakket-edit.php` - Pakket bewerken
- ✅ `Pakket/pakket-delete.php` - Pakket verwijderen
- ✅ `USER_STORIES.md` - User stories documentatie
- ✅ `MAPSTRUCTUUR.md` - Dit bestand

### 📋 Documenten Aangemaakt
- `USER_STORIES.md` - Alle 42 user stories gecategoriseerd
- `MAPSTRUCTUUR.md` - Volledige mappenstructuur documentatie

---

## 🎨 Design Principes

### Folder Structuur
- **Rollen-gebaseerd**: `leerling/`, `instructeur/`, `rijschool/` - elke rol heeft eigen pages
- **Feature-gebaseerd**: `Auto/`, `Les/`, `Mededeling/`, `Ziek/`, `Pakket/` - gerelateerde functionaliteit bij elkaar
- **Shared**: `user/`, `includes/` - gedeelde componenten en klasses

### URL Patronen
- `/` = Inloggen
- `/leerling/dashboard.php` = Leerling start
- `/instructeur/dashboard.php` = Instructeur start
- `/rijschool/dashboard.php` = Rijschoolhouder start
- `/Auto/auto-view.php` = Auto management
- `/Pakket/pakket-view.php` = Lespakketten management

---

## 📝 Volgende Stappen

### Nog Te Implementeren
1. **Bedrijfsinformatie pagina** - dynamisch laden uit `rijschool` tabel
2. **Mededelingenoverzicht voor leerlingen** - tonen bij inlog
3. **Mededelingenoverzicht voor instructeurs** - tonen bij inlog
4. **Ophaallocatie management** - per les kunnen opgeven
5. **Les plannen** - leerling kan zelf les aanvragen
6. **Auto toewijzing aan instructeurs** - rijschoolhouder functie
7. **Mankementmeldingen** - instructeur kan auto defecten melden
8. **Kilometerstand invoeren** - instructeur dagslot
9. **Algemene voorwaarden pagina** - rijschool statische pagina
10. **Locatie pagina** - rijschool adres + kaart

### Code Quality
- [ ] Input validatie overal toevoegen
- [ ] Error handling verbeteren
- [ ] Security audit (SQL injection, XSS, CSRF)
- [ ] Database transactions toevoegen
- [ ] Logging implementeren

---

## 💡 Tips & Best Practices

### Voor Developers
1. **Layout gebruiken**: Altijd `require_once __DIR__ . "/../user/layout.php"` en `layout_header()` / `layout_footer()`
2. **URL structuur volgen**: Feature mappen gebruiken voor gerelateerde pages
3. **Auth checken**: `$auth->check()` en `$auth->user()` voor role-based access
4. **Database**: Via `DB` klasse werken, prepared statements gebruiken
5. **Error handling**: Try-catch blokken en user-friendly meldingen

### Voor Testers
1. **Rollen testen**: Elke feature met alle 3 rollen testen
2. **Mobile testing**: Bootstrap is responsive, testen op telefoon
3. **Edge cases**: Lege formulieren, speciale karakters, SQL injection pogingen
4. **Performance**: Roosters met veel lessen kunnen traag zijn

---

## 📊 Statistieken

- **Totaal User Stories**: 42+
- **Totaal Directories**: 9 (user/, includes/, leerling/, instructeur/, Les/, Auto/, Mededeling/, Ziek/, Pakket/, rijschool/)
- **Totaal PHP Files**: 40+
- **Ondersteuning van Rollen**: 3 (leerling, instructeur, rijschoolhouder)
- **Features**: Inlog, Lespakketten, Wagenpark, Mededelingen, Ziekmeldingen, Lessen, Roosters, Profielen

---

*Laatste update: December 2025*
