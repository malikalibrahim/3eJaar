<?php
require_once __DIR__ . "/user/layout.php";
require_once __DIR__ . "/includes/db.php";

layout_header('Locatie rijschool');

$db = new DB();
$rijschool = null;
try {
    $rijschool = $db->run("SELECT * FROM rijschool LIMIT 1")->fetch();
} catch (Throwable $e) {
    // tabel bestaat mogelijk niet; we'll show fallback info
    $rijschool = null;
}

$address = '';
if ($rijschool) {
    $address = trim(($rijschool['adres'] ?? '') . ' ' . ($rijschool['postcode'] ?? '') . ' ' . ($rijschool['plaats'] ?? ''));
} else {
    $address = 'Lesstraat 1, 1234 AB, Amsterdam';
}
?>

<div class="card shadow-sm">
    <div class="card-body">
        <h1 class="h5 mb-3">Onze locatie</h1>

        <?php if ($rijschool): ?>
            <p class="mb-1"><strong><?php echo htmlspecialchars($rijschool['naam'] ?? 'Rijschool'); ?></strong></p>
            <p class="small text-muted mb-2"><?php echo htmlspecialchars($address); ?></p>
            <p class="small text-muted mb-3"><?php echo htmlspecialchars($rijschool['beschrijving'] ?? 'Contacteer ons voor meer informatie.'); ?></p>
        <?php else: ?>
            <p class="small text-muted">Adres niet in database ingesteld — hieronder een voorbeeldadres.</p>
        <?php endif; ?>

        <div style="width:100%;height:360px;">
            <iframe
                width="100%" height="100%" frameborder="0" style="border:0"
                src="https://www.google.com/maps?q=<?php echo urlencode($address); ?>&output=embed" allowfullscreen>
            </iframe>
        </div>
    </div>
</div>

<?php layout_footer(); ?>
