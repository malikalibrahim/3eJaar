# 📋 User Stories - Rijschool Management Systeem (42 Stories)

## 🔐 1. AUTHENTIFICATIE (5 stories)
- [x] **US-1.1**: Als instructeur moet ik kunnen inloggen.
  - Lokatie: `index.php`, `includes/Auth.php`
  - Status: ✅ VOLTOOID
  
- [x] **US-1.2**: Als leerling moet ik kunnen inloggen.
  - Lokatie: `index.php`, `includes/Auth.php`
  - Status: ✅ VOLTOOID
  
- [x] **US-1.3**: Als rijschoolhouder moet ik kunnen inloggen.
  - Lokatie: `index.php`, `includes/Auth.php`
  - Status: ✅ VOLTOOID
  
- [x] **US-1.4**: Als leerling moet ik me kunnen registreren op de website.
  - Lokatie: `leerling/leerling-add.php`
  - Status: ✅ VOLTOOID
  
- [x] **US-1.5**: Als rijschool wil ik een account kunnen aanmaken voor een instructeur.
  - Lokatie: `instructeur/instructeur-add.php`
  - Status: ✅ VOLTOOID

---

## 🎨 2. PAGINA'S & GENERAL BEHEER (4 stories)
 - [x] **US-2.1**: Als rijschool wil ik bedrijfsinformatie (eigenaar, medewerkers, doelstellingen) kunnen zien op de website.
  - Lokatie: `locatie.php` (dynamisch laden uit tabel `rijschool` indien aanwezig)
  - Status: ✅ VOLTOOID (pagina toont fallback adres als tabel ontbreekt)
  - Opmerkingen: Als tabel `rijschool` gevuld is, zal de pagina dynamisch tonen wat er in de database staat.
  
- [x] **US-2.2**: Als rijschool wil ik dat alle pagina's op dezelfde wijze zijn vormgegeven.
  - Lokatie: `user/layout.php` (Bootstrap template)
  - Status: ✅ VOLTOOID
  
- [x] **US-2.3**: Als rijschoolhouder wil ik dat de website ook op mobiele telefoons werkt.
  - Lokatie: Bootstrap responsive design overal
  - Status: ✅ VOLTOOID (Bootstrap 5 gebruikt)
  
 - [x] **US-2.4**: Als rijschool wil ik de algemene voorwaarden publiceren.
  - Lokatie: `voorwaarden.php`
  - Status: ✅ VOLTOOID

---

## 👁️ 3. INLOGSTATUS ZICHTBAAR (3 stories)
- [x] **US-3.1**: Als leerling wil ik kunnen zien dat ik ingelogd ben.
  - Lokatie: `user/layout.php` (toont gebruikersnaam in header)
  - Status: ✅ VOLTOOID
  
- [x] **US-3.2**: Als instructeur wil ik kunnen zien dat ik ingelogd ben.
  - Lokatie: `user/layout.php` (toont gebruikersnaam in header)
  - Status: ✅ VOLTOOID
  
- [x] **US-3.3**: Als rijschoolhouder wil ik kunnen zien dat ik ingelogd ben.
  - Lokatie: `user/layout.php` (toont gebruikersnaam in header)
  - Status: ✅ VOLTOOID

---

## 👨‍🎓 4. LEERLING - LESSEN & ROOSTER (5 stories)
- [x] **US-4.1**: Als leerling wil ik mijn lesrooster kunnen zien (inclusief ophaallocatie, te behandelen onderdeel, opmerkingen instructeur).
  - Lokatie: `leerling/rooster.php`
  - Status: ✅ VOLTOOID
  
- [ ] **US-4.2**: Als leerling wil ik een ophaallocatie voor een specifieke les kunnen opgeven.
  - Lokatie: `leerling/les-edit-pickup.php` (NIEUW NODIG)
  - Status: 📋 TE DOEN
  - Dependencies: Database veld `ophaallocatie` in tabel `les`
  
- [x] **US-4.3**: Als leerling wil ik een les in kunnen plannen.
  - Lokatie: `Les/les-plannen.php`
  - Status: ✅ VOLTOOID
  - Dependencies: Beschikbare sloten moeten worden uitgebreid (optioneel)
  
- [x] **US-4.4**: Als leerling wil ik via een formulier een les kunnen annuleren, inclusief de reden.
  - Lokatie: `Les/les-annuleer.php`
  - Status: ✅ VOLTOOID
  
- [x] **US-4.5**: Als leerling wil ik achteraf opmerkingen kunnen toevoegen aan een les.
  - Lokatie: `Les/les-opmerking.php`
  - Status: ✅ VOLTOOID

---

## 📝 5. LEERLING - PROFIEL & INFO (2 stories)
- [x] **US-5.1**: Als leerling wil ik mijn profiel kunnen inzien en aanpassen.
  - Lokatie: `leerling/profiel.php`
  - Status: ✅ VOLTOOID
  
 - [x] **US-5.2**: Als leerling wil ik, als ik ingelogd ben, mededelingen voor leerlingen zien.
  - Lokatie: `leerling/dashboard.php` (mededelingen widget toegevoegd)
  - Status: ✅ VOLTOOID
  - Dependencies: Query mededelingen voor leerlingen (rol filter)

---

## 🗺️ 6. LEERLING - LOCATIE & CONTACT (2 stories)
 - [x] **US-6.1**: Als leerling wil ik de locatie van de rijschool kunnen zien.
  - Lokatie: `locatie.php`
  - Status: ✅ VOLTOOID (iframe kaart + DB-fallback)
  - Dependencies: Tabel `rijschool` met adres + lat/lng coördinaten (optioneel)
  
- [x] **US-6.2**: Klanten moeten een routebeschrijving kunnen maken naar de locatie.
  - Lokatie: `index.php` (routeknop aanwezig naar Google Maps)
  - Status: ✅ VOLTOOID

---

## 👨‍🏫 7. INSTRUCTEUR - ROOSTER & PLANNING (3 stories)
- [x] **US-7.1**: Als instructeur wil ik een dagrooster kunnen zien (met per les: ophaallocatie, naam leerling, onderwerp).
  - Lokatie: `instructeur/dagrooster.php`
  - Status: ✅ VOLTOOID
  
- [x] **US-7.2**: Als instructeur wil ik een weekrooster kunnen zien.
  - Lokatie: `instructeur/weekrooster.php`
  - Status: ✅ VOLTOOID
  
- [x] **US-7.3**: Als instructeur wil ik een nieuwe les kunnen aanmaken bij een leerling.
  - Lokatie: `Les/les-add.php`
  - Status: ✅ VOLTOOID

---

## ✏️ 8. INSTRUCTEUR - LESSEN & OPMERKINGEN (2 stories)
- [x] **US-8.1**: Als instructeur wil ik een les kunnen aanpassen.
  - Lokatie: `Les/les-edit.php`
  - Status: ✅ VOLTOOID
  
- [x] **US-8.2**: Als instructeur wil ik achteraf opmerkingen kunnen toevoegen aan een les.
  - Lokatie: `instructeur/les-opmerking.php`
  - Status: ✅ VOLTOOID

---

## 🚗 9. INSTRUCTEUR - AUTO'S & ONDERHOUD (3 stories)
- [x] **US-9.1**: Als instructeur wil ik kunnen zien met welke auto ik de lessen van die dag verzorg.
  - Lokatie: `instructeur/wagenpark.php`
  - Status: ✅ VOLTOOID
  
- [x] **US-9.2**: Als instructeur wil ik mankementen aan een auto kunnen melden.
  - Lokatie: `Auto/mankement-add.php`
  - Status: ✅ VOLTOOID (eenvoudige UI toegevoegd)
  - Dependencies: Database tabel `auto_mankement` (insert via `includes/Auto.php`)
  
 - [x] **US-9.3**: Als instructeur wil ik de kilometerstand aan het einde van de lesdag kunnen invoeren.
  - Lokatie: `instructeur/kilometres-register.php`
  - Status: ✅ VOLTOOID (back-end + eenvoudige UI toegevoegd)
  - Dependencies: Database tabel `auto_kilometerstand` (insert via `includes/Auto.php`)

---

## 🏥 10. INSTRUCTEUR - ZIEKTE & PRINT (2 stories)
- [x] **US-10.1**: Als instructeur wil ik me via een formulier ziek kunnen melden.
  - Lokatie: `instructeur/ziek-melden.php` → `Ziek/ziek-add.php`
  - Status: ✅ VOLTOOID
  
- [x] **US-10.2**: Als instructeur wil ik het dagrooster kunnen printen (zonder menu, afbeeldingen, etc.).
  - Lokatie: `instructeur/dagrooster-print.php`
  - Status: ✅ VOLTOOID

---

## 📢 11. INSTRUCTEUR - MEDEDELINGEN (1 story)
 - [x] **US-11.1**: Als instructeur wil ik, als ik ingelogd ben, mededelingen voor instructeurs zien.
  - Lokatie: `instructeur/dashboard.php` (mededelingen widget toegevoegd)
  - Status: ✅ VOLTOOID
  - Dependencies: Query mededelingen voor instructeurs (rol filter)

---

## 🔊 12. RIJSCHOOLHOUDER - MEDEDELINGEN (1 story)
- [x] **US-12.1**: Als rijschoolhouder wil ik mededelingen kunnen doen aan instructeurs en klanten.
  - Lokatie: `Mededeling/mededeling-add.php`
  - Status: ✅ VOLTOOID

---

## 🚙 13. RIJSCHOOLHOUDER - WAGENPARK BEHEER (5 stories)
- [x] **US-13.1**: Als rijschoolhouder wil ik een overzicht van het wagenpark kunnen bekijken.
  - Lokatie: `Auto/auto-view.php`
  - Status: ✅ VOLTOOID
  
- [x] **US-13.2**: Als rijschoolhouder wil ik een instructeur een auto kunnen toewijzen.
  - Lokatie: `Auto/auto-assign-instructor.php`
  - Status: ✅ VOLTOOID (eenvoudige toewijzing UI toegevoegd)
  - Dependencies: Database tabel `auto_toewijzing` (insert via `includes/Auto.php`)
  
- [x] **US-13.3**: Als rijschoolhouder wil ik nieuwe auto's kunnen toevoegen aan het wagenpark.
  - Lokatie: `Auto/auto-add.php`
  - Status: ✅ VOLTOOID
  
- [x] **US-13.4**: Als rijschoolhouder wil ik kunnen aangeven welke auto in onderhoud is.
  - Lokatie: `Auto/auto-maintenance.php`
  - Status: ✅ VOLTOOID
  
- [x] **US-13.5**: Als rijschoolhouder wil ik een auto kunnen verwijderen uit het wagenpark.
  - Lokatie: `Auto/auto-delete.php`
  - Status: ✅ VOLTOOID

---

## 💳 14. RIJSCHOOLHOUDER - LESPAKKETTEN (1 story) ⭐ NIEUW
- [x] **US-14.1**: Als rijschoolhouder wil ik meerdere lessen kunnen samenstellen voor een vast bedrag.
  - Lokatie: `Pakket/pakket-view.php`, `pakket-add.php`, `pakket-edit.php`, `pakket-delete.php`
  - Status: ✅ VOLTOOID
  - Opmerking: Volledig werkend systeem voor lespakketten

---

## 📊 SAMENVATTINGSSTATISTIEKEN

| Categorie | Stories | Voltooid | In Progress | Te Doen |
|-----------|---------|----------|------------|---------|
| Authenticatie | 5 | 5 | 0 | 0 |
| Pagina's & General | 4 | 2 | 0 | 2 |
| Inlogstatus | 3 | 3 | 0 | 0 |
| Leerling - Rooster | 5 | 3 | 0 | 2 |
| Leerling - Profiel | 2 | 1 | 0 | 1 |
| Leerling - Locatie | 2 | 1 | 0 | 1 |
| Instructeur - Rooster | 3 | 3 | 0 | 0 |
| Instructeur - Lessen | 2 | 2 | 0 | 0 |
| Instructeur - Auto's | 3 | 1 | 0 | 2 |
| Instructeur - Ziekte/Print | 2 | 2 | 0 | 0 |
| Instructeur - Mededelingen | 1 | 0 | 0 | 1 |
| Rijschoolhouder - Mededelingen | 1 | 1 | 0 | 0 |
| Rijschoolhouder - Wagenpark | 5 | 4 | 0 | 1 |
| Rijschoolhouder - Pakketten | 1 | 1 | 0 | 0 |
| **TOTAAL** | **42** | **28** | **0** | **14** |

---

## 🗂️ MAPPENSTRUCTUUR OVERZICHT

```
rijschool_examen/
├── 📁 includes/           → Backend klasses & utilities
├── 📁 user/               → Shared UI templates
├── 📁 leerling/           → 👨‍🎓 Leerling pages
├── 📁 instructeur/        → 👨‍🏫 Instructeur pages
├── 📁 Les/                → Lessen management
├── 📁 Auto/               → 🚗 Wagenpark management
├── 📁 Mededeling/         → 📢 Mededelingen
├── 📁 Ziek/               → 🏥 Ziekmeldingen
├── 📁 Pakket/             → 💳 Lespakketten (⭐ NIEUW)
├── 📁 rijschool/          → 🏢 Rijschoolhouder pages
├── index.php              → Inlogpagina (hoofd entry point)
├── USER_STORIES.md        → Dit bestand
└── MAPSTRUCTUUR.md        → Detailgids mappenstructuur
```

---

## ✅ RECENTE IMPLEMENTATIES (Sessie December 2025)

### ✨ Gemaakte Items
1. **Pakket Management Systeem** (⭐ NIEUW)
   - `Pakket/pakket-view.php` - Overzicht
   - `Pakket/pakket-add.php` - Toevoegen
   - `Pakket/pakket-edit.php` - Bewerken
   - `Pakket/pakket-delete.php` - Verwijderen

2. **Instructeur Ziekmelden Link**
   - `instructeur/ziek-melden.php` - Redirect naar ziekmeldingen

3. **Documentatie**
   - `USER_STORIES.md` - Dit bestand (geïmporteerd & gestructureerd)
   - `MAPSTRUCTUUR.md` - Volledige structuur gids

---

## 🚀 PRIORITEIT VOLGENDE IMPLEMENTATIE

### 🔴 KRITIEK (voor MVP):
1. [ ] Ophaallocatie per les (leerling kan pickup bewerken) — `Les/les-edit-pickup.php`
2. [ ] Input validatie & security hardening (CSRF, XSS, SQLi)

### 🟡 BELANGRIJK:
3. [ ] Verbeter beschikbaarheidslogica (voorkom double-booking van tijdsloten)
4. [ ] Admin UI voor `rijschool`-gegevens (vult `locatie.php` dynamisch)

### 🟢 OPTIONEEL:
5. [ ] Verwijderen of beschermen van dev-tools (`setup.php`, `user_admin.php`)
6. [ ] Extra UX: notificaties/mededelingen widgets verfijnen

---

*Geëxporteerde & gereorganiseerde user stories - December 2025*
