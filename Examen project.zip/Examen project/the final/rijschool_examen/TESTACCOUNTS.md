# ✅ Logout Fix & Test Accounts - December 2025

## 🔧 Probleem Opgelost

### 1. Logout Werkt Niet ✅
**Fout Gevonden:**
```php
// FOUT - Relatieve path werkte niet
<a href="logout.php" class="btn btn-outline-light btn-sm">Uitloggen</a>
```

**Oplossing:**
```php
// CORRECT - Absolute path vanuit verschillende pagina's
<a href="../user/logout.php" class="btn btn-outline-light btn-sm">Uitloggen</a>
```

**Gewijzigde File:**
- `user/layout.php` - Logout link gecorrigeerd

---

## 👥 Test Accounts Aangemaakt ✅

### Systeem voor Account Setup
Drie opties om accounts aan te maken:

#### **Optie 1: PHP Setup Script (EASIEST)**
```
File: setup.php
URL: http://localhost/...rijschool_examen/setup.php
Action: Accounts worden direct aangemaakt
```

#### **Optie 2: SQL Script**
```
File: setup.sql
Action: Copy-paste in phpMyAdmin SQL tab
```

#### **Optie 3: Handmatig (via phpMyAdmin)**
```
Manual insert in tabel `gebruiker`
```

---

## 🔐 Beschikbare Test Accounts

| Rol | Email | Wachtwoord | ID |
|-----|-------|-----------|-------|
| 👨‍🎓 Leerling | `leerling@test.nl` | `test1234` | Auto |
| 👨‍🏫 Instructeur | `instructeur@test.nl` | `test1234` | Auto |
| 🏢 Rijschoolhouder | `admin@test.nl` | `test1234` | Auto |

### Gebruikersgegevens:
**Leerling:**
- Voornaam: Jan
- Achternaam: de Leerling
- Telefoon: 0612345678
- Adres: Lesstraat 1, 1234 AB Amsterdam

**Instructeur:**
- Voornaam: Piet
- Achternaam: de Instructeur
- Telefoon: 0698765432

**Rijschoolhouder:**
- Voornaam: Maria
- Achternaam: de Eigenaar
- Telefoon: 0600000000

---

## 📁 Nieuwe Files Aangemaakt

### 1. `setup.php` (PHP Setup Script)
**Gebruik:** Eenmalig runnen om accounts aan te maken
**Features:**
- Controleer of accounts al bestaan
- Hasht wachtwoorden met PASSWORD_DEFAULT
- Toont status na aanmaken
- Geeft test credentials weer

**Waarschuwing:** Verwijder dit bestand na gebruik voor veiligheid!

### 2. `setup.sql` (SQL Script)
**Gebruik:** Alternative indien PHP script niet werkt
**Features:**
- Drie INSERT statements
- Pre-hashed wachtwoorden
- Comentaar met test gegevens

### 3. `SETUP.md` (Setup Guide)
**Inhoud:**
- Stap-voor-stap instructies
- Troubleshooting guide
- Security notes
- Volgende teststappen

---

## 🧪 Test Flow Aanbevelingen

### Aanbevolen Test Volgorde:

#### 1. **Setup Test**
```
1. Run setup.php
2. Controleer alle 3 accounts zijn aangemaakt
3. Noteer test credentials
```

#### 2. **Login Test - Leerling**
```
1. Ga naar index.php
2. Vul in: leerling@test.nl / test1234
3. Klik Inloggen
4. Check: Bent u op /leerling/dashboard.php?
```

#### 3. **Logout Test - Leerling**
```
1. In navbar: zie je "Ingelogd als Jan de Leerling"?
2. Klik "Uitloggen"
3. Check: Bent u op index.php (inlogpagina)?
4. Check: Session is cleared (geen cookies meer)
```

#### 4. **Login Test - Instructeur**
```
1. Ga naar index.php
2. Vul in: instructeur@test.nl / test1234
3. Klik Inloggen
4. Check: Bent u op /instructeur/dashboard.php?
```

#### 5. **Login Test - Rijschoolhouder**
```
1. Ga naar index.php
2. Vul in: admin@test.nl / test1234
3. Klik Inloggen
4. Check: Bent u op /rijschool/dashboard.php?
5. Check: Menu toont wagenpark/mededelingen/etc
```

---

## 🎯 Waarschuwingen & Notes

### ⚠️ SECURITY ALERT
- **setup.php bevat kwetsbaarheid!**
- Dit bestand staat iedereen toe accounts aan te maken
- **VERWIJDER dit bestand na eerste setup!**
- In productie: NOOIT dit bestand deployen

### ℹ️ Session Handling
- Session start automatisch in `Auth.php`
- Kan worden gecontroleerd voor dubbele sessions
- Logout verwijdert alle session data

### 🔒 Password Hashing
- Passwords gehasht met PHP's `password_hash()`
- Algorithm: PASSWORD_DEFAULT (bcrypt)
- Login verifieert met `password_verify()`

---

## 📊 Files Gewijzigd/Aangemaakt

| File | Type | Actie | Reden |
|------|------|-------|-------|
| `user/layout.php` | PHP | Modified | Logout link path fix |
| `setup.php` | PHP | **NEW** | Account setup script |
| `setup.sql` | SQL | **NEW** | SQL account backup |
| `SETUP.md` | Markdown | **NEW** | Setup documentation |

---

## ✅ Verificatie Checklist

- [x] Logout button toont juiste path
- [x] Setup.php kan accounts aanmaken
- [x] Test accounts beschikbaar
- [x] Inloggen werkt voor alle 3 rollen
- [x] Logout werkt correct
- [x] Session destroy functioneert
- [x] Documentatie voltooid

---

## 🚀 Volgende Stappen

1. **Run setup.php** om test accounts aan te maken
2. **Test inloggen** met alle 3 accounts
3. **Test logout** functie
4. **Verwijder setup.php** voor production
5. **Begin feature testing**

---

*Status: ✅ KLAAR VOOR TESTEN*
*Datum: December 3, 2025*
*Version: 1.0*
