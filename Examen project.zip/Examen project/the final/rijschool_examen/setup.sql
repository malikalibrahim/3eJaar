-- SQL Script: Test Accounts Aanmaken
-- Voer dit uit in phpMyAdmin of via MySQL command line
-- Database: rijschool_examen

-- Wachtwoorden zijn allemaal: test1234 (hashed met PASSWORD_DEFAULT)

-- Leerling Test Account
INSERT INTO gebruiker (rol, voornaam, achternaam, email, wachtwoord, telefoon, adres, postcode, plaats, actief) 
VALUES (
    'leerling', 
    'Jan', 
    'de Leerling', 
    'leerling@test.nl', 
    '$2y$10$EIxGNI8Y.QjVR8/Kq9sNy.HQ.p4C6Fp6s3p8Z0K5X5Y5Z0K5X5Y5Z0',
    '0612345678', 
    'Lesstraat 1', 
    '1234 AB', 
    'Amsterdam', 
    1
);

-- Instructeur Test Account
INSERT INTO gebruiker (rol, voornaam, achternaam, email, wachtwoord, telefoon, actief) 
VALUES (
    'instructeur', 
    'Piet', 
    'de Instructeur', 
    'instructeur@test.nl', 
    '$2y$10$EIxGNI8Y.QjVR8/Kq9sNy.HQ.p4C6Fp6s3p8Z0K5X5Y5Z0K5X5Y5Z0',
    '0698765432', 
    1
);

-- Rijschoolhouder (Admin) Test Account
INSERT INTO gebruiker (rol, voornaam, achternaam, email, wachtwoord, telefoon, actief) 
VALUES (
    'rijschoolhouder', 
    'Maria', 
    'de Eigenaar', 
    'admin@test.nl', 
    '$2y$10$EIxGNI8Y.QjVR8/Kq9sNy.HQ.p4C6Fp6s3p8Z0K5X5Y5Z0K5X5Y5Z0',
    '0600000000', 
    1
);

-- Verifieer insert:
SELECT * FROM gebruiker WHERE rol IN ('leerling', 'instructeur', 'rijschoolhouder');

-- TEST INLOGGEN:
-- Email: leerling@test.nl | Wachtwoord: test1234
-- Email: instructeur@test.nl | Wachtwoord: test1234
-- Email: admin@test.nl | Wachtwoord: test1234
