<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Auto.php";
require_once __DIR__ . "/../includes/db.php";

// Alleen rijschoolhouder mag auto's toewijzen
global $user;
if (($user['rol'] ?? '') !== 'rijschoolhouder') {
    header('HTTP/1.1 403 Forbidden');
    echo 'Toegang geweigerd.';
    exit;
}

$autoRepo = new AutoRepo();
$db = new DB();
$error = null;
$success = null;

// haal actieve auto's en instructeurs
$autos = $autoRepo->alleAutos();
$instructeurs = $db->run("SELECT id, voornaam, achternaam FROM gebruiker WHERE rol = 'instructeur' AND actief = 1 ORDER BY achternaam, voornaam")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $autoId = isset($_POST['auto_id']) ? (int)$_POST['auto_id'] : 0;
    $instrId = isset($_POST['instructeur_id']) ? (int)$_POST['instructeur_id'] : 0;
    $start = $_POST['startdatum'] ?? date('Y-m-d');
    $eind = trim($_POST['einddatum'] ?? '');

    if ($autoId <= 0 || $instrId <= 0 || !$start) {
        $error = 'Selecteer auto, instructeur en startdatum.';
    } else {
        try {
            $autoRepo->koppelAanInstructeur($autoId, $instrId, $start, $eind !== '' ? $eind : null);
            $success = 'Auto succesvol toegewezen.';
        } catch (Throwable $e) {
            $error = 'Kon toewijzing niet opslaan: ' . $e->getMessage();
        }
    }
}

layout_header('Auto toewijzen aan instructeur');
?>

<div class="row">
    <div class="col-lg-8">
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h1 class="h5 mb-3">Auto toewijzen</h1>

                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>

                <form method="post" class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label small">Auto</label>
                        <select name="auto_id" class="form-select" required>
                            <option value="">Kies een auto</option>
                            <?php foreach ($autos as $a): ?>
                                <option value="<?php echo (int)$a['id']; ?>"><?php echo htmlspecialchars($a['kenteken'] . ' — ' . $a['merk'] . ' ' . $a['type']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small">Instructeur</label>
                        <select name="instructeur_id" class="form-select" required>
                            <option value="">Kies een instructeur</option>
                            <?php foreach ($instructeurs as $i): ?>
                                <option value="<?php echo (int)$i['id']; ?>"><?php echo htmlspecialchars($i['achternaam'] . ', ' . $i['voornaam']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label small">Startdatum</label>
                        <input type="date" name="startdatum" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label small">Einddatum (optioneel)</label>
                        <input type="date" name="einddatum" class="form-control">
                    </div>

                    <div class="col-12 text-end">
                        <button class="btn btn-primary btn-sm">Toewijzen</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h6 class="mb-2">Uitleg</h6>
                <p class="small text-muted">Wijs een auto toe aan een instructeur voor een bepaalde periode. Laat einddatum leeg voor onbepaalde tijd.</p>
            </div>
        </div>
    </div>
</div>

<?php layout_footer(); ?>
