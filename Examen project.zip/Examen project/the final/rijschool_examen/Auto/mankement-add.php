<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Auto.php";

// Alleen instructeurs en rijschoolhouder mogen mankementen melden
global $user;
if (!in_array($user['rol'] ?? '', ['instructeur', 'rijschoolhouder'], true)) {
    header('HTTP/1.1 403 Forbidden');
    echo 'Toegang geweigerd.';
    exit;
}

$autoRepo = new AutoRepo();
$msg = null;
$err = null;

// Als instructeur, toon toegewezen auto voor vandaag, anders alle actieve autos
$today = date('Y-m-d');
$autos = [];
if ($user['rol'] === 'instructeur') {
    $assigned = $autoRepo->autoVoorInstructeurVandaag((int)$user['id'], $today);
    if ($assigned) $autos[] = $assigned;
} else {
    $autos = $autoRepo->alleAutos();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $autoId = isset($_POST['auto_id']) ? (int)$_POST['auto_id'] : 0;
    $datum = $_POST['datum'] ?? date('Y-m-d');
    $beschrijving = trim($_POST['beschrijving'] ?? '');

    if ($autoId <= 0 || $beschrijving === '') {
        $err = 'Selecteer een auto en vul een beschrijving in.';
    } else {
        try {
            $autoRepo->meldMankement($autoId, (int)$user['id'], $datum, $beschrijving);
            $msg = 'Mankement succesvol gerapporteerd.';
        } catch (Throwable $e) {
            $err = 'Kon mankement niet opslaan: ' . $e->getMessage();
        }
    }
}

layout_header('Mankement melden');
?>

<div class="row">
    <div class="col-lg-8">
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h1 class="h5 mb-3">Mankement melden</h1>

                <?php if ($msg): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div>
                <?php endif; ?>
                <?php if ($err): ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars($err); ?></div>
                <?php endif; ?>

                <form method="post">
                    <div class="mb-3">
                        <label class="form-label">Auto</label>
                        <select name="auto_id" class="form-select" required>
                            <option value="">-- selecteer --</option>
                            <?php foreach ($autos as $a): ?>
                                <option value="<?php echo (int)$a['id']; ?>"><?php echo htmlspecialchars($a['kenteken'] . ' — ' . $a['merk'] . ' ' . $a['type']); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (empty($autos)): ?>
                            <div class="small text-muted mt-1">Geen auto's beschikbaar.</div>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Datum</label>
                        <input type="date" name="datum" class="form-control" value="<?php echo htmlspecialchars($today); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Beschrijving van het mankement</label>
                        <textarea name="beschrijving" rows="4" class="form-control" required></textarea>
                    </div>

                    <button class="btn btn-primary">Melden</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h6 class="mb-2">Instructie</h6>
                <p class="small text-muted">Beschrijf kort het probleem en voeg de datum toe. De rijschoolhouder ontvangt de melding en kan actie ondernemen.</p>
            </div>
        </div>
    </div>
</div>

<?php layout_footer(); ?>
