<?php
require_once __DIR__ . "/user/layout.php";

layout_header('Algemene voorwaarden');
?>

<div class="card shadow-sm">
    <div class="card-body">
        <h1 class="h5 mb-3">Algemene Voorwaarden</h1>
        <p class="small text-muted">Hieronder vind je de algemene voorwaarden van de rijschool. Pas deze tekst aan naar jouw juridische vereisten.</p>

        <h2 class="h6 mt-3">1. Diensten</h2>
        <p class="small text-muted">Onze rijschool verleent rijlessen en praktijkbegeleiding conform de geldende wet- en regelgeving.</p>

        <h2 class="h6 mt-3">2. Betaling</h2>
        <p class="small text-muted">Betaling dient te geschieden volgens de overeengekomen voorwaarden en tarieven.</p>

        <h2 class="h6 mt-3">3. Annulering</h2>
        <p class="small text-muted">Annuleringen dienen tijdig te gebeuren; voor meer informatie zie de annuleringsregelingen.</p>

        <h2 class="h6 mt-3">4. Aansprakelijkheid</h2>
        <p class="small text-muted">De rijschool is slechts aansprakelijk volgens de wettelijke bepalingen.</p>

        <p class="small text-muted mt-4">Deze voorwaarden zijn een voorbeeld. Raadpleeg een jurist voor geldige voorwaarden voor jouw bedrijf.</p>
    </div>
</div>

<?php layout_footer(); ?>
