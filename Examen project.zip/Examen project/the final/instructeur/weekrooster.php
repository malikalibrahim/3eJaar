<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Les.php";

layout_header("Weekrooster");

$auth    = new Auth();
$user    = $auth->user();
$lesRepo = new Les();

$start = $_GET['start'] ?? date('Y-m-d', strtotime('monday this week'));
$eind  = date('Y-m-d', strtotime($start . ' +6 days'));
$lessen = $lesRepo->weekroosterInstructeur((int)$user['id'], $start, $eind);
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h5 mb-0">Weekrooster <?php echo htmlspecialchars($start); ?> t/m <?php echo htmlspecialchars($eind); ?></h1>
    <div>
        <a href="weekrooster.php?start=<?php echo date('Y-m-d', strtotime($start . ' -7 days')); ?>" class="btn btn-outline-secondary btn-sm">&laquo; Vorige week</a>
        <a href="weekrooster.php?start=<?php echo date('Y-m-d', strtotime('monday this week')); ?>" class="btn btn-outline-secondary btn-sm">Deze week</a>
        <a href="weekrooster.php?start=<?php echo date('Y-m-d', strtotime($start . ' +7 days')); ?>" class="btn btn-outline-secondary btn-sm">Volgende week &raquo;</a>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <table class="table table-sm align-middle">
            <thead>
            <tr>
                <th>Datum</th>
                <th>Tijd</th>
                <th>Leerling</th>
                <th>Ophaallocatie</th>
                <th>Onderwerp</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($lessen as $l): ?>
                <tr>
                    <td><?php echo htmlspecialchars($l['datum']); ?></td>
                    <td><?php echo htmlspecialchars($l['starttijd'] . ' - ' . $l['eindtijd']); ?></td>
                    <td><?php echo htmlspecialchars(trim(($l['voornaam'] ?? '') . ' ' . ($l['achternaam'] ?? ''))); ?></td>
                    <td><?php echo htmlspecialchars($l['ophaallocatie']); ?></td>
                    <td><?php echo htmlspecialchars($l['onderwerp']); ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($lessen)): ?>
                <tr><td colspan="5" class="small text-muted">Geen lessen in deze week.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php layout_footer(); ?>


