<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Les.php";

layout_header("Opmerking bij les");

$auth    = new Auth();
$user    = $auth->user();
$lesRepo = new Les();

$id   = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$les  = $id > 0 ? $lesRepo->findById($id) : null;
$msg  = null;
$err  = null;

if (!$les || $les['instructeur_id'] != $user['id']) {
    $err = "Les niet gevonden of niet aan jou gekoppeld.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$err) {
    $opm = trim($_POST['opmerking'] ?? '');
    try {
        $lesRepo->opslaanOpmerkingInstructeur($id, $opm);
        $msg = "Opmerking opgeslagen.";
        $les = $lesRepo->findById($id);
    } catch (Throwable $e) {
        $err = "Kon opmerking niet opslaan: " . $e->getMessage();
    }
}
?>

<div class="card shadow-sm">
    <div class="card-body">
        <h1 class="h5 mb-3">Opmerking bij les</h1>

        <?php if ($err): ?>
            <div class="alert alert-danger py-2 small"><?php echo htmlspecialchars($err); ?></div>
        <?php endif; ?>
        <?php if ($msg): ?>
            <div class="alert alert-success py-2 small"><?php echo htmlspecialchars($msg); ?></div>
        <?php endif; ?>

        <?php if ($les && !$err): ?>
            <p class="small text-muted mb-2">
                Les op <strong><?php echo htmlspecialchars($les['datum']); ?></strong>
                om <strong><?php echo htmlspecialchars($les['starttijd']); ?></strong>,
                onderwerp: <?php echo htmlspecialchars($les['onderwerp']); ?>
            </p>
            <form method="POST" class="row g-3">
                <div class="col-12">
                    <label class="form-label small">Opmerking instructeur</label>
                    <textarea name="opmerking" rows="3" class="form-control"><?php echo htmlspecialchars($les['opmerking_instructeur'] ?? ''); ?></textarea>
                </div>
                <div class="col-12 d-flex justify-content-between">
                    <a href="dagrooster.php" class="btn btn-outline-secondary btn-sm">Terug naar dagrooster</a>
                    <button class="btn btn-primary btn-sm">Opslaan</button>
                </div>
            </form>
        <?php endif; ?>
    </div>
</div>

<?php layout_footer(); ?>


