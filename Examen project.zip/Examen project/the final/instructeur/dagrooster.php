<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Les.php";

layout_header("Dagrooster");

$auth    = new Auth();
$user    = $auth->user();
$lesRepo = new Les();

$datum = $_GET['datum'] ?? date('Y-m-d');
$lessen = $lesRepo->dagroosterInstructeur((int)$user['id'], $datum);
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h5 mb-0">Dagrooster <?php echo htmlspecialchars($datum); ?></h1>
    <div>
        <a href="dagrooster.php?datum=<?php echo date('Y-m-d', strtotime($datum . ' -1 day')); ?>" class="btn btn-outline-secondary btn-sm">&laquo; Vorige dag</a>
        <a href="dagrooster.php?datum=<?php echo date('Y-m-d'); ?>" class="btn btn-outline-secondary btn-sm">Vandaag</a>
        <a href="dagrooster.php?datum=<?php echo date('Y-m-d', strtotime($datum . ' +1 day')); ?>" class="btn btn-outline-secondary btn-sm">Volgende dag &raquo;</a>
        <a href="dagrooster-print.php?datum=<?php echo htmlspecialchars($datum); ?>" class="btn btn-outline-primary btn-sm" target="_blank">Printversie</a>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <table class="table table-sm align-middle">
            <thead>
            <tr>
                <th>Tijd</th>
                <th>Leerling</th>
                <th>Ophaallocatie</th>
                <th>Onderwerp</th>
                <th>Opmerking leerling</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($lessen as $l): ?>
                <tr>
                    <td><?php echo htmlspecialchars($l['starttijd'] . ' - ' . $l['eindtijd']); ?></td>
                    <td><?php echo htmlspecialchars(trim(($l['voornaam'] ?? '') . ' ' . ($l['achternaam'] ?? ''))); ?></td>
                    <td><?php echo htmlspecialchars($l['ophaallocatie']); ?></td>
                    <td><?php echo htmlspecialchars($l['onderwerp']); ?></td>
                    <td><?php echo htmlspecialchars($l['opmerking_leerling']); ?></td>
                    <td class="text-end">
                        <a href="les-opmerking.php?id=<?php echo (int)$l['id']; ?>" class="btn btn-outline-secondary btn-sm">Mijn opmerking</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($lessen)): ?>
                <tr><td colspan="6" class="small text-muted">Geen lessen op deze dag.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php layout_footer(); ?>


