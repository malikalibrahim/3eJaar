<?php
require_once __DIR__ . "/../includes/Les.php";
require_once __DIR__ . "/../includes/Auth.php";

$auth    = new Auth();
$user    = $auth->user();
$lesRepo = new Les();

$datum = $_GET['datum'] ?? date('Y-m-d');
$lessen = $lesRepo->dagroosterInstructeur((int)$user['id'], $datum);
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Dagrooster <?php echo htmlspecialchars($datum); ?></title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        h1 { font-size: 16px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #000; padding: 4px; }
        th { text-align: left; }
        @media print {
            button { display: none; }
        }
    </style>
</head>
<body>
<h1>Dagrooster <?php echo htmlspecialchars($datum); ?> – <?php echo htmlspecialchars($user['naam']); ?></h1>
<table>
    <thead>
    <tr>
        <th>Tijd</th>
        <th>Leerling</th>
        <th>Ophaallocatie</th>
        <th>Onderwerp</th>
        <th>Opmerkingen</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($lessen as $l): ?>
        <tr>
            <td><?php echo htmlspecialchars($l['starttijd'] . ' - ' . $l['eindtijd']); ?></td>
            <td><?php echo htmlspecialchars(trim(($l['voornaam'] ?? '') . ' ' . ($l['achternaam'] ?? ''))); ?></td>
            <td><?php echo htmlspecialchars($l['ophaallocatie']); ?></td>
            <td><?php echo htmlspecialchars($l['onderwerp']); ?></td>
            <td></td>
        </tr>
    <?php endforeach; ?>
    <?php if (empty($lessen)): ?>
        <tr><td colspan="5">Geen lessen op deze dag.</td></tr>
    <?php endif; ?>
    </tbody>
</table>
<button onclick="window.print()">Printen</button>
</body>
</html>


