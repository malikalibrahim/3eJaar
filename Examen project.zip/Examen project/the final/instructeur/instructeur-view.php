<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/db.php";

layout_header("Instructeurs overzicht");

$db = new DB();
$instructeurs = $db->run(
    "SELECT * FROM gebruiker WHERE rol = 'instructeur' AND actief = 1 ORDER BY achternaam, voornaam"
)->fetchAll();
?>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h5 mb-0">Instructeurs</h1>
            <a href="instructeur-add.php" class="btn btn-primary btn-sm">Nieuwe instructeur</a>
        </div>
        <table class="table table-sm align-middle">
            <thead>
            <tr>
                <th>Naam</th>
                <th>E‑mail</th>
                <th>Telefoon</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($instructeurs as $i): ?>
                <tr>
                    <td><?php echo htmlspecialchars($i['voornaam'] . ' ' . $i['achternaam']); ?></td>
                    <td><?php echo htmlspecialchars($i['email']); ?></td>
                    <td><?php echo htmlspecialchars($i['telefoon']); ?></td>
                    <td class="text-end">
                        <a href="instructeur-delete.php?id=<?php echo (int)$i['id']; ?>" class="btn btn-outline-danger btn-sm">Deactiveren</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($instructeurs)): ?>
                <tr><td colspan="4" class="small text-muted">Nog geen instructeurs.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php layout_footer(); ?>


