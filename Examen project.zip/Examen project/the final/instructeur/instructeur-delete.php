<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/db.php";

layout_header("Instructeur deactiveren");

$db = new DB();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    $db->run("UPDATE gebruiker SET actief = 0 WHERE id = :id AND rol = 'instructeur'", ['id' => $id]);
}

header("Location: instructeur-view.php");
exit;


