<?php
require_once __DIR__ . "/../user/layout.php";
require_once __DIR__ . "/../includes/Auto.php";

layout_header("Mijn auto vandaag");

$auth     = new Auth();
$user     = $auth->user();
$autoRepo = new AutoRepo();

$datum = date('Y-m-d');
$auto  = $autoRepo->autoVoorInstructeurVandaag((int)$user['id'], $datum);
?>

<div class="card shadow-sm">
    <div class="card-body">
        <h1 class="h5 mb-3">Auto voor vandaag (<?php echo htmlspecialchars($datum); ?>)</h1>

        <?php if ($auto): ?>
            <p class="mb-1"><strong>Kenteken:</strong> <?php echo htmlspecialchars($auto['kenteken']); ?></p>
            <p class="mb-1"><strong>Merk / type:</strong> <?php echo htmlspecialchars($auto['merk'] . ' ' . $auto['type']); ?></p>
            <p class="mb-1"><strong>Bouwjaar:</strong> <?php echo htmlspecialchars($auto['bouwjaar']); ?></p>
            <p class="mb-1">
                <strong>Status:</strong>
                <?php echo $auto['in_onderhoud'] ? 'In onderhoud' : 'Beschikbaar'; ?>
            </p>
        <?php else: ?>
            <p class="small text-muted mb-0">
                Er is voor vandaag nog geen auto aan je toegewezen.
            </p>
        <?php endif; ?>
    </div>
</div>

<?php layout_footer(); ?>


