    </main>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> Jongeren Kansrijker - Almere</p>
    </footer>
</body>
</html>
